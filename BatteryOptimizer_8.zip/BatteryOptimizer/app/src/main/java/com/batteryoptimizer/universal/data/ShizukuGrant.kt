package com.batteryoptimizer.universal.data

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import android.util.Log
import rikka.shizuku.Shizuku

/**
 * Optional helper. If the Shizuku app is running and allowed here, Shizuku can grant
 * "Modify system settings" (WRITE_SETTINGS) through its shell. No root is needed.
 * The app works the same without Shizuku; the Android settings screen is still the fallback.
 *
 * Every failure is logged under the tag "BatteryOptimizerShizuku" and explained in [explain].
 */
object ShizukuGrant {
    const val REQUEST_CODE = 4101
    private const val TAG = "BatteryOptimizerShizuku"

    /** Why the last grant attempt failed. Null when it worked or was not tried. */
    @Volatile
    var lastError: String? = null
        private set

    /** True when the Shizuku service is running and reachable. Never throws. */
    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        Log.w(TAG, "pingBinder failed", e)
        false
    }

    /** True when Shizuku is running and the user has allowed this app in Shizuku. Never throws. */
    fun hasPermission(): Boolean = try {
        isAvailable() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        Log.w(TAG, "checkSelfPermission failed", e)
        false
    }

    /**
     * Asks Shizuku to show its allow prompt. If the user denied this app before, Shizuku may not
     * show a prompt at all. The result is reported to the listener in the Tweaks screen.
     */
    fun requestPermission() {
        try {
            if (isAvailable()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            Log.w(TAG, "requestPermission failed", e)
        }
    }

    /** A plain-language reason for the user, based on the current state. */
    fun explain(): String = when {
        !isAvailable() -> "Shizuku is not running. Open the Shizuku app and start it, then try again."
        !hasPermission() -> "Shizuku is running but has not allowed Battery Optimizer. " +
            "Allow it in Shizuku, then try again."
        else -> lastError ?: "Shizuku allowed this app, but the change did not apply. Use Open permission screen."
    }

    /**
     * Grants this app WRITE_SETTINGS through Shizuku's shell (`appops set <package> WRITE_SETTINGS allow`).
     * Returns true only when the command exits with code 0 and Android then reports that the app can write settings.
     */
    fun grantWriteSettings(context: Context): Boolean {
        lastError = null
        if (!hasPermission()) return false
        val exitCode = runShell(arrayOf("appops", "set", context.packageName, "WRITE_SETTINGS", "allow"))
        val granted = exitCode == 0 && Settings.System.canWrite(context)
        if (!granted) {
            lastError = when (exitCode) {
                null -> "This Shizuku version did not run the grant command for this app. " +
                    "Use Open permission screen."
                0 -> "The grant command ran, but Android still reports no permission. Use Open permission screen."
                else -> "The grant command failed with code $exitCode. Use Open permission screen."
            }
            Log.w(TAG, "WRITE_SETTINGS grant failed: $lastError (exit=$exitCode)")
        }
        return granted
    }

    /**
     * Calls Shizuku.newProcess by reflection, because it is not a stable public method in every
     * Shizuku version. If it is missing or fails, this returns null and the reason is logged.
     */
    private fun runShell(command: Array<String>): Int? = try {
        val method = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
        )
        method.isAccessible = true
        val process = method.invoke(null, command, null, null) as Process
        process.waitFor()
    } catch (e: Throwable) {
        Log.w(TAG, "Shizuku shell command failed", e)
        null
    }
}
