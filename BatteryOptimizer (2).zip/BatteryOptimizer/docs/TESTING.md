# Testing report

**Status legend:** `Not run` = not yet executed. Fill in the result and date after testing on real hardware or an emulator.

The project was written in an environment without the Android SDK, Gradle dependency downloads, or devices. Nothing below has been compiled or executed yet. Source files were reviewed by reading them, which caught and fixed a wrong import path and two missing imports.

## Build

| # | Check | Method | Status |
|---|---|---|---|
| B1 | Project compiles with no errors | `./gradlew assembleArm32Debug assembleArm64Debug`, or the GitHub Actions run | Not run |
| B2 | Dependencies resolve | Same build; check that Gradle downloads succeed | Not run |
| B3 | No lint errors that block the build | Run `./gradlew lintArm64Debug` and review | Not run |
| B4 | ARM 32-bit APK produced | Check `BatteryOptimizer-arm32.apk` artifact exists and installs | Not run |
| B5 | ARM 64-bit APK produced | Check `BatteryOptimizer-arm64.apk` artifact exists and installs | Not run |

## Device detection

| # | Check | Method | Status |
|---|---|---|---|
| D1 | Manufacturer, brand, model, Android version, SDK shown correctly | Compare with Settings > About phone | Not run |
| D2 | ARM 32-bit vs 64-bit label correct | Compare with the device's CPU spec | Not run |
| D3 | RAM values plausible | Compare total RAM with the spec sheet | Not run |
| D4 | Feature list matches the device (e.g. NFC absent on a device without NFC) | Compare with the spec sheet | Not run |

## Battery information

| # | Check | Method | Status |
|---|---|---|---|
| I1 | Percentage matches the status bar | Compare on screen | Not run |
| I2 | Temperature in °C is plausible | Compare with a thermometer app or after heavy use | Not run |
| I3 | Voltage in V is plausible (about 3.5 to 4.4 V for a Li-ion cell) | Visual check | Not run |
| I4 | Charging status and source update when plugging and unplugging | Plug and unplug a charger | Not run |
| I5 | Time-to-full appears only while charging on Android 9+ and is hidden when unavailable | Charge and check | Not run |
| I6 | Unsupported values show *Not Supported*, not zero | Test on a device that omits some values, or review code path | Not run |

## Optimization and modes

| # | Check | Method | Status |
|---|---|---|---|
| O1 | Score matches the checks shown | Compare the checks and the score | Not run |
| O2 | Each *Open settings* button opens the right system screen, or the fallback settings screen | Tap each button on at least two brands | Not run |
| O3 | Ultra Battery Saver turns off this app's background alerts | Enable alerts, select Ultra, check Settings | Not run |
| O4 | Performance Mode changes no CPU or thermal settings | Review code and check no system settings change | Not run |
| O5 | Mode chips update the recommendations | Tap each chip | Not run |

## Alerts and notifications

| # | Check | Method | Status |
|---|---|---|---|
| N1 | Notification permission explained before the system prompt (Android 13+) | Enable alerts on a fresh install | Not run |
| N2 | Low battery alert at 15% when not charging | Test with the battery low or a test build with a lower threshold | Not run |
| N3 | Temperature warning at 40 °C | Hard to trigger safely; verify by code review or a test build | Not run |
| N4 | Charging started / stopped notifications | Plug and unplug | Not run |
| N5 | No alerts when alerts are off | Disable alerts and plug and unplug | Not run |

## Offline and privacy

| # | Check | Method | Status |
|---|---|---|---|
| P1 | All core features work with airplane mode on | Enable airplane mode and use every screen | Not run |
| P2 | Merged manifest has only `POST_NOTIFICATIONS` as a permission | Inspect `app/build/intermediates/merged_manifests` | Not run |
| P3 | No network calls are made | Check with a network monitor or review code (no networking libraries used) | Not run |

## Compatibility

| # | Check | Method | Status |
|---|---|---|---|
| C1 | Install and launch on Android 8.0 (API 26) | Emulator or device | Not run |
| C2 | Install and launch on a current Android version | Emulator or device | Not run |
| C3 | Layout works on a small phone and a large phone | Emulator with two screen sizes | Not run |
| C4 | Dark and light themes both readable | Toggle system theme | Not run |
| C5 | Test on a low-end device | Physical device | Not run |

## Known gaps

- No automated unit or UI tests are included yet.
- Physical battery health is not available to apps on Android, so it cannot be tested directly.
