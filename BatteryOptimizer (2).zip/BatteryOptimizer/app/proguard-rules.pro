# Compose and WorkManager ship their own consumer ProGuard rules.
# Add project-specific rules here if needed.
