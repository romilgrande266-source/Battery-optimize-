package com.batteryoptimizer.universal.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Green battery theme colour used for the charge ring, chart and primary accents. */
val BatteryGreen = Color(0xFF2E9E5B)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7BE0A4),
    onPrimary = Color(0xFF00391F),
    primaryContainer = Color(0xFF0F5235),
    onPrimaryContainer = Color(0xFFB7F2CF),
    secondary = Color(0xFF9CCFB2),
    background = Color(0xFF0E1412),
    onBackground = Color(0xFFE2F1E9),
    surface = Color(0xFF17201C),
    onSurface = Color(0xFFE2F1E9),
    surfaceVariant = Color(0xFF223029),
    onSurfaceVariant = Color(0xFFB7CCC1),
    error = Color(0xFFFFB4AB),
)

private val LightColors = lightColorScheme(
    primary = BatteryGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB7F2CF),
    onPrimaryContainer = Color(0xFF00210F),
    secondary = Color(0xFF4B6356),
    background = Color(0xFFF5FBF7),
    onBackground = Color(0xFF111D17),
    surface = Color.White,
    onSurface = Color(0xFF111D17),
    surfaceVariant = Color(0xFFDDE8E1),
    onSurfaceVariant = Color(0xFF404943),
    error = Color(0xFFBA1A1A),
)

@Composable
fun BatteryOptimizerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}
