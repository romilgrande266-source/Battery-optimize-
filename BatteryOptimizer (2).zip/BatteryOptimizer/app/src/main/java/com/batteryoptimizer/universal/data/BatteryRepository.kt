package com.batteryoptimizer.universal.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

enum class ChargeStatus(val label: String) {
    CHARGING("Charging"),
    DISCHARGING("Discharging"),
    FULL("Full"),
    NOT_CHARGING("Not charging"),
    UNKNOWN("Unknown"),
}

/**
 * Every value comes from an Android system API.
 * A null value means the device did not report it; the UI shows "Not Supported" for it.
 */
data class BatteryInfo(
    val percent: Int?,
    val temperatureC: Double?,
    val voltageV: Double?,
    val status: ChargeStatus,
    val chargingSource: String?,
    val health: String?,
    val technology: String?,
    val currentChargeMah: Int?,
    val minutesToFull: Long?,
) {
    val isCharging: Boolean get() = status == ChargeStatus.CHARGING
}

private fun Intent?.intExtra(key: String, default: Int): Int =
    this?.getIntExtra(key, default) ?: default

object BatteryRepository {

    /** Reads the current state from the sticky ACTION_BATTERY_CHANGED broadcast and BatteryManager. */
    fun read(context: Context, intent: Intent? = null): BatteryInfo {
        val i: Intent? = intent ?: context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

        val level = i.intExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.intExtra(BatteryManager.EXTRA_SCALE, -1)
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else null

        val temperatureC = i?.takeIf { it.hasExtra(BatteryManager.EXTRA_TEMPERATURE) }
            ?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
            ?.let { it / 10.0 }

        val voltageV = i.intExtra(BatteryManager.EXTRA_VOLTAGE, -1)
            .takeIf { it > 0 }
            ?.let { it / 1000.0 }

        val statusCode = i.intExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val status = when (statusCode) {
            BatteryManager.BATTERY_STATUS_CHARGING -> ChargeStatus.CHARGING
            BatteryManager.BATTERY_STATUS_DISCHARGING -> ChargeStatus.DISCHARGING
            BatteryManager.BATTERY_STATUS_FULL -> ChargeStatus.FULL
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> ChargeStatus.NOT_CHARGING
            else -> ChargeStatus.UNKNOWN
        }

        val source = when (i.intExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC adapter"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> null
        }

        val health = when (i.intExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over-voltage"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure reported"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> null
        }

        val technology = i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.takeIf { it.isNotBlank() }

        // Current charge (not design capacity). Unsupported devices return Long.MIN_VALUE, filtered by takeIf.
        val currentChargeMah = bm?.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
            ?.takeIf { it > 0 }
            ?.let { (it / 1000).toInt() }

        val minutesToFull = if (Build.VERSION.SDK_INT >= 28 && statusCode == BatteryManager.BATTERY_STATUS_CHARGING) {
            bm?.computeChargeTimeRemaining()?.takeIf { it > 0 }?.let { it / 60_000L }
        } else {
            null
        }

        return BatteryInfo(
            percent = percent,
            temperatureC = temperatureC,
            voltageV = voltageV,
            status = status,
            chargingSource = source,
            health = health,
            technology = technology,
            currentChargeMah = currentChargeMah,
            minutesToFull = minutesToFull,
        )
    }

    /** Emits a new BatteryInfo each time Android reports a battery change while the flow is collected. */
    fun observe(context: Context): Flow<BatteryInfo> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                trySend(read(c, intent))
            }
        }
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        trySend(read(context))
        awaitClose { context.unregisterReceiver(receiver) }
    }
}
