package com.batteryoptimizer.universal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.batteryoptimizer.universal.data.AppPrefs
import com.batteryoptimizer.universal.data.BatteryInfo
import com.batteryoptimizer.universal.data.BatterySample
import com.batteryoptimizer.universal.data.BatteryHistory
import com.batteryoptimizer.universal.data.BatteryRepository
import com.batteryoptimizer.universal.data.DeviceProfile
import com.batteryoptimizer.universal.data.OptimizationChecker
import com.batteryoptimizer.universal.data.OptimizationMode
import com.batteryoptimizer.universal.ui.BatteryOptimizerTheme
import com.batteryoptimizer.universal.ui.DashboardScreen
import com.batteryoptimizer.universal.ui.DeviceScreen
import com.batteryoptimizer.universal.ui.HealthScreen
import com.batteryoptimizer.universal.ui.ModeScreen
import com.batteryoptimizer.universal.ui.MonitorScreen
import com.batteryoptimizer.universal.ui.OptimizeScreen
import com.batteryoptimizer.universal.ui.Screen
import com.batteryoptimizer.universal.ui.SettingsScreen
import com.batteryoptimizer.universal.work.AlertWorker
import kotlinx.coroutines.flow.distinctUntilChanged

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BatteryOptimizerTheme {
                AppRoot()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val prefs = remember { AppPrefs(context) }

    var screen: Screen by rememberSaveable { mutableStateOf(Screen.DASHBOARD) }
    var mode: OptimizationMode by remember { mutableStateOf(prefs.mode) }

    val initialBattery = remember { BatteryRepository.read(context) }
    val battery: BatteryInfo by remember { BatteryRepository.observe(context).distinctUntilChanged() }
        .collectAsState(initial = initialBattery)
    val history: List<BatterySample> by BatteryHistory.samples.collectAsState()
    LaunchedEffect(battery) { BatteryHistory.record(battery) }

    // Re-read device and checks when the screen changes so "available RAM" and settings values stay current.
    val device = remember(screen) { DeviceProfile.read(context) }
    val report = remember(screen, battery) { OptimizationChecker.evaluate(context) }

    BackHandler(enabled = screen != Screen.DASHBOARD) { screen = Screen.DASHBOARD }

    val selectMode: (OptimizationMode) -> Unit = { selected ->
        prefs.mode = selected
        mode = selected
        if (selected == OptimizationMode.ULTRA_SAVER) {
            // Ultra mode minimizes this app's own background work.
            AlertWorker.setEnabled(context, false)
        }
        screen = Screen.MODE
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(screen.title) },
                navigationIcon = {
                    if (screen != Screen.DASHBOARD) {
                        IconButton(onClick = { screen = Screen.DASHBOARD }) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (screen) {
                Screen.DASHBOARD -> DashboardScreen(
                    battery = battery,
                    device = device,
                    report = report,
                    onNavigate = { screen = it },
                    onSelectMode = selectMode,
                )
                Screen.OPTIMIZE -> OptimizeScreen(report = report, device = device)
                Screen.MODE -> ModeScreen(mode = mode, onSelectMode = selectMode)
                Screen.HEALTH -> HealthScreen(battery = battery)
                Screen.MONITOR -> MonitorScreen(battery = battery, history = history)
                Screen.DEVICE -> DeviceScreen(device = device)
                Screen.SETTINGS -> SettingsScreen(
                    initialAlerts = prefs.alertsEnabled,
                    initialSaver = prefs.saverReminders,
                    onAlertsChange = { AlertWorker.setEnabled(context, it) },
                    onSaverChange = { prefs.saverReminders = it },
                )
            }
        }
    }
}
