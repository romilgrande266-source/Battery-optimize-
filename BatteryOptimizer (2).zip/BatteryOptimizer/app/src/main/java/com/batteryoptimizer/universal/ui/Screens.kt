package com.batteryoptimizer.universal.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.batteryoptimizer.universal.data.BatterySample
import com.batteryoptimizer.universal.data.BatteryInfo
import com.batteryoptimizer.universal.data.DeviceProfile
import com.batteryoptimizer.universal.data.GENERAL_TIPS
import com.batteryoptimizer.universal.data.OptimizationMode
import com.batteryoptimizer.universal.data.OptimizationReport
import com.batteryoptimizer.universal.data.SettingsTarget
import com.batteryoptimizer.universal.data.brandTips
import com.batteryoptimizer.universal.data.modeInfo

enum class Screen(val title: String) {
    DASHBOARD("Battery Optimizer"),
    OPTIMIZE("Battery Optimize"),
    MODE("Battery Mode"),
    HEALTH("Battery Health"),
    MONITOR("Battery Monitor"),
    DEVICE("Device Information"),
    SETTINGS("Settings"),
}

private class QuickAction(val label: String, val icon: ImageVector, val onClick: () -> Unit)

@Composable
fun DashboardScreen(
    battery: BatteryInfo,
    device: DeviceProfile,
    report: OptimizationReport,
    onNavigate: (Screen) -> Unit,
    onSelectMode: (OptimizationMode) -> Unit,
) {
    val saverOn = report.checks.firstOrNull { it.target == SettingsTarget.BATTERY_SAVER }?.passed
    val actions = listOf(
        QuickAction("BATTERY OPTIMIZE", Icons.Filled.BatteryFull) { onNavigate(Screen.OPTIMIZE) },
        QuickAction("ULTRA BATTERY SAVER", Icons.Filled.BatteryAlert) { onSelectMode(OptimizationMode.ULTRA_SAVER) },
        QuickAction("NORMAL MODE", Icons.Filled.Tune) { onSelectMode(OptimizationMode.NORMAL) },
        QuickAction("PERFORMANCE MODE", Icons.Filled.Speed) { onSelectMode(OptimizationMode.PERFORMANCE) },
        QuickAction("BATTERY HEALTH", Icons.Filled.Favorite) { onNavigate(Screen.HEALTH) },
        QuickAction("BATTERY MONITOR", Icons.Filled.Insights) { onNavigate(Screen.MONITOR) },
        QuickAction("DEVICE INFORMATION", Icons.Filled.Smartphone) { onNavigate(Screen.DEVICE) },
        QuickAction("SETTINGS", Icons.Filled.Settings) { onNavigate(Screen.SETTINGS) },
    )

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        BatteryCircle(percent = battery.percent)
        Text(statusLine(battery), style = MaterialTheme.typography.bodyLarge)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard(
                label = "Temperature",
                value = battery.temperatureC?.let { "%.1f °C".format(it) } ?: NOT_SUPPORTED,
                icon = Icons.Filled.Thermostat,
                modifier = Modifier.weight(1f),
            )
            MetricCard(
                label = "Voltage",
                value = battery.voltageV?.let { "%.2f V".format(it) } ?: NOT_SUPPORTED,
                icon = Icons.Filled.ElectricBolt,
                modifier = Modifier.weight(1f),
            )
        }

        SectionCard("Device") {
            InfoRow("Model", "${device.brand} ${device.model}")
            InfoRow("Android", "${device.androidRelease} (SDK ${device.sdkInt})")
            InfoRow("Architecture", abiLabel(device.primaryAbi))
            InfoRow("Available RAM", "${device.availableRamMb} MB of ${device.totalRamMb} MB")
        }

        SectionCard("Battery optimization score") {
            Text(
                report.score?.let { "$it / 100" } ?: NOT_SUPPORTED,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
            )
            report.score?.let { score ->
                LinearProgressIndicator(progress = { score / 100f }, modifier = Modifier.fillMaxWidth())
            }
        }

        SectionCard("Battery Saver") {
            InfoRow(
                "Status",
                when (saverOn) {
                    true -> "On"
                    false -> "Off"
                    null -> NOT_SUPPORTED
                },
            )
        }

        Text("Quick actions", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth())
        actions.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { action ->
                    MenuButton(action.label, action.icon, Modifier.weight(1f)) { action.onClick() }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun OptimizeScreen(report: OptimizationReport, device: DeviceProfile) {
    val context = LocalContext.current
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Optimization score") {
            Text(
                report.score?.let { "$it / 100" } ?: NOT_SUPPORTED,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
            )
            val measured = report.checks.count { it.passed != null }
            Text(
                "Based on $measured of ${report.checks.size} checks that Android lets this app read.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        report.checks.forEach { check ->
            SectionCard(check.title) {
                Text(verdict(check.passed), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Text(check.detail, style = MaterialTheme.typography.bodyMedium)
                check.target?.let { target ->
                    TextButton(onClick = { openSystemSettings(context, target) }) { Text("Open settings") }
                }
            }
        }

        SectionCard("Recommended for ${device.brand}") {
            brandTips(device.manufacturer).forEach {
                Text("• $it", style = MaterialTheme.typography.bodyMedium)
            }
            Text(
                "Menu names differ by Android version and phone software.",
                style = MaterialTheme.typography.labelSmall,
            )
        }

        SectionCard("General recommendations") {
            GENERAL_TIPS.forEach {
                Text("• $it", style = MaterialTheme.typography.bodyMedium)
            }
        }

        SectionCard("Background battery usage") {
            Text(
                "Battery usage shows which apps used the most power recently. This app cannot read other " +
                    "apps' usage, so it opens the system screen for you.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        Button(
            onClick = { openSystemSettings(context, SettingsTarget.BATTERY_OPTIMIZATION) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("OPEN BATTERY OPTIMIZATION SETTINGS") }
        OutlinedButton(
            onClick = { openSystemSettings(context, SettingsTarget.BATTERY_SAVER) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("OPEN POWER-SAVING SETTINGS") }
        OutlinedButton(
            onClick = { openSystemSettings(context, SettingsTarget.BATTERY_USAGE) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("OPEN BATTERY USAGE") }

        Text(
            "This app never force-stops apps or changes protected system settings. It only opens the settings screens for you.",
            style = MaterialTheme.typography.labelSmall,
        )
    }
}

@Composable
fun ModeScreen(mode: OptimizationMode, onSelectMode: (OptimizationMode) -> Unit) {
    val context = LocalContext.current
    val info = modeInfo(mode)
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OptimizationMode.entries.forEach { m ->
                FilterChip(
                    selected = m == mode,
                    onClick = { onSelectMode(m) },
                    label = { Text(modeInfo(m).title) },
                )
            }
        }

        SectionCard(info.title) {
            Text(info.summary, style = MaterialTheme.typography.bodyMedium)
        }

        SectionCard("Recommendations") {
            info.tips.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
        }

        if (mode == OptimizationMode.ULTRA_SAVER) {
            SectionCard("This app's background activity") {
                Text(
                    "Background battery alerts for this app are turned off in this mode. " +
                        "You can turn them on again in Settings.",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        Button(
            onClick = { openSystemSettings(context, info.shortcut) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(info.shortcutLabel.uppercase()) }
    }
}

@Composable
fun HealthScreen(battery: BatteryInfo) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Reported by Android") {
            InfoRow("Health status", battery.health ?: NOT_SUPPORTED)
            InfoRow("Battery technology", battery.technology ?: NOT_SUPPORTED)
            InfoRow("Current charge", battery.currentChargeMah?.let { "$it mAh" } ?: NOT_SUPPORTED)
            InfoRow("Design capacity", NOT_SUPPORTED)
            InfoRow("Charge cycles", NOT_SUPPORTED)
            InfoRow("Time to full charge", battery.minutesToFull?.let { "$it min" } ?: NOT_SUPPORTED)
        }
        SectionCard("About these values") {
            Text(
                "Android does not give apps the physical wear level, design capacity or cycle count of a battery, " +
                    "so those fields show Not Supported instead of estimates. No app can restore battery capacity " +
                    "or improve battery health. Battery condition changes with age, heat and charge cycles.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
fun MonitorScreen(battery: BatteryInfo, history: List<BatterySample>) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Live readings") {
            InfoRow("Battery level", battery.percent?.let { "$it%" } ?: NOT_SUPPORTED)
            InfoRow("Temperature", battery.temperatureC?.let { "%.1f °C".format(it) } ?: NOT_SUPPORTED)
            InfoRow("Voltage", battery.voltageV?.let { "%.2f V".format(it) } ?: NOT_SUPPORTED)
            InfoRow("Status", statusLine(battery))
        }
        SectionCard("Level history (this session)") {
            if (history.size < 2) {
                Text(
                    "Collecting samples. One sample is kept per minute while the app is open. " +
                        "History stays in memory only.",
                    style = MaterialTheme.typography.bodySmall,
                )
            } else {
                Canvas(Modifier.fillMaxWidth().height(140.dp)) {
                    val values = history.map { it.percent }
                    val path = Path()
                    values.forEachIndexed { i, v ->
                        val x = size.width * i / (values.size - 1)
                        val y = size.height * (1f - v / 100f)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, BatteryGreen, style = Stroke(width = 4.dp.toPx()))
                }
            }
        }
        SectionCard("Warnings") {
            Text(
                "With background alerts on, you get a temperature warning at 40 °C or higher and a low battery " +
                    "alert at 15% or lower.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
fun DeviceScreen(device: DeviceProfile) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Identity") {
            InfoRow("Manufacturer", device.manufacturer)
            InfoRow("Brand", device.brand)
            InfoRow("Model", device.model)
        }
        SectionCard("Software") {
            InfoRow("Android version", device.androidRelease)
            InfoRow("SDK level", device.sdkInt.toString())
        }
        SectionCard("Hardware") {
            InfoRow("Primary CPU ABI", abiLabel(device.primaryAbi))
            InfoRow("All supported ABIs", device.supportedAbis.joinToString())
            InfoRow("Total RAM", "${device.totalRamMb} MB")
            InfoRow("Available RAM", "${device.availableRamMb} MB")
            InfoRow("Screen", "${device.screenWidthPx} × ${device.screenHeightPx} px")
            InfoRow("Density", "${device.densityDpi} dpi")
        }
        SectionCard("Features") {
            device.features.forEach { feature ->
                InfoRow(feature.name, if (feature.supported) "Supported" else NOT_SUPPORTED)
            }
        }
    }
}

@Composable
fun SettingsScreen(
    initialAlerts: Boolean,
    initialSaver: Boolean,
    onAlertsChange: (Boolean) -> Unit,
    onSaverChange: (Boolean) -> Unit,
) {
    val context = LocalContext.current
    var alerts by remember { mutableStateOf(initialAlerts) }
    var saver by remember { mutableStateOf(initialSaver) }
    var explainPermission by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            alerts = true
            onAlertsChange(true)
        }
    }

    fun setAlerts(on: Boolean) {
        if (!on) {
            alerts = false
            onAlertsChange(false)
            return
        }
        val needsPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            explainPermission = true
        } else {
            alerts = true
            onAlertsChange(true)
        }
    }

    if (explainPermission) {
        AlertDialog(
            onDismissRequest = { explainPermission = false },
            title = { Text("Allow notifications?") },
            text = {
                Text(
                    "Battery Optimizer uses notifications only for the alerts you turn on: low battery, " +
                        "temperature warnings, charging, and Battery Saver reminders. It does not need internet, " +
                        "location or storage access.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    explainPermission = false
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }) { Text("Continue") }
            },
            dismissButton = {
                TextButton(onClick = { explainPermission = false }) { Text("Not now") }
            },
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Background battery alerts") {
            Text(
                "Low battery, temperature warnings and charging notifications. While enabled, checks run about " +
                    "every 15 minutes with WorkManager. No foreground service is used.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Enable alerts", modifier = Modifier.weight(1f))
                Switch(checked = alerts, onCheckedChange = { setAlerts(it) })
            }
        }

        SectionCard("Battery Saver reminders") {
            Text(
                "Reminds you when the battery is at 20% or lower and Battery Saver is off. Requires background alerts.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Enable reminders", modifier = Modifier.weight(1f))
                Switch(
                    checked = saver,
                    onCheckedChange = {
                        saver = it
                        onSaverChange(it)
                    },
                )
            }
        }

        SectionCard("Permissions and privacy") {
            Text(
                "The only permission requested is notifications (Android 13 and newer), asked for only when you " +
                    "turn on alerts. The app has no internet permission, collects no personal data, uploads nothing, " +
                    "and keeps battery readings on this device.",
                style = MaterialTheme.typography.bodyMedium,
            )
            OutlinedButton(
                onClick = { openAppNotificationSettings(context) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("OPEN NOTIFICATION SETTINGS") }
        }
    }
}

private fun openAppNotificationSettings(context: Context) {
    val intent = Intent(AndroidSettings.ACTION_APP_NOTIFICATION_SETTINGS)
        .putExtra(AndroidSettings.EXTRA_APP_PACKAGE, context.packageName)
    context.startActivity(intent)
}

private fun verdict(passed: Boolean?): String = when (passed) {
    true -> "Good"
    false -> "Needs attention"
    null -> NOT_SUPPORTED
}

private fun statusLine(b: BatteryInfo): String {
    val parts = mutableListOf(b.status.label)
    b.chargingSource?.let { parts += it }
    b.minutesToFull?.let { parts += "about $it min to full" }
    return parts.joinToString(" · ")
}

private fun abiLabel(abi: String): String = when (abi) {
    "armeabi-v7a" -> "ARM 32-bit (armeabi-v7a)"
    "arm64-v8a" -> "ARM 64-bit (arm64-v8a)"
    else -> abi
}
