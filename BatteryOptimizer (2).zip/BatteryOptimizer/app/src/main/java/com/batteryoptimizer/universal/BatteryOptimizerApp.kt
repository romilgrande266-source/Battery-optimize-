package com.batteryoptimizer.universal

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.batteryoptimizer.universal.notify.Notifications

class BatteryOptimizerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(
            Notifications.CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply { description = getString(R.string.channel_description) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}
