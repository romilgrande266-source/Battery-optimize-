package com.batteryoptimizer.universal.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class BatterySample(val timeMs: Long, val percent: Int, val temperatureC: Double?)

/**
 * In-memory history only. Samples exist while the app is open, are kept at most once per minute,
 * and are never written to disk or sent anywhere.
 */
object BatteryHistory {
    private const val MAX_SAMPLES = 120
    private const val MIN_INTERVAL_MS = 60_000L

    private val _samples = MutableStateFlow<List<BatterySample>>(emptyList())
    val samples: StateFlow<List<BatterySample>> = _samples.asStateFlow()

    fun record(info: BatteryInfo) {
        val percent = info.percent ?: return
        val now = System.currentTimeMillis()
        val current = _samples.value
        if (current.isNotEmpty() && now - current.last().timeMs < MIN_INTERVAL_MS) return
        _samples.value = (current + BatterySample(now, percent, info.temperatureC)).takeLast(MAX_SAMPLES)
    }
}
