package com.batteryoptimizer.universal.data

import android.content.Context
import android.os.PowerManager
import android.provider.Settings

enum class SettingsTarget { BATTERY_OPTIMIZATION, BATTERY_SAVER, DISPLAY, BATTERY_USAGE }

/** passed = null means the value cannot be measured on this device and is shown as Not Supported. */
data class Check(
    val title: String,
    val passed: Boolean?,
    val detail: String,
    val target: SettingsTarget?,
)

data class OptimizationReport(val score: Int?, val checks: List<Check>)

object OptimizationChecker {
    private const val BRIGHTNESS_LIMIT = 153     // about 60% of the 0–255 range
    private const val TIMEOUT_LIMIT_MS = 60_000

    /** Score = share of measurable checks that pass. Nothing is estimated. */
    fun evaluate(context: Context): OptimizationReport {
        val pm = context.getSystemService(PowerManager::class.java)
        val ignoring = pm.isIgnoringBatteryOptimizations(context.packageName)
        val saverOn = pm.isPowerSaveMode
        val brightness = readSetting(context, Settings.System.SCREEN_BRIGHTNESS)
        val timeout = readSetting(context, Settings.System.SCREEN_OFF_TIMEOUT)

        val checks = listOf(
            Check(
                title = "App battery optimization",
                passed = !ignoring,
                detail = if (ignoring) {
                    "This app is excluded from battery optimization."
                } else {
                    "Android applies battery optimization to this app."
                },
                target = SettingsTarget.BATTERY_OPTIMIZATION,
            ),
            Check(
                title = "Battery Saver",
                passed = saverOn,
                detail = if (saverOn) "Battery Saver is on." else "Battery Saver is off.",
                target = SettingsTarget.BATTERY_SAVER,
            ),
            Check(
                title = "Screen brightness",
                passed = brightness?.let { it <= BRIGHTNESS_LIMIT },
                detail = brightness?.let { "Current level ${it * 100 / 255}%. Recommended: 60% or lower." }
                    ?: NOT_SUPPORTED_TEXT,
                target = SettingsTarget.DISPLAY,
            ),
            Check(
                title = "Screen timeout",
                passed = timeout?.let { it <= TIMEOUT_LIMIT_MS },
                detail = timeout?.let { "Screen turns off after ${it / 1000} seconds. Recommended: 60 seconds or less." }
                    ?: NOT_SUPPORTED_TEXT,
                target = SettingsTarget.DISPLAY,
            ),
        )

        val measurable = checks.mapNotNull { it.passed }
        val score = if (measurable.isEmpty()) null else measurable.count { it } * 100 / measurable.size
        return OptimizationReport(score, checks)
    }

    private fun readSetting(context: Context, name: String): Int? = try {
        Settings.System.getInt(context.contentResolver, name)
    } catch (e: Settings.SettingNotFoundException) {
        null
    }

    private const val NOT_SUPPORTED_TEXT = "Not Supported"
}

/** Brand-specific guidance. Menu names differ between Android versions and phone software. */
fun brandTips(manufacturer: String): List<String> {
    val m = manufacturer.lowercase()
    return when {
        listOf("xiaomi", "redmi", "poco").any { m.contains(it) } -> listOf(
            "Open the Security app and review Autostart and battery-saver settings for apps you rarely use.",
            "In Battery settings, check the apps listed under battery usage and restrict those you do not need in the background.",
        )
        m.contains("samsung") -> listOf(
            "Open Device care, then Battery, to review background usage and put unused apps to sleep.",
        )
        m.contains("huawei") || m.contains("honor") -> listOf(
            "Open App launch or Startup manager and turn off automatic background activity for rarely used apps.",
        )
        listOf("oppo", "realme", "oneplus").any { m.contains(it) } -> listOf(
            "Open Battery settings and review app battery management or background restrictions for apps you rarely use.",
        )
        m.contains("vivo") -> listOf(
            "Open iManager or Battery settings and review background power consumption for each app.",
        )
        m.contains("infinix") || m.contains("tecno") -> listOf(
            "Open Phone Manager or Battery settings and review background app restrictions.",
        )
        m.contains("motorola") || m.contains("google") -> listOf(
            "Open Settings, then Battery, then Battery usage, to see which apps use the most power.",
        )
        else -> listOf("Open Settings, then Battery, to see which apps use the most power.")
    }
}

val GENERAL_TIPS: List<String> = listOf(
    "Lower screen brightness, or keep adaptive brightness on.",
    "Use a shorter screen timeout, such as 30 to 60 seconds.",
    "Turn off Bluetooth, NFC and Wi-Fi scanning when you are not using them.",
    "Set location access to \"While using the app\" for apps that do not need it all the time.",
    "Check battery usage weekly for apps with unusually high use.",
    "On OLED screens, dark mode uses less power.",
    "Install system updates; they often include battery fixes.",
)
