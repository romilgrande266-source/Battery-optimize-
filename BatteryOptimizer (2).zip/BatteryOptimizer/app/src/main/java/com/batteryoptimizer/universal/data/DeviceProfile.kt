package com.batteryoptimizer.universal.data

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

data class FeatureState(val name: String, val supported: Boolean)

data class DeviceProfile(
    val manufacturer: String,
    val brand: String,
    val model: String,
    val androidRelease: String,
    val sdkInt: Int,
    val primaryAbi: String,
    val supportedAbis: List<String>,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val screenWidthPx: Int,
    val screenHeightPx: Int,
    val densityDpi: Int,
    val features: List<FeatureState>,
) {
    companion object {
        fun read(context: Context): DeviceProfile {
            val am = context.getSystemService(ActivityManager::class.java)
            val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
            val dm = context.resources.displayMetrics
            val pm = context.packageManager

            val features = listOf(
                "Bluetooth" to PackageManager.FEATURE_BLUETOOTH,
                "NFC" to PackageManager.FEATURE_NFC,
                "Wi-Fi" to PackageManager.FEATURE_WIFI,
                "Fingerprint sensor" to PackageManager.FEATURE_FINGERPRINT,
                "Camera flash" to PackageManager.FEATURE_CAMERA_FLASH,
                "Accelerometer" to PackageManager.FEATURE_SENSOR_ACCELEROMETER,
                "Telephony" to PackageManager.FEATURE_TELEPHONY,
            ).map { (name, feature) -> FeatureState(name, pm.hasSystemFeature(feature)) }

            return DeviceProfile(
                manufacturer = Build.MANUFACTURER,
                brand = Build.BRAND,
                model = Build.MODEL,
                androidRelease = Build.VERSION.RELEASE,
                sdkInt = Build.VERSION.SDK_INT,
                primaryAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown",
                supportedAbis = Build.SUPPORTED_ABIS.toList(),
                totalRamMb = mem.totalMem / (1024 * 1024),
                availableRamMb = mem.availMem / (1024 * 1024),
                screenWidthPx = dm.widthPixels,
                screenHeightPx = dm.heightPixels,
                densityDpi = dm.densityDpi,
                features = features,
            )
        }
    }
}
