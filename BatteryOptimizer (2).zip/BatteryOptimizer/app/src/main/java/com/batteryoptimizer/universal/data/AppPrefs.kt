package com.batteryoptimizer.universal.data

import android.content.Context
import androidx.core.content.edit

enum class OptimizationMode { NORMAL, BATTERY_SAVER, ULTRA_SAVER, PERFORMANCE }

data class ModeInfo(
    val title: String,
    val summary: String,
    val tips: List<String>,
    val shortcut: SettingsTarget,
    val shortcutLabel: String,
)

fun modeInfo(mode: OptimizationMode): ModeInfo = when (mode) {
    OptimizationMode.NORMAL -> ModeInfo(
        title = "Normal Mode",
        summary = "Regular use with a balance of battery life and performance.",
        tips = listOf(
            "Keep adaptive brightness on.",
            "Use a screen timeout of 60 seconds or less.",
            "Review battery usage every week.",
        ),
        shortcut = SettingsTarget.BATTERY_USAGE,
        shortcutLabel = "Open battery usage",
    )
    OptimizationMode.BATTERY_SAVER -> ModeInfo(
        title = "Battery Saver",
        summary = "Reduces the most common sources of battery drain.",
        tips = listOf(
            "Reduce screen brightness to about 50% or lower.",
            "Set the screen timeout to 30 to 60 seconds.",
            "Turn on Battery Saver in system settings (shortcut below).",
            "Turn off Bluetooth and NFC when you are not using them.",
        ),
        shortcut = SettingsTarget.BATTERY_SAVER,
        shortcutLabel = "Open Battery Saver settings",
    )
    OptimizationMode.ULTRA_SAVER -> ModeInfo(
        title = "Ultra Battery Saver",
        summary = "The strongest recommendations. This app also minimizes its own background activity: " +
            "its battery alerts are turned off while this mode is selected.",
        tips = listOf(
            "Turn on Battery Saver and restrict background activity for apps you rarely use.",
            "Set brightness low and the screen timeout to 15 to 30 seconds.",
            "Use dark mode on OLED screens.",
            "Turn off Wi-Fi, Bluetooth, NFC and location when you do not need them.",
            "Lower the screen refresh rate if your device offers a power-saving option.",
        ),
        shortcut = SettingsTarget.BATTERY_SAVER,
        shortcutLabel = "Open Battery Saver settings",
    )
    OptimizationMode.PERFORMANCE -> ModeInfo(
        title = "Performance Mode",
        summary = "Shows performance-related settings and battery usage information. This app does not " +
            "overclock the CPU or change thermal protection; performance is controlled by your phone's system software.",
        tips = listOf(
            "Expect faster response and higher battery use.",
            "Check battery usage to see which apps use the most power.",
            "Keep brightness at the level you need; higher brightness uses more power.",
        ),
        shortcut = SettingsTarget.BATTERY_USAGE,
        shortcutLabel = "Open battery usage",
    )
}

/** Simple SharedPreferences wrapper. Nothing here leaves the device. */
class AppPrefs(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("battery_optimizer", Context.MODE_PRIVATE)

    var mode: OptimizationMode
        get() = OptimizationMode.entries.getOrElse(prefs.getInt(KEY_MODE, 0)) { OptimizationMode.NORMAL }
        set(value) { prefs.edit { putInt(KEY_MODE, value.ordinal) } }

    var alertsEnabled: Boolean
        get() = getFlag(KEY_ALERTS)
        set(value) = setFlag(KEY_ALERTS, value)

    var saverReminders: Boolean
        get() = getFlag(KEY_SAVER_REMINDERS)
        set(value) = setFlag(KEY_SAVER_REMINDERS, value)

    // Internal "already notified" flags so one condition does not repeat every check.
    var lowNotified: Boolean
        get() = getFlag(KEY_LOW_NOTIFIED)
        set(value) = setFlag(KEY_LOW_NOTIFIED, value)

    var saverNotified: Boolean
        get() = getFlag(KEY_SAVER_NOTIFIED)
        set(value) = setFlag(KEY_SAVER_NOTIFIED, value)

    var tempNotified: Boolean
        get() = getFlag(KEY_TEMP_NOTIFIED)
        set(value) = setFlag(KEY_TEMP_NOTIFIED, value)

    private fun getFlag(key: String): Boolean = prefs.getBoolean(key, false)

    private fun setFlag(key: String, value: Boolean) {
        prefs.edit { putBoolean(key, value) }
    }

    private companion object {
        const val KEY_MODE = "mode"
        const val KEY_ALERTS = "alerts_enabled"
        const val KEY_SAVER_REMINDERS = "saver_reminders"
        const val KEY_LOW_NOTIFIED = "low_notified"
        const val KEY_SAVER_NOTIFIED = "saver_notified"
        const val KEY_TEMP_NOTIFIED = "temp_notified"
    }
}
