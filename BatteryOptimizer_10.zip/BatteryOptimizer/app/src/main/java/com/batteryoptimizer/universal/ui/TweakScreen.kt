package com.batteryoptimizer.universal.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.batteryoptimizer.universal.data.AppPrefs
import com.batteryoptimizer.universal.data.BatteryHistory
import com.batteryoptimizer.universal.data.BatteryInfo
import com.batteryoptimizer.universal.data.GENERAL_TIPS
import com.batteryoptimizer.universal.data.InAppChange
import com.batteryoptimizer.universal.data.OptimizationMode
import com.batteryoptimizer.universal.data.ShizukuGrant
import com.batteryoptimizer.universal.data.verifiedApply
import android.content.pm.PackageManager
import androidx.compose.runtime.DisposableEffect
import rikka.shizuku.Shizuku
import com.batteryoptimizer.universal.data.Tweak
import com.batteryoptimizer.universal.data.TweakBackup
import com.batteryoptimizer.universal.data.UiPrefs
import com.batteryoptimizer.universal.data.buildTweaks
import com.batteryoptimizer.universal.work.AlertWorker

@Composable
fun TweaksScreen(
    battery: BatteryInfo,
    onSelectMode: (OptimizationMode) -> Unit,
    onRestored: () -> Unit,
) {
    val context = LocalContext.current
    var refresh by remember { mutableStateOf(0) }
    var askPermission by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    // Shizuku reports the answer to its allow request here. Without this, a grant or denial gives no feedback.
    DisposableEffect(Unit) {
        val listener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuGrant.REQUEST_CODE) {
                message = if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    "Shizuku allowed Battery Optimizer. Tap the change again."
                } else {
                    "Shizuku did not allow Battery Optimizer. Allow it in Shizuku, then tap the change again."
                }
            }
        }
        try {
            Shizuku.addRequestPermissionResultListener(listener)
        } catch (e: Throwable) {
            message = "Shizuku is not available: ${e.message}"
        }
        onDispose {
            try {
                Shizuku.removeRequestPermissionResultListener(listener)
            } catch (e: Throwable) {
                // Shizuku is already gone. Nothing to remove.
            }
        }
    }

    val tweaks = remember(refresh, battery) { buildTweaks(context, battery) }
    val supportedCount = tweaks.count { it.supported }
    val optimizeAllChanges = tweaks
        .filter { it.supported }
        .mapNotNull { it.change }
        .filter { it != InAppChange.ULTRA_MODE }

    fun runChanges(changes: List<InAppChange>) {
        if (changes.isEmpty()) {
            message = "No changes are available on this device. Use OPEN SETTINGS for the other tweaks."
            return
        }
        // Use Shizuku only when it is running and allowed. Otherwise ask for the normal Android permission.
        if (!TweakBackup.canWrite(context) && !ShizukuGrant.grantWriteSettings(context)) {
            message = ShizukuGrant.explain()
            askPermission = true
            return
        }
        message = changes.joinToString("\n") { change ->
            val name = if (change == InAppChange.LOWER_BRIGHTNESS) "Brightness" else "Screen timeout"
            if (verifiedApply(context, change)) {
                "$name: changed. Android confirmed the new value."
            } else {
                "$name: Android did not confirm the change."
            }
        }
        refresh++
    }

    fun restore() {
        val systemOk = restoreEverything(context)
        message = if (systemOk) {
            "Restored. Brightness and screen timeout were returned to their earlier values."
        } else {
            "App preferences were reset. Brightness and timeout need permission to restore."
        }
        onRestored()
        refresh++
    }

    if (askPermission) {
        AlertDialog(
            onDismissRequest = { askPermission = false },
            title = { Text("Allow screen changes?") },
            text = {
                Column {
                    Text(
                        "Android needs your permission before an app can change brightness or screen timeout. " +
                            "The app changes these only when you tap a button, and it saves the old values so " +
                            "Restore Default Settings can put them back.",
                    )
                    // Shown only when the Shizuku app is running. Shizuku is optional.
                    if (ShizukuGrant.isAvailable()) {
                        TextButton(onClick = {
                            askPermission = false
                            ShizukuGrant.requestPermission()
                            message = "Shizuku prompt sent. Allow Battery Optimizer in Shizuku, then tap the change again."
                        }) { Text("Use Shizuku instead") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    askPermission = false
                    openWriteSettingsPermission(context)
                }) { Text("Open permission screen") }
            },
            dismissButton = {
                TextButton(onClick = { askPermission = false }) { Text("Not now") }
            },
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PremiumCard {
            Text(
                "$supportedCount of ${tweaks.size} tweaks are supported on this device",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
            )
            Text(
                "Status shows what Android reports. A change is marked done only after Android confirms it.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        Button(
            onClick = { runChanges(optimizeAllChanges) },
            modifier = Modifier.fillMaxWidth().height(60.dp),
        ) { Text("OPTIMIZE ALL", fontWeight = FontWeight.Bold) }

        OutlinedButton(onClick = { restore() }, modifier = Modifier.fillMaxWidth()) {
            Text("RESTORE DEFAULT SETTINGS")
        }

        message?.let { text ->
            PremiumCard { Text(text, style = MaterialTheme.typography.bodyMedium) }
        }

        tweaks.forEach { tweak ->
            TweakCard(
                tweak = tweak,
                onChange = { change ->
                    if (change == InAppChange.ULTRA_MODE) {
                        onSelectMode(OptimizationMode.ULTRA_SAVER)
                    } else {
                        runChanges(listOf(change))
                    }
                },
                onOpen = { action -> openAction(context, action) },
            )
        }

        PremiumCard {
            Text("Battery-saving recommendations", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            GENERAL_TIPS.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
        }
    }
}

@Composable
private fun TweakCard(tweak: Tweak, onChange: (InAppChange) -> Unit, onOpen: (String) -> Unit) {
    PremiumCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(
                imageVector = tweakIcon(tweak.number),
                contentDescription = null,
                tint = BatteryGreen,
                modifier = Modifier.size(28.dp),
            )
            Column(Modifier.weight(1f)) {
                Text("${tweak.number}. ${tweak.title}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                StatusPill(tweak.value)
            }
        }
        Text(tweak.advice, style = MaterialTheme.typography.bodyMedium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val change = tweak.change
            if (change != null && tweak.supported) {
                Button(onClick = { onChange(change) }, modifier = Modifier.weight(1f)) {
                    Text(changeLabel(change))
                }
            }
            val action = tweak.action
            if (action != null) {
                OutlinedButton(onClick = { onOpen(action) }, modifier = Modifier.weight(1f)) {
                    Text("OPEN SETTINGS")
                }
            }
        }
    }
}

/** Restores system values this app changed, and resets this app's own preferences. */
fun restoreEverything(context: Context): Boolean {
    val systemOk = TweakBackup.restoreSystemSettings(context)
    val app = AppPrefs(context)
    app.mode = OptimizationMode.NORMAL
    app.saverReminders = false
    AlertWorker.setEnabled(context, false)
    val ui = UiPrefs(context)
    ui.themeMode = 0
    ui.tempAlertEnabled = true
    ui.batteryAlertEnabled = true
    return systemOk
}

private fun tweakIcon(number: Int): ImageVector = when (number) {
    1 -> Icons.Filled.Brightness6
    2 -> Icons.Filled.Timer
    3 -> Icons.Filled.Insights
    4 -> Icons.Filled.Memory
    5 -> Icons.Filled.ElectricBolt
    6 -> Icons.Filled.DarkMode
    7 -> Icons.Filled.Speed
    8 -> Icons.Filled.LocationOn
    9 -> Icons.Filled.Bluetooth
    10 -> Icons.Filled.Wifi
    11 -> Icons.Filled.SignalCellularAlt
    12 -> Icons.Filled.Share
    13 -> Icons.Filled.Eco
    14 -> Icons.Filled.Visibility
    15 -> Icons.Filled.Vibration
    16 -> Icons.Filled.Keyboard
    17 -> Icons.Filled.Notifications
    18 -> Icons.Filled.Sync
    19 -> Icons.Filled.Thermostat
    else -> Icons.Filled.BatteryAlert
}

private fun changeLabel(change: InAppChange): String = when (change) {
    InAppChange.LOWER_BRIGHTNESS -> "LOWER BRIGHTNESS"
    InAppChange.SHORTER_TIMEOUT -> "SHORTER TIMEOUT"
    InAppChange.ULTRA_MODE -> "SWITCH TO ULTRA"
}

private fun openAction(context: Context, action: String) {
    try {
        context.startActivity(Intent(action))
    } catch (e: ActivityNotFoundException) {
        context.startActivity(Intent(Settings.ACTION_SETTINGS))
    }
}

private fun openWriteSettingsPermission(context: Context) {
    val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
    context.startActivity(intent)
}
