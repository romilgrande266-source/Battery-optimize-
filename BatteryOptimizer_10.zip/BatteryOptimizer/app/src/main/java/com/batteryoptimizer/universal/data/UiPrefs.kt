package com.batteryoptimizer.universal.data

import android.content.Context
import androidx.core.content.edit

/** Appearance and alert-type preferences. Stored only on this device. */
class UiPrefs(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("ui_prefs", Context.MODE_PRIVATE)

    /** 0 = automatic (follow phone), 1 = dark, 2 = light */
    var themeMode: Int
        get() = prefs.getInt(KEY_THEME, 0)
        set(value) { prefs.edit { putInt(KEY_THEME, value) } }

    var tempAlertEnabled: Boolean
        get() = prefs.getBoolean(KEY_TEMP, true)
        set(value) { prefs.edit { putBoolean(KEY_TEMP, value) } }

    var batteryAlertEnabled: Boolean
        get() = prefs.getBoolean(KEY_BATTERY, true)
        set(value) { prefs.edit { putBoolean(KEY_BATTERY, value) } }

    private companion object {
        const val KEY_THEME = "theme_mode"
        const val KEY_TEMP = "temp_alert"
        const val KEY_BATTERY = "battery_alert"
    }
}
