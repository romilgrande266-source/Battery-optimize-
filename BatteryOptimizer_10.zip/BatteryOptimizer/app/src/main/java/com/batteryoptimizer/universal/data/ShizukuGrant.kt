package com.batteryoptimizer.universal.data

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

/**
 * Optional Shizuku integration. Shizuku runs a privileged shell that this app can ask to run a few
 * fixed commands: the WRITE_SETTINGS grant and background restriction for apps the user picks.
 * No root is needed, and the app works the same without Shizuku.
 *
 * Every failure is logged under the tag "BatteryOptimizerShizuku" and kept in [lastError].
 */
object ShizukuGrant {
    const val REQUEST_CODE = 4101
    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    const val DOWNLOAD_URL = "https://shizuku.rikka.app/download/"
    const val RESTRICT_OP = "RUN_ANY_IN_BACKGROUND"
    private const val TAG = "BatteryOptimizerShizuku"

    class ShellResult(val exitCode: Int, val output: String)

    /** Why the last Shizuku action failed. Null when it worked or has not run. */
    @Volatile
    var lastError: String? = null
        private set

    private val _connected = MutableStateFlow(false)

    /** True when Shizuku is running and allowed for this app. Updates when Shizuku starts or stops. */
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    @Volatile
    private var listening = false

    /** Listens for Shizuku starting and stopping. Safe to call more than once. */
    fun startListeners() {
        if (listening) return
        listening = true
        try {
            Shizuku.addBinderReceivedListener { refresh() }
            Shizuku.addBinderDeadListener { _connected.value = false }
        } catch (e: Throwable) {
            listening = false
            Log.w(TAG, "Could not register Shizuku listeners", e)
        }
        refresh()
    }

    /** Re-checks the connection and updates [connected]. Never throws. */
    fun refresh() {
        _connected.value = hasPermission()
    }

    /** True when the Shizuku manager app is installed. */
    fun isInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** True when the Shizuku service is running and reachable. Never throws. */
    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        Log.w(TAG, "pingBinder failed", e)
        false
    }

    /** True when Shizuku is running and this app is allowed in it. Never throws. */
    fun hasPermission(): Boolean = try {
        isAvailable() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        Log.w(TAG, "checkSelfPermission failed", e)
        false
    }

    /**
     * Asks Shizuku to show its allow prompt. If the user denied this app before, Shizuku may show
     * no prompt at all. The answer arrives in the listener on the Tweaks screen.
     */
    fun requestPermission() {
        try {
            if (isAvailable()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            Log.w(TAG, "requestPermission failed", e)
        }
    }

    /** A plain-language reason for the user, based on the current state. */
    fun explain(): String = when {
        !isAvailable() -> "Shizuku is not running. Open Shizuku, start it, then try again."
        !hasPermission() -> "Shizuku is running but has not allowed Battery Optimizer. Allow it in Shizuku, then try again."
        else -> lastError ?: "Shizuku allowed this app, but the change did not apply. Use Open permission screen."
    }

    /**
     * Grants this app WRITE_SETTINGS through Shizuku's shell. Returns true only when the command
     * exits with code 0 and Android then reports that the app can write settings.
     */
    fun grantWriteSettings(context: Context): Boolean {
        lastError = null
        if (!hasPermission()) return false
        val result = exec(arrayOf("appops", "set", context.packageName, "WRITE_SETTINGS", "allow"))
        val granted = result != null && result.exitCode == 0 && Settings.System.canWrite(context)
        if (!granted) {
            lastError = when {
                result == null -> "This Shizuku version did not run the grant command. Use Open permission screen."
                result.exitCode != 0 -> "The grant command failed with code ${result.exitCode}. Use Open permission screen."
                else -> "The grant command ran, but Android still reports no permission. Use Open permission screen."
            }
            Log.w(TAG, "WRITE_SETTINGS grant failed: $lastError")
        }
        return granted
    }

    /**
     * Sets background restriction (RUN_ANY_IN_BACKGROUND) for one app, then reads it back.
     * Returns true only when Android reports the requested state. Never force-stops anything.
     */
    fun setBackgroundRestricted(pkg: String, restricted: Boolean): Boolean {
        lastError = null
        if (!hasPermission()) {
            lastError = "Shizuku is not connected."
            return false
        }
        val mode = if (restricted) "ignore" else "allow"
        val result = exec(arrayOf("cmd", "appops", "set", pkg, RESTRICT_OP, mode))
        if (result == null) {
            lastError = "Shizuku did not run the command for this app."
            return false
        }
        if (result.exitCode != 0) {
            lastError = "The command failed with code ${result.exitCode}: ${result.output}"
            Log.w(TAG, "set $pkg restricted=$restricted: $lastError")
            return false
        }
        val now = readBackgroundRestricted(pkg)
        if (now != restricted) {
            lastError = "Android reports the restriction as ${now ?: "unknown"}."
            Log.w(TAG, "readback for $pkg did not match: $lastError")
            return false
        }
        return true
    }

    /** Reads the background restriction for one app. Null when it cannot be read. */
    fun readBackgroundRestricted(pkg: String): Boolean? {
        val result = exec(arrayOf("cmd", "appops", "get", pkg, RESTRICT_OP)) ?: return null
        if (result.exitCode != 0) return null
        return when {
            result.output.contains("ignore") -> true
            // "default" means no override is set, so the app runs in the background normally.
            result.output.contains("allow") || result.output.contains("default") -> false
            else -> null
        }
    }

    /**
     * Runs one command in Shizuku's shell and returns its exit code and output. Null if Shizuku
     * cannot run it. Shizuku.newProcess is not public in every version, so it is called by reflection.
     */
    private fun exec(command: Array<String>): ShellResult? = try {
        val method = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
        )
        method.isAccessible = true
        val process = method.invoke(null, command, null, null) as Process
        val output = process.inputStream.bufferedReader().use { it.readText() }.trim()
        ShellResult(process.waitFor(), output)
    } catch (e: Throwable) {
        Log.w(TAG, "Shizuku shell failed: ${command.joinToString(" ")}", e)
        null
    }
}
