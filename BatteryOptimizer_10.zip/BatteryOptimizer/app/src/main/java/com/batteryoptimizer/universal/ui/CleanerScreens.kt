package com.batteryoptimizer.universal.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.batteryoptimizer.universal.data.AppEntry
import com.batteryoptimizer.universal.data.ApplyOutcome
import com.batteryoptimizer.universal.data.BackgroundCleaner
import com.batteryoptimizer.universal.data.ScanResult
import com.batteryoptimizer.universal.data.ScanStage
import com.batteryoptimizer.universal.data.ShizukuGrant
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * CLEAN ALL BACKGROUND flow. A scan runs the real stages in order. Results appear only after the scan
 * has finished. Nothing is restricted until the user picks apps and confirms.
 */
@Composable
fun CleanAllBackgroundScreen(onOpenShizukuSetup: () -> Unit, onOpenAppMonitor: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val connected by ShizukuGrant.connected.collectAsState()
    var scanning by remember { mutableStateOf(false) }
    var stage by remember { mutableStateOf<ScanStage?>(null) }
    var result by remember { mutableStateOf<ScanResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var applying by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    var outcomes by remember { mutableStateOf<List<ApplyOutcome>>(emptyList()) }

    fun startScan() {
        scanning = true
        stage = null
        result = null
        error = null
        outcomes = emptyList()
        selected = emptySet()
        scope.launch {
            try {
                result = BackgroundCleaner.scan(context) { stage = it }
            } catch (e: Exception) {
                error = "The scan stopped early (${e.javaClass.simpleName}). Nothing was changed."
            } finally {
                scanning = false
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (!connected && !scanning) {
            PremiumCard {
                Text("Shizuku is not connected", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(
                    "You can still scan. Restricting apps needs Shizuku connected.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                OutlinedButton(onClick = onOpenShizukuSetup, modifier = Modifier.fillMaxWidth()) {
                    Text("SHIZUKU SETUP")
                }
            }
        }

        when {
            scanning -> ScanLoading(stage)

            result != null -> {
                val current = result!!
                val candidates = (current.highActivity + current.recommended).distinctBy { it.packageName }
                val chosen = candidates.filter { it.packageName in selected }

                PremiumCard {
                    Text("Scan results", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    InfoRow("Apps scanned", current.entries.size.toString())
                    InfoRow("Scanned at", timeText(current.scannedAt))
                    InfoRow("Usage access", if (current.usageAccess) "On" else "Off")
                    InfoRow("Shizuku", if (current.shizukuConnected) "Connected" else "Not connected")
                }

                PremiumCard {
                    Text("High background activity", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    if (current.highActivity.isEmpty()) {
                        Text(
                            if (current.usageAccess) "No third-party app had screen time in the last 24 hours."
                            else "Turn on usage access to see which apps are active.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    } else {
                        current.highActivity.forEach { app ->
                            Text("${app.label}: ${app.foregroundMinutes ?: 0} min in 24 hours", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                PremiumCard {
                    Text("Apps you can restrict", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(
                        "Pick the apps to restrict. Nothing changes until you confirm. " +
                            "System apps and essential services are never listed.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (candidates.isEmpty()) {
                        Text("No apps need restriction right now.", style = MaterialTheme.typography.bodyMedium)
                    }
                    candidates.forEach { app ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = app.packageName in selected,
                                onCheckedChange = { on ->
                                    selected = if (on) selected + app.packageName else selected - app.packageName
                                },
                                enabled = connected && !applying,
                            )
                            Column(Modifier.weight(1f)) {
                                Text(app.label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                                Text(appLine(app), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    Button(
                        onClick = { confirm = true },
                        enabled = connected && chosen.isNotEmpty() && !applying,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = greenButtonColors(),
                    ) {
                        Text(
                            if (applying) "APPLYING..." else "RESTRICT SELECTED (${chosen.size})",
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }

                if (outcomes.isNotEmpty()) {
                    PremiumCard {
                        Text("Optimization results", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        outcomes.forEach { o ->
                            Text("${o.label}: ${o.message}", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                PremiumCard {
                    Text("Supported on this device", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    current.supported.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
                    Text("Not supported", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    current.unsupported.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
                }

                OutlinedButton(
                    onClick = {
                        applying = true
                        scope.launch {
                            outcomes = BackgroundCleaner.restoreAll(context)
                            applying = false
                        }
                    },
                    enabled = connected && !applying,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text("RESTORE RESTRICTED APPS") }

                OutlinedButton(onClick = { startScan() }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("SCAN AGAIN")
                }
                OutlinedButton(onClick = onOpenAppMonitor, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("APP MONITOR")
                }

                if (confirm) {
                    AlertDialog(
                        onDismissRequest = { confirm = false },
                        title = { Text("Restrict ${chosen.size} app(s)?") },
                        text = {
                            Text(
                                "Android will stop these apps from running in the background. " +
                                    "No app is force-stopped. Use RESTORE RESTRICTED APPS to undo it.",
                            )
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                confirm = false
                                applying = true
                                scope.launch {
                                    outcomes = BackgroundCleaner.restrict(context, chosen)
                                    applying = false
                                }
                            }) { Text("RESTRICT") }
                        },
                        dismissButton = {
                            TextButton(onClick = { confirm = false }) { Text("CANCEL") }
                        },
                    )
                }
            }

            else -> {
                PremiumCard {
                    Text("Clean all background", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Scans installed apps and shows what Android lets this app restrict. " +
                            "Nothing changes until you pick apps and confirm.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                error?.let { text -> PremiumCard { Text(text, style = MaterialTheme.typography.bodyMedium) } }
                Button(
                    onClick = { startScan() },
                    modifier = Modifier.fillMaxWidth().height(84.dp),
                    colors = greenButtonColors(),
                ) { Text("CLEAN ALL BACKGROUND", fontWeight = FontWeight.Bold) }
                OutlinedButton(onClick = onOpenAppMonitor, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("APP MONITOR")
                }
            }
        }
    }
}

/**
 * App list with per-app details. Only Android-readable facts are shown. Battery use per app and
 * other apps' services are not available to apps, and the screen says so.
 */
@Composable
fun AppMonitorScreen(onOpenShizukuSetup: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val connected by ShizukuGrant.connected.collectAsState()
    var scanning by remember { mutableStateOf(false) }
    var stage by remember { mutableStateOf<ScanStage?>(null) }
    var scan by remember { mutableStateOf<ScanResult?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var showSystem by remember { mutableStateOf(false) }

    fun runScan() {
        scanning = true
        message = null
        scope.launch {
            try {
                scan = BackgroundCleaner.scan(context) { stage = it }
            } catch (e: Exception) {
                message = "The scan stopped early. Nothing was changed."
            } finally {
                scanning = false
            }
        }
    }

    val shown = scan?.entries.orEmpty().filter { showSystem || !it.system }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
    ) {
        item {
            PremiumCard {
                Text("App monitor", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Battery use per app and other apps' services are not available to apps on Android. " +
                        "Screen time and background restriction are shown when Android allows them.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text(
                    scan?.let { "Last scan: ${timeText(it.scannedAt)}" } ?: "Not scanned yet",
                    style = MaterialTheme.typography.bodyMedium,
                )
                message?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                Button(
                    onClick = { runScan() },
                    enabled = !scanning,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = greenButtonColors(),
                ) { Text(if (scan == null) "SCAN APPS" else "REFRESH", fontWeight = FontWeight.Bold) }
                OutlinedButton(onClick = { showSystem = !showSystem }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (showSystem) "HIDE SYSTEM APPS" else "SHOW SYSTEM APPS")
                }
                if (!connected) {
                    OutlinedButton(onClick = onOpenShizukuSetup, modifier = Modifier.fillMaxWidth()) {
                        Text("SHIZUKU SETUP")
                    }
                }
            }
        }

        if (scanning) {
            item { PremiumCard { ScanLoading(stage) } }
        } else if (scan == null) {
            item {
                Text("Tap SCAN APPS to load the app list.", style = MaterialTheme.typography.bodyMedium)
            }
        }

        items(shown, key = { it.packageName }) { app ->
            AppMonitorRow(
                app = app,
                connected = connected,
                onChanged = { updated ->
                    scan = scan?.let { s ->
                        s.copy(entries = s.entries.map { if (it.packageName == updated.packageName) updated else it })
                    }
                },
                onMessage = { message = it },
            )
        }
    }
}

@Composable
private fun AppMonitorRow(
    app: AppEntry,
    connected: Boolean,
    onChanged: (AppEntry) -> Unit,
    onMessage: (String) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val protected = app.system || app.essential
    PremiumCard {
        Text(app.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Text(app.packageName, style = MaterialTheme.typography.bodySmall)
        InfoRow("Type", when {
            app.essential -> "Essential (protected)"
            app.system -> "System (protected)"
            else -> "Installed app"
        })
        InfoRow("Background", when (app.restricted) {
            true -> "Restricted"
            false -> "Allowed"
            null -> if (connected) "Not read" else "Needs Shizuku to read"
        })
        InfoRow("Screen time (24h)", app.foregroundMinutes?.let { "$it min" } ?: "Usage access off")
        InfoRow("Last used", lastUsedText(app.daysSinceUsed))
        InfoRow("Battery use", "Not available to apps")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { openSafely(context, appDetailsIntent(app.packageName)) }) {
                Text("APP DETAILS")
            }
            Button(
                onClick = {
                    scope.launch {
                        val outcome = BackgroundCleaner.setRestriction(context, app, app.restricted != true)
                        onChanged(app.copy(restricted = outcome.restricted))
                        onMessage("${app.label}: ${outcome.message}")
                    }
                },
                enabled = connected && !protected,
            ) {
                Text(if (app.restricted == true) "ALLOW BACKGROUND" else "RESTRICT BACKGROUND")
            }
        }
    }
}

/**
 * Animated battery and the real stage list. The bar advances only when a stage has finished,
 * so it never shows progress that has not happened.
 */
@Composable
private fun ScanLoading(stage: ScanStage?) {
    val pulse by rememberInfiniteTransition(label = "battery").animateFloat(
        initialValue = 0.9f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(animation = tween(900), repeatMode = RepeatMode.Reverse),
        label = "pulse",
    )
    val finished = stage?.ordinal ?: 0
    val target = finished.toFloat() / ScanStage.entries.size
    val progress by animateFloatAsState(targetValue = target, animationSpec = tween(400), label = "progress")

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(
            Icons.Filled.BatteryFull,
            contentDescription = null,
            tint = BatteryGreen,
            modifier = Modifier
                .size(88.dp)
                .align(Alignment.CenterHorizontally)
                .graphicsLayer { scaleX = pulse; scaleY = pulse },
        )
        Text(
            "${(progress * 100).toInt()}%",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = BatteryGreen)
        Text(stage?.label ?: "Starting", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
        ScanStage.entries.forEach { s ->
            val mark = when {
                stage == null -> "○"
                s.ordinal < stage.ordinal -> "✓"
                s == stage -> "…"
                else -> "○"
            }
            Text("$mark  ${s.label}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun appLine(app: AppEntry): String {
    val screen = app.foregroundMinutes?.let { "$it min in 24 h" } ?: "screen time unavailable"
    val restriction = when (app.restricted) {
        true -> "restricted"
        false -> "allowed"
        null -> "background state not read"
    }
    return "$screen · $restriction"
}

private fun lastUsedText(days: Long?): String = when (days) {
    null -> "Not recorded"
    0L -> "Today"
    1L -> "1 day ago"
    else -> "$days days ago"
}

private fun timeText(millis: Long): String =
    SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(millis))
