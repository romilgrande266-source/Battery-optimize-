package com.batteryoptimizer.universal.data

import android.content.ContentResolver
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.location.LocationManager
import android.os.Build
import android.provider.Settings
import android.view.WindowManager

private const val NS = "Not Supported"
// Shown when Android does not give the value, but the tip and the settings shortcut still apply.
private const val GUIDANCE = "Guidance"
private const val POWER_USAGE = "android.intent.action.POWER_USAGE_SUMMARY"
private const val LOW_BRIGHTNESS = 102          // about 40% of the 0–255 range
private const val SHORT_TIMEOUT_MS = 30_000

/** Changes this app can make itself, only with the user's permission and only when they tap the button. */
enum class InAppChange { LOWER_BRIGHTNESS, SHORTER_TIMEOUT, ULTRA_MODE }

data class Tweak(
    val number: Int,
    val title: String,
    val value: String,
    val advice: String,
    val action: String? = null,
    val change: InAppChange? = null,
) {
    val supported: Boolean get() = value != NS
}

/** Builds the 20 tweaks from values Android reports on this device. Nothing is estimated. */
fun buildTweaks(context: Context, battery: BatteryInfo): List<Tweak> {
    val pm = context.packageManager
    val brightness = systemInt(context, Settings.System.SCREEN_BRIGHTNESS)
    val brightnessAuto = systemInt(context, Settings.System.SCREEN_BRIGHTNESS_MODE) == 1
    val timeout = systemInt(context, Settings.System.SCREEN_OFF_TIMEOUT)
    val haptic = systemInt(context, Settings.System.HAPTIC_FEEDBACK_ENABLED)?.let { it == 1 }
    val adaptive = globalInt(context, "adaptive_battery_management_enabled")?.let { it == 1 }
    val alwaysOn = secureInt(context, "doze_always_on")?.let { it == 1 }
    val dark = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    val rates = refreshRates(context)
    // Every platform call below is wrapped. Some phones refuse these reads with a SecurityException
    // (missing permission or OEM restriction). That must show "Not Supported", never close the app.
    val locationOn: Boolean? = if (Build.VERSION.SDK_INT >= 28) {
        safe { context.getSystemService(LocationManager::class.java)?.isLocationEnabled }
    } else {
        null
    }
    // WifiManager.isScanAlwaysAvailable needs ACCESS_WIFI_STATE, which this app does not request.
    // The same value is stored in Settings.Global and can be read without any permission.
    val scanAlways: Boolean? = globalInt(context, "wifi_scan_always_enabled")?.let { it == 1 }
    // Reading master sync needs READ_SYNC_SETTINGS, which this app does not request.
    // When Android refuses, the card falls back to guidance instead of crashing.
    val syncOn: Boolean? = safe { ContentResolver.getMasterSyncAutomatically() }
    val ultraRecommended = battery.percent != null && battery.percent <= 15 && !battery.isCharging
    val temp = battery.temperatureC

    return listOf(
        Tweak(
            number = 1,
            title = "Smart Screen Brightness",
            value = brightness?.let { "${it * 100 / 255}%" + if (brightnessAuto) " (auto)" else "" } ?: GUIDANCE,
            advice = "Use adaptive brightness, or set brightness to 60% or lower. Lower brightness uses less power.",
            action = Settings.ACTION_DISPLAY_SETTINGS,
            change = if (brightness != null) InAppChange.LOWER_BRIGHTNESS else null,
        ),
        Tweak(
            number = 2,
            title = "Screen Timeout",
            value = timeout?.let { "${it / 1000} seconds" } ?: GUIDANCE,
            advice = "Use 30 to 60 seconds so the screen turns off sooner when you stop using it.",
            action = Settings.ACTION_DISPLAY_SETTINGS,
            change = if (timeout != null) InAppChange.SHORTER_TIMEOUT else null,
        ),
        Tweak(
            number = 3,
            title = "Background App Battery Usage",
            value = "Available",
            advice = "Open battery usage to see which apps used the most power recently. Restrict apps you rarely use.",
            action = POWER_USAGE,
        ),
        Tweak(
            number = 4,
            title = "Unnecessary Background Activity",
            value = "Guidance",
            advice = "Turn off battery optimization exceptions for apps you rarely open.",
            action = Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS,
        ),
        Tweak(
            number = 5,
            title = "Adaptive Battery",
            value = onOffOrGuidance(adaptive),
            advice = "Keep Adaptive Battery on. It limits apps you rarely use.",
            action = Settings.ACTION_BATTERY_SAVER_SETTINGS,
        ),
        Tweak(
            number = 6,
            title = "Dark Mode",
            value = if (dark) "On" else "Off",
            advice = "Dark mode uses less power on OLED or AMOLED screens. On LCD screens the saving is small.",
            action = Settings.ACTION_DISPLAY_SETTINGS,
        ),
        Tweak(
            number = 7,
            title = "Refresh Rate",
            value = if (rates.size > 1) rates.joinToString(", ") { "${it.toInt()} Hz" } else GUIDANCE,
            advice = "Use a lower refresh rate or adaptive mode when you do not need smooth motion.",
            action = Settings.ACTION_DISPLAY_SETTINGS,
        ),
        Tweak(
            number = 8,
            title = "Location Usage",
            value = onOffOrGuidance(locationOn),
            advice = "Set location to \"While using the app\" for apps that do not need it all the time.",
            action = Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        ),
        Tweak(
            number = 9,
            title = "Bluetooth Power Saving",
            value = availability(pm, PackageManager.FEATURE_BLUETOOTH),
            advice = "Turn Bluetooth off when you are not connected to a device.",
            action = Settings.ACTION_BLUETOOTH_SETTINGS,
        ),
        Tweak(
            number = 10,
            title = "Wi-Fi Scanning",
            value = onOffOrGuidance(scanAlways),
            advice = "Turn off Wi-Fi scanning when you do not need location-based scanning.",
            action = Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        ),
        Tweak(
            number = 11,
            title = "Mobile Data Usage",
            value = availability(pm, PackageManager.FEATURE_TELEPHONY),
            advice = "Turn off mobile data when Wi-Fi is available and you do not need it. Check data usage limits.",
            action = Settings.ACTION_WIRELESS_SETTINGS,
        ),
        Tweak(
            number = 12,
            title = "Hotspot Power Saving",
            value = availability(pm, PackageManager.FEATURE_WIFI),
            advice = "Turn off the hotspot when you are not sharing. It keeps Wi-Fi and the radio active.",
            action = Settings.ACTION_WIRELESS_SETTINGS,
        ),
        Tweak(
            number = 13,
            title = "NFC Usage",
            value = availability(pm, PackageManager.FEATURE_NFC),
            advice = "Turn NFC off if you do not use contactless payments or tags.",
            action = Settings.ACTION_NFC_SETTINGS,
        ),
        Tweak(
            number = 14,
            title = "Always-On Display",
            value = onOffOrGuidance(alwaysOn),
            advice = "Turn off Always-On Display, or set a schedule, to reduce constant screen use.",
            action = Settings.ACTION_DISPLAY_SETTINGS,
        ),
        Tweak(
            number = 15,
            title = "Haptic Feedback",
            value = onOffOrGuidance(haptic),
            advice = "Lower or turn off haptic feedback for touches.",
            action = Settings.ACTION_SOUND_SETTINGS,
        ),
        Tweak(
            number = 16,
            title = "Keyboard Vibration",
            value = "Guidance",
            advice = "Turn off key vibration in your keyboard app's settings. This setting is not part of Android.",
            action = Settings.ACTION_INPUT_METHOD_SETTINGS,
        ),
        Tweak(
            number = 17,
            title = "Notification Wake-up Reduction",
            value = "Guidance",
            advice = "Turn off wake-up for apps that send unimportant notifications. Use Do Not Disturb at night.",
            action = Settings.ACTION_SOUND_SETTINGS,
        ),
        Tweak(
            number = 18,
            title = "Auto-Sync",
            value = syncOn?.let { onOff(it) } ?: "Guidance",
            advice = "Turn off auto-sync for apps that do not need background updates. This app cannot change sync settings.",
            action = Settings.ACTION_SYNC_SETTINGS,
        ),
        Tweak(
            number = 19,
            title = "Battery Temperature",
            value = temp?.let { "%.1f °C".format(it) } ?: NS,
            advice = "Warning at 40 °C, critical at 45 °C. Pause heavy use or charging when the phone is hot.",
        ),
        Tweak(
            number = 20,
            title = "Smart Ultra Battery Saver",
            value = if (ultraRecommended) "Recommended now" else "Not needed yet",
            advice = "Switch to Ultra Battery Saver when the battery is at 15% or lower and not charging.",
            change = InAppChange.ULTRA_MODE,
        ),
    )
}

/** Applies and restores only the two system values this app can change, with the user's permission. */
object TweakBackup {
    private const val PREFS = "tweak_backup"
    private const val KEY_BRIGHTNESS = "brightness"
    private const val KEY_BRIGHTNESS_MODE = "brightness_mode"
    private const val KEY_TIMEOUT = "timeout"
    private const val UNSET = -1

    fun canWrite(context: Context): Boolean = Settings.System.canWrite(context)

    /** Saves the original value the first time, then applies the change. */
    fun applyChange(context: Context, change: InAppChange): Boolean {
        if (!canWrite(context)) return false
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val cr = context.contentResolver
        return try {
            when (change) {
                InAppChange.LOWER_BRIGHTNESS -> {
                    saveOnce(prefs, KEY_BRIGHTNESS, systemInt(context, Settings.System.SCREEN_BRIGHTNESS))
                    saveOnce(prefs, KEY_BRIGHTNESS_MODE, systemInt(context, Settings.System.SCREEN_BRIGHTNESS_MODE))
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0) &&
                        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, LOW_BRIGHTNESS)
                }
                InAppChange.SHORTER_TIMEOUT -> {
                    saveOnce(prefs, KEY_TIMEOUT, systemInt(context, Settings.System.SCREEN_OFF_TIMEOUT))
                    Settings.System.putInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, SHORT_TIMEOUT_MS)
                }
                InAppChange.ULTRA_MODE -> false
            }
        } catch (e: SecurityException) {
            false
        }
    }

    /** Puts back the values saved before this app changed them. Returns false if permission is missing. */
    fun restoreSystemSettings(context: Context): Boolean {
        if (!canWrite(context)) return false
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val cr = context.contentResolver
        return try {
            prefs.getInt(KEY_BRIGHTNESS_MODE, UNSET).takeIf { it != UNSET }
                ?.let { Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, it) }
            prefs.getInt(KEY_BRIGHTNESS, UNSET).takeIf { it != UNSET }
                ?.let { Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, it) }
            prefs.getInt(KEY_TIMEOUT, UNSET).takeIf { it != UNSET }
                ?.let { Settings.System.putInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, it) }
            prefs.edit().clear().apply()
            true
        } catch (e: SecurityException) {
            false
        }
    }

    private fun saveOnce(prefs: SharedPreferences, key: String, value: Int?) {
        if (!prefs.contains(key)) prefs.edit().putInt(key, value ?: UNSET).apply()
    }
}

/** Changes a setting, then reads it back. Returns true only when Android reports the new value. */
fun verifiedApply(context: Context, change: InAppChange): Boolean {
    if (!TweakBackup.applyChange(context, change)) return false
    return when (change) {
        InAppChange.LOWER_BRIGHTNESS ->
            (systemInt(context, Settings.System.SCREEN_BRIGHTNESS) ?: 999) <= 110 &&
                systemInt(context, Settings.System.SCREEN_BRIGHTNESS_MODE) == 0
        InAppChange.SHORTER_TIMEOUT ->
            systemInt(context, Settings.System.SCREEN_OFF_TIMEOUT) == 30_000
        InAppChange.ULTRA_MODE -> false
    }
}

private fun onOffOrGuidance(value: Boolean?): String = when (value) {
    true -> "On"
    false -> "Off"
    null -> GUIDANCE
}

private fun onOff(value: Boolean?): String = when (value) {
    true -> "On"
    false -> "Off"
    null -> NS
}

private fun availability(pm: PackageManager, feature: String): String =
    if (pm.hasSystemFeature(feature)) "Available" else NS

/** Runs a platform read and returns null if Android throws (SecurityException, OEM quirks, missing service). */
private inline fun <T> safe(block: () -> T?): T? = try {
    block()
} catch (e: Exception) {
    null
}

internal fun systemInt(context: Context, name: String): Int? =
    safe { Settings.System.getInt(context.contentResolver, name) }

private fun secureInt(context: Context, name: String): Int? =
    safe { Settings.Secure.getInt(context.contentResolver, name) }

private fun globalInt(context: Context, name: String): Int? =
    safe { Settings.Global.getInt(context.contentResolver, name) }

@Suppress("DEPRECATION")
private fun refreshRates(context: Context): List<Float> = try {
    context.getSystemService(WindowManager::class.java).defaultDisplay.supportedRefreshRates.toList()
} catch (e: Exception) {
    emptyList()
}
