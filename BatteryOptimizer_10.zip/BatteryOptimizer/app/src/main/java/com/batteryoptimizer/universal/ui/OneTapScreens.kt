package com.batteryoptimizer.universal.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.batteryoptimizer.universal.data.AppUsage
import com.batteryoptimizer.universal.data.BackgroundCleanup
import com.batteryoptimizer.universal.data.CheckResult
import com.batteryoptimizer.universal.data.OneTapReport
import com.batteryoptimizer.universal.data.toShareText

/** Green filled button used for the main actions. */
@Composable
fun greenButtonColors(): ButtonColors = ButtonDefaults.buttonColors(
    containerColor = BatteryGreen,
    contentColor = Color.Black,
    disabledContainerColor = BatteryGreen,
    disabledContentColor = Color.Black,
)

@Composable
fun OneTapReportScreen(report: OneTapReport, onOpenScreenPermission: () -> Unit) {
    val context = LocalContext.current
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PremiumCard {
            Text(
                report.optimizationStatus,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BatteryGreen,
            )
            Text(
                "Battery: ${report.percent?.let { "$it%" } ?: NOT_SUPPORTED}",
                style = MaterialTheme.typography.bodyLarge,
            )
            Text(
                "Temperature: ${report.temperatureC?.let { "%.1f °C".format(it) } ?: NOT_SUPPORTED}",
                style = MaterialTheme.typography.bodyLarge,
            )
        }

        if (report.screenPermissionNeeded) {
            Button(
                onClick = onOpenScreenPermission,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = greenButtonColors(),
            ) { Text("ALLOW SCREEN CHANGES", fontWeight = FontWeight.Bold) }
        }
        OutlinedButton(onClick = { shareReport(context, report) }, modifier = Modifier.fillMaxWidth()) {
            Text("SHARE REPORT")
        }

        ReportSection("Completed optimizations", report.completed, "None. Android did not confirm any change.")
        ReportSection("Recommendations", report.recommendations, "No recommendations right now.")
        ReportSection("Unsupported on this device", report.unsupported, "Nothing unsupported.")
        AttentionSection(report.attention, report.usageAccess)
        ReportSection("Looks good", report.goodChecks, "Nothing to show yet.")
    }
}

@Composable
private fun ReportSection(title: String, items: List<CheckResult>, emptyText: String) {
    PremiumCard {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (items.isEmpty()) {
            Text(emptyText, style = MaterialTheme.typography.bodyMedium)
        }
        items.forEach { item ->
            Text(
                "• ${item.title}: ${item.value}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
            )
            item.detail?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun AttentionSection(apps: List<AppUsage>, usageAccess: Boolean) {
    PremiumCard {
        Text("Apps needing your attention", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (apps.isEmpty()) {
            Text(
                if (usageAccess) "No app stands out." else "Allow usage access to see which apps were active.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        apps.forEach { app ->
            Text(
                "• ${app.label}: ${app.foregroundMinutes} min screen time in 24 h",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        Text(
            "Android does not share per-app battery numbers with apps. These minutes are screen time, not battery use.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

internal fun appDetailsIntent(pkg: String): Intent =
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null))

/** Shares the report as plain text. The user chooses where it goes. */
fun shareReport(context: Context, report: OneTapReport) {
    val send = Intent(Intent.ACTION_SEND)
        .setType("text/plain")
        .putExtra(Intent.EXTRA_TEXT, report.toShareText())
    openSafely(context, Intent.createChooser(send, "Share report"))
}

/** Opens the screen where the user allows this app to change brightness and timeout. */
fun openScreenPermission(context: Context) {
    openSafely(context, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}")))
}

fun openSafely(context: Context, intent: Intent) {
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        context.startActivity(Intent(Settings.ACTION_SETTINGS))
    }
}
