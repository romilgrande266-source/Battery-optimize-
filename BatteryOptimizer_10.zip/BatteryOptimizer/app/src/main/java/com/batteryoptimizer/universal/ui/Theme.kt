package com.batteryoptimizer.universal.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Neon green used for battery indicators, charts and primary accents. */
val BatteryGreen = Color(0xFF39FF88)

private val DarkColors = darkColorScheme(
    primary = BatteryGreen,
    onPrimary = Color(0xFF002912),
    primaryContainer = Color(0xFF0B3D22),
    onPrimaryContainer = Color(0xFFB9FFD3),
    secondary = Color(0xFF8FD6AE),
    onSecondary = Color(0xFF00210F),
    background = Color(0xFF000000),
    onBackground = Color(0xFFE6F5EC),
    surface = Color(0xFF0A130E),
    onSurface = Color(0xFFE6F5EC),
    surfaceVariant = Color(0xFF13241A),
    onSurfaceVariant = Color(0xFFA9C7B5),
    outline = Color(0xFF355443),
    error = Color(0xFFFFB4AB),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF137A43),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB9FFD3),
    onPrimaryContainer = Color(0xFF00210F),
    secondary = Color(0xFF4B6356),
    background = Color(0xFFF4FBF6),
    onBackground = Color(0xFF0F1D15),
    surface = Color.White,
    onSurface = Color(0xFF0F1D15),
    surfaceVariant = Color(0xFFDDEDE3),
    onSurfaceVariant = Color(0xFF3F5246),
    outline = Color(0xFF6F8577),
    error = Color(0xFFBA1A1A),
)

/** themeMode: 0 = automatic (follow phone), 1 = dark, 2 = light */
@Composable
fun BatteryOptimizerTheme(themeMode: Int = 0, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        1 -> true
        2 -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
