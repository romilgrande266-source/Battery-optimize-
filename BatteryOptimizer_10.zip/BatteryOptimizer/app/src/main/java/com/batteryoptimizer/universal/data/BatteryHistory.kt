package com.batteryoptimizer.universal.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class BatterySample(
    val timeMs: Long,
    val percent: Int,
    val temperatureC: Double?,
    val charging: Boolean = false,
)

/**
 * In-memory history only. Samples exist while the app is open, are kept at most once per minute,
 * and are never written to disk or sent anywhere.
 */
object BatteryHistory {
    private const val MAX_SAMPLES = 120
    private const val MIN_INTERVAL_MS = 60_000L
    private const val MIN_MEASURE_MS = 10 * 60_000L

    private val _samples = MutableStateFlow<List<BatterySample>>(emptyList())
    val samples: StateFlow<List<BatterySample>> = _samples.asStateFlow()

    fun record(info: BatteryInfo) {
        val percent = info.percent ?: return
        val now = System.currentTimeMillis()
        val current = _samples.value
        if (current.isNotEmpty() && now - current.last().timeMs < MIN_INTERVAL_MS) return
        _samples.value = (current + BatterySample(now, percent, info.temperatureC, info.isCharging))
            .takeLast(MAX_SAMPLES)
    }

    /** Measured discharge rate since the last charging session, in % per hour. Null if not enough data. */
    fun drainPerHour(): Double? {
        val list = _samples.value
        val start = list.indexOfLast { it.charging } + 1
        val run = list.subList(start, list.size)
        if (run.size < 2) return null
        val elapsed = run.last().timeMs - run.first().timeMs
        if (elapsed < MIN_MEASURE_MS) return null
        val drop = run.first().percent - run.last().percent
        return maxOf(0.0, drop * 3_600_000.0 / elapsed)
    }
}
