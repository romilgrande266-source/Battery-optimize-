package com.batteryoptimizer.universal.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.batteryoptimizer.universal.data.ShizukuGrant

/**
 * Shows whether Shizuku is installed, running, and allowed for this app. It updates by itself when
 * Shizuku stops or starts. Everything else in the app works without it.
 */
@Composable
fun ShizukuSetupScreen() {
    val context = LocalContext.current
    val connected by ShizukuGrant.connected.collectAsState()
    var refreshes by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    val installed = remember(refreshes) { ShizukuGrant.isInstalled(context) }
    val running = remember(refreshes, connected) { ShizukuGrant.isAvailable() }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PremiumCard {
            Text("Shizuku setup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Shizuku lets this app use a few extra Android features without root. " +
                    "Everything else in the app works without Shizuku.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        PremiumCard {
            Text("Connection status", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            InfoRow("Shizuku app installed", yesNo(installed))
            InfoRow("Shizuku service running", yesNo(running))
            InfoRow("Allowed for Battery Optimizer", yesNo(connected))
            Text(statusText(installed, running, connected), style = MaterialTheme.typography.bodyMedium)
        }

        Button(
            onClick = {
                when {
                    !installed -> { openSafely(context, Intent(Intent.ACTION_VIEW, Uri.parse(ShizukuGrant.DOWNLOAD_URL))) }
                    !running -> { message = "Shizuku is not running. Follow the steps below, start it, then tap CONNECT SHIZUKU again." }
                    connected -> { message = "Already connected." }
                    else -> {
                        ShizukuGrant.requestPermission()
                        message = "Shizuku prompt sent. Allow Battery Optimizer in Shizuku."
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(60.dp),
            colors = greenButtonColors(),
        ) {
            Text(if (installed) "CONNECT SHIZUKU" else "GET SHIZUKU", fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
            onClick = { openShizuku(context) },
            modifier = Modifier.fillMaxWidth().height(56.dp),
        ) {
            Text("START SHIZUKU GUIDE", fontWeight = FontWeight.SemiBold)
        }

        OutlinedButton(
            onClick = {
                refreshes++
                ShizukuGrant.refresh()
                message = if (ShizukuGrant.hasPermission()) {
                    "Reconnected."
                } else {
                    "Not connected yet. Start Shizuku, then tap RECONNECT."
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
        ) {
            Text("RECONNECT", fontWeight = FontWeight.SemiBold)
        }

        message?.let { text ->
            PremiumCard { Text(text, style = MaterialTheme.typography.bodyMedium) }
        }

        PremiumCard {
            Text("Wireless Debugging (Android 11 and newer)", style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold)
            Text(
                "1. Settings > Developer options > turn on Wireless debugging.\n" +
                    "2. Tap Pair device with pairing code and enter the code in Shizuku.\n" +
                    "3. Open Shizuku and tap Start.\n" +
                    "4. Come back here and tap RECONNECT.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        PremiumCard {
            Text("USB Debugging", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Turn on USB debugging in Developer options, connect the phone to a computer, then follow " +
                    "the USB section of the Shizuku guide. Tap START SHIZUKU GUIDE to open the app.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        PremiumCard {
            Text("If Shizuku stops", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Shizuku usually stops after a restart. Start it again, then tap RECONNECT. " +
                    "Battery Optimizer keeps working without it.",
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

private fun yesNo(value: Boolean): String = if (value) "Yes" else "No"

private fun statusText(installed: Boolean, running: Boolean, connected: Boolean): String = when {
    !installed -> "Shizuku is not installed. Tap GET SHIZUKU to download it."
    !running -> "Shizuku is installed but not running. Start it using the steps below."
    !connected -> "Shizuku is running. Tap CONNECT SHIZUKU and allow Battery Optimizer."
    else -> "Connected. Advanced features are available."
}

/** Opens the Shizuku app if it is installed, otherwise its download page. */
private fun openShizuku(context: Context) {
    val launch = context.packageManager.getLaunchIntentForPackage(ShizukuGrant.SHIZUKU_PACKAGE)
    openSafely(context, launch ?: Intent(Intent.ACTION_VIEW, Uri.parse(ShizukuGrant.DOWNLOAD_URL)))
}
