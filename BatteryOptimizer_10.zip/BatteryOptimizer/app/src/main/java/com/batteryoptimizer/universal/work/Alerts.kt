package com.batteryoptimizer.universal.work

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ListenableWorker.Result
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.batteryoptimizer.universal.data.AppPrefs
import com.batteryoptimizer.universal.data.BatteryRepository
import com.batteryoptimizer.universal.data.UiPrefs
import com.batteryoptimizer.universal.notify.Notifications
import java.util.concurrent.TimeUnit

/**
 * Periodic check (about every 15 minutes, the WorkManager minimum) that runs only when the user
 * has turned on background alerts. It is not a foreground service and nothing runs when alerts are off.
 */
class AlertWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val prefs = AppPrefs(ctx)
        if (!prefs.alertsEnabled) return Result.success()

        val info = BatteryRepository.read(ctx)
        val level = info.percent

        if (level != null) {
            // Low battery: notify once per drop, re-arm after the level recovers.
            if (UiPrefs(ctx).batteryAlertEnabled && level <= LOW_LEVEL && !info.isCharging) {
                if (!prefs.lowNotified) {
                    Notifications.post(ctx, ID_LOW, "Low battery", "Battery is at $level%. Consider turning on Battery Saver.")
                    prefs.lowNotified = true
                }
            } else if (level > LOW_LEVEL + 5) {
                prefs.lowNotified = false
            }

            // Battery Saver reminder, only when the user opted in and Battery Saver is off.
            val power = ctx.getSystemService(PowerManager::class.java)
            if (prefs.saverReminders && level <= SAVER_LEVEL && !info.isCharging && !power.isPowerSaveMode) {
                if (!prefs.saverNotified) {
                    Notifications.post(ctx, ID_SAVER, "Battery Saver reminder", "Battery is at $level%. Turn on Battery Saver to extend use.")
                    prefs.saverNotified = true
                }
            } else if (level > SAVER_LEVEL + 5) {
                prefs.saverNotified = false
            }
        }

        // Temperature warning, once per overheating episode.
        val temp = info.temperatureC
        if (temp != null) {
            if (UiPrefs(ctx).tempAlertEnabled && temp >= TEMP_WARNING_C && !prefs.tempNotified) {
                Notifications.post(
                    ctx,
                    ID_TEMP,
                    "Battery temperature warning",
                    "Battery is at ${"%.1f".format(temp)} °C. Pause heavy use or charging to let it cool down.",
                )
                prefs.tempNotified = true
            } else if (temp < TEMP_WARNING_C - 3) {
                prefs.tempNotified = false
            }
        }

        return Result.success()
    }

    companion object {
        private const val UNIQUE_NAME = "battery_alerts"
        private const val LOW_LEVEL = 15
        private const val SAVER_LEVEL = 20
        private const val TEMP_WARNING_C = 40.0
        private const val ID_LOW = 1
        private const val ID_TEMP = 2
        private const val ID_SAVER = 3

        /** Turns background alerts on or off. Turning off cancels all scheduled checks. */
        fun setEnabled(context: Context, enabled: Boolean) {
            AppPrefs(context).alertsEnabled = enabled
            val wm = WorkManager.getInstance(context)
            if (enabled) {
                val request = PeriodicWorkRequestBuilder<AlertWorker>(15, TimeUnit.MINUTES).build()
                wm.enqueueUniquePeriodicWork(UNIQUE_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
            } else {
                wm.cancelUniqueWork(UNIQUE_NAME)
            }
        }
    }
}

/** Posts charging notifications when the user has turned on alerts. */
class PowerEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!AppPrefs(context).alertsEnabled) return
        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED ->
                Notifications.post(context, 10, "Charging started", "Your device is now charging.")
            Intent.ACTION_POWER_DISCONNECTED ->
                Notifications.post(context, 11, "Charging stopped", "Your device is now running on battery.")
        }
    }
}
