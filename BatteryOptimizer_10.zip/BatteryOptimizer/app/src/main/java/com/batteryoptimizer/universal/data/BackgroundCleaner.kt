package com.batteryoptimizer.universal.data

import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val DAY_MS = 86_400_000L
private const val WEEK_DAYS = 7L

/** Shizuku checks per scan. Each check starts a short shell command, so this keeps the scan short. */
private const val CHECK_LIMIT = 40
private const val PREFS = "battery_optimizer_restrictions"
private const val KEY_RESTRICTED = "restricted_packages"

/** The scan stages, in order. Each one does its real work before the next one starts. */
enum class ScanStage(val label: String) {
    INIT("Initializing Battery Optimizer"),
    DEVICE("Checking Android Device"),
    SHIZUKU("Checking Shizuku Connection"),
    APPS("Scanning Installed Apps"),
    BACKGROUND("Checking Background Activity"),
    BATTERY("Analyzing Battery Usage"),
    RESULTS("Preparing Optimization Results"),
}

/** One installed app. A null value means Android did not report that fact to this app. */
data class AppEntry(
    val label: String,
    val packageName: String,
    val system: Boolean,
    val essential: Boolean,
    val foregroundMinutes: Long?,
    val daysSinceUsed: Long?,
    val restricted: Boolean?,
)

data class ScanResult(
    val scannedAt: Long,
    val entries: List<AppEntry>,
    val highActivity: List<AppEntry>,
    val recommended: List<AppEntry>,
    val usageAccess: Boolean,
    val shizukuConnected: Boolean,
    val supported: List<String>,
    val unsupported: List<String>,
)

/** What happened to one app. [restricted] is the state read back after the action. */
data class ApplyOutcome(
    val label: String,
    val packageName: String,
    val restricted: Boolean?,
    val message: String,
)

/**
 * Scans installed apps and restricts only the ones the user picks. Android does not let an app stop
 * other apps, so restriction goes through Shizuku's shell and the change is read back before it is reported.
 */
object BackgroundCleaner {

    /** Runs the scan stages in order. [onStage] runs on the main thread before each stage starts. */
    suspend fun scan(context: Context, onStage: (ScanStage) -> Unit): ScanResult = withContext(Dispatchers.IO) {
        stage(ScanStage.INIT, onStage)
        val pm = context.packageManager
        val self = context.packageName
        val essential = BackgroundCleanup.essentialPackages(context)

        stage(ScanStage.DEVICE, onStage)
        val supported = mutableListOf("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        val unsupported = mutableListOf<String>()

        stage(ScanStage.SHIZUKU, onStage)
        val connected = ShizukuGrant.hasPermission()
        if (connected) {
            supported += "Background restriction through Shizuku"
        } else {
            unsupported += "Background restriction: needs Shizuku connected"
        }

        stage(ScanStage.APPS, onStage)
        val installed = pm.getInstalledApplications(0)

        stage(ScanStage.BACKGROUND, onStage)
        val usageAccess = hasUsageAccess(context)
        val now = System.currentTimeMillis()
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
        val day: Map<String, UsageStats> =
            if (usageAccess && usm != null) usm.queryAndAggregateUsageStats(now - DAY_MS, now) else emptyMap()
        val week: Map<String, UsageStats> =
            if (usageAccess && usm != null) usm.queryAndAggregateUsageStats(now - WEEK_DAYS * DAY_MS, now) else emptyMap()
        if (usageAccess) {
            supported += "Screen time per app (last 24 hours and 7 days)"
        } else {
            unsupported += "Screen time per app: usage access is off"
        }

        val base = installed.map { info ->
            val pkg = info.packageName
            AppEntry(
                label = labelOf(pm, info),
                packageName = pkg,
                system = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                essential = pkg == self || pkg in essential,
                foregroundMinutes = if (usageAccess) (day[pkg]?.totalTimeInForeground ?: 0L) / 60_000L else null,
                daysSinceUsed = if (usageAccess) daysSince(now, week[pkg]?.lastTimeUsed) else null,
                restricted = null,
            )
        }

        // Shizuku is asked only about the apps the user might act on, and only when it is connected.
        val candidates = base
            .filter { isHigh(it) || isUnused(it) }
            .sortedByDescending { it.foregroundMinutes ?: 0L }
            .take(CHECK_LIMIT)
        val restrictedMap: Map<String, Boolean?> = if (connected) {
            candidates.associate { it.packageName to ShizukuGrant.readBackgroundRestricted(it.packageName) }
        } else {
            emptyMap()
        }
        val entries = base.map { it.copy(restricted = restrictedMap[it.packageName]) }

        stage(ScanStage.BATTERY, onStage)
        unsupported += "Battery use per app: Android does not give apps per-app battery numbers"
        unsupported += "Other apps' running services and wake-up counts: not accessible to apps"

        stage(ScanStage.RESULTS, onStage)
        ScanResult(
            scannedAt = now,
            entries = entries.sortedBy { it.label.lowercase() },
            highActivity = entries.filter { isHigh(it) }.sortedByDescending { it.foregroundMinutes ?: 0L }.take(5),
            recommended = entries.filter { isUnused(it) },
            usageAccess = usageAccess,
            shizukuConnected = connected,
            supported = supported,
            unsupported = unsupported,
        )
    }

    /** Restricts or un-restricts one app. Essential and system apps are never restricted. */
    suspend fun setRestriction(context: Context, app: AppEntry, restricted: Boolean): ApplyOutcome =
        withContext(Dispatchers.IO) {
            if (restricted && (app.system || app.essential)) {
                return@withContext ApplyOutcome(app.label, app.packageName, app.restricted,
                    "Protected app. It cannot be restricted.")
            }
            if (!ShizukuGrant.hasPermission()) {
                return@withContext ApplyOutcome(app.label, app.packageName, app.restricted,
                    "Shizuku is not connected.")
            }
            val ok = ShizukuGrant.setBackgroundRestricted(app.packageName, restricted)
            if (ok) {
                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val saved = prefs.getStringSet(KEY_RESTRICTED, emptySet())?.toMutableSet() ?: mutableSetOf()
                if (restricted) {
                    saved.add(app.packageName)
                } else {
                    saved.remove(app.packageName)
                }
                prefs.edit().putStringSet(KEY_RESTRICTED, saved).apply()
                ApplyOutcome(
                    app.label, app.packageName, restricted,
                    if (restricted) "Restricted. Android confirmed it." else "Restriction removed. Android confirmed it.",
                )
            } else {
                ApplyOutcome(app.label, app.packageName, app.restricted,
                    ShizukuGrant.lastError ?: "Android did not confirm the change.")
            }
        }

    /** Restricts each chosen app, one at a time, and reports the result for each. */
    suspend fun restrict(context: Context, apps: List<AppEntry>): List<ApplyOutcome> =
        apps.map { setRestriction(context, it, true) }

    /** Removes the restriction from every app this app restricted earlier. Apps stay on the list if Shizuku fails. */
    suspend fun restoreAll(context: Context): List<ApplyOutcome> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val packages = prefs.getStringSet(KEY_RESTRICTED, emptySet())?.toList() ?: emptyList()
        packages.map { pkg ->
            val app = AppEntry(
                label = labelOf(pm, pkg),
                packageName = pkg,
                system = false,
                essential = false,
                foregroundMinutes = null,
                daysSinceUsed = null,
                restricted = true,
            )
            setRestriction(context, app, false)
        }
    }
}

private suspend fun stage(stage: ScanStage, onStage: (ScanStage) -> Unit) {
    withContext(Dispatchers.Main) { onStage(stage) }
}

/** Screen time in the last 24 hours, for a third-party app that is not essential. */
private fun isHigh(e: AppEntry): Boolean =
    !e.system && !e.essential && (e.foregroundMinutes ?: 0L) > 0L

/** Not used in the last 7 days, for a third-party app that is not essential. Needs usage access. */
private fun isUnused(e: AppEntry): Boolean {
    if (e.system || e.essential || e.foregroundMinutes == null) return false
    val days = e.daysSinceUsed
    return days == null || days >= WEEK_DAYS
}

private fun daysSince(now: Long, lastUsed: Long?): Long? =
    if (lastUsed == null || lastUsed <= 0L) null else (now - lastUsed) / DAY_MS

private fun labelOf(pm: PackageManager, info: ApplicationInfo): String =
    pm.getApplicationLabel(info).toString()

private fun labelOf(pm: PackageManager, pkg: String): String = try {
    labelOf(pm, pm.getApplicationInfo(pkg, 0))
} catch (e: PackageManager.NameNotFoundException) {
    pkg
}
