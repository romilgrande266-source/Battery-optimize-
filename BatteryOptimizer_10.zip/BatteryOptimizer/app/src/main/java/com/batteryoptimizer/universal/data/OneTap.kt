package com.batteryoptimizer.universal.data

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import android.view.inputmethod.InputMethodManager

private const val DAY_MS = 86_400_000L
private const val NOT_SUPPORTED_TEXT = "Not Supported"

/**
 * What happened to one check.
 * CHANGED only when Android confirmed the new value. Everything else is information or a recommendation.
 */
enum class Outcome { CHANGED, OK, RECOMMEND, UNSUPPORTED }

data class CheckResult(
    val title: String,
    val value: String,
    val outcome: Outcome,
    val detail: String? = null,
)

/** An app Android lets us see. Minutes are screen time, not battery use. */
data class AppUsage(
    val label: String,
    val packageName: String,
    val foregroundMinutes: Long,
    val daysSinceUsed: Long?,
)

class BackgroundScan(
    val usageAccess: Boolean,
    val recent: List<AppUsage>,   // screen time in the last 24 hours, most first
    val unused: List<AppUsage>,   // installed apps with no use in the last 7 days
)

data class OneTapReport(
    val generatedAt: Long,
    val percent: Int?,
    val temperatureC: Double?,
    val optimizationStatus: String,
    val checks: List<CheckResult>,
    val screenPermissionNeeded: Boolean,
    val usageAccess: Boolean,
    val attention: List<AppUsage>,
) {
    val completed: List<CheckResult> get() = checks.filter { it.outcome == Outcome.CHANGED }
    val recommendations: List<CheckResult> get() = checks.filter { it.outcome == Outcome.RECOMMEND }
    val unsupported: List<CheckResult> get() = checks.filter { it.outcome == Outcome.UNSUPPORTED }
    val goodChecks: List<CheckResult> get() = checks.filter { it.outcome == Outcome.OK }
}

fun hasUsageAccess(context: Context): Boolean {
    val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
    @Suppress("DEPRECATION")
    val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

/**
 * Lists apps from Android's usage data. Android does not give apps per-app battery numbers,
 * so this uses screen time. It never stops, kills or restricts any app.
 */
object BackgroundCleanup {
    fun scan(context: Context): BackgroundScan {
        if (!hasUsageAccess(context)) return BackgroundScan(false, emptyList(), emptyList())
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return BackgroundScan(true, emptyList(), emptyList())

        val pm = context.packageManager
        val self = context.packageName
        val essential = essentialPackages(context)
        val now = System.currentTimeMillis()
        val day = usm.queryAndAggregateUsageStats(now - DAY_MS, now)
        val week = usm.queryAndAggregateUsageStats(now - 7 * DAY_MS, now)

        val recent = day.mapNotNull { (pkg, stats) ->
            if (stats.totalTimeInForeground <= 0L) return@mapNotNull null
            val info = eligible(pm, pkg, self, essential) ?: return@mapNotNull null
            AppUsage(
                label = pm.getApplicationLabel(info).toString(),
                packageName = pkg,
                foregroundMinutes = stats.totalTimeInForeground / 60_000L,
                daysSinceUsed = daysSince(now, week[pkg]?.lastTimeUsed ?: stats.lastTimeUsed),
            )
        }.sortedByDescending { it.foregroundMinutes }

        val unused = pm.getInstalledApplications(0).mapNotNull { info ->
            val pkg = info.packageName
            if (week.containsKey(pkg)) return@mapNotNull null
            eligible(pm, pkg, self, essential) ?: return@mapNotNull null
            AppUsage(pm.getApplicationLabel(info).toString(), pkg, 0L, null)
        }.sortedBy { it.label.lowercase() }

        return BackgroundScan(true, recent, unused)
    }

    private fun daysSince(now: Long, last: Long): Long? =
        if (last <= 0L) null else (now - last) / DAY_MS

    /** Third-party apps only. Phone, messages, home screen and keyboard apps are never listed. */
    private fun eligible(pm: PackageManager, pkg: String, self: String, essential: Set<String>): ApplicationInfo? {
        if (pkg == self || pkg in essential) return null
        return try {
            val info = pm.getApplicationInfo(pkg, 0)
            if ((info.flags and ApplicationInfo.FLAG_SYSTEM) != 0) null else info
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    internal fun essentialPackages(context: Context): Set<String> {
        val pm = context.packageManager
        val found = mutableSetOf<String>()
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_VIEW, Uri.parse("sms:")),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
        )
        for (intent in intents) {
            val pkg = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            if (pkg != null) found.add(pkg)
        }
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.enabledInputMethodList?.forEach { found.add(it.packageName) }
        return found
    }
}

object OneTapOptimizer {
    /**
     * Runs every check. A setting is changed only when Android allows it, and it is marked CHANGED
     * only after Android reads the new value back.
     */
    fun run(context: Context, battery: BatteryInfo): OneTapReport {
        val tweaks = buildTweaks(context, battery)
        val screenOk = TweakBackup.canWrite(context) || ShizukuGrant.grantWriteSettings(context)
        val scan = BackgroundCleanup.scan(context)
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val checks = mutableListOf<CheckResult>()

        checks += CheckResult(
            "Battery status",
            "${battery.percent?.let { "$it%" } ?: NOT_SUPPORTED_TEXT} · ${battery.status.label}",
            Outcome.OK,
        )

        val temp = battery.temperatureC
        checks += when {
            temp == null -> CheckResult("Battery temperature", NOT_SUPPORTED_TEXT, Outcome.UNSUPPORTED)
            temp >= 45.0 -> CheckResult(
                "Battery temperature", "%.1f °C".format(temp), Outcome.RECOMMEND,
                "Stop heavy use, unplug the charger, and let the phone cool.",
            )
            temp >= 40.0 -> CheckResult(
                "Battery temperature", "%.1f °C".format(temp), Outcome.RECOMMEND,
                "Pause heavy use or charging.",
            )
            else -> CheckResult("Battery temperature", "%.1f °C".format(temp), Outcome.OK)
        }

        for (tweak in tweaks) {
            if (tweak.number == 19) continue // battery temperature is checked above
            checks += when (tweak.number) {
                1, 2 -> screenCheck(context, tweak, screenOk)
                3 -> {
                    if (scan.usageAccess) {
                        CheckResult(tweak.title, "${scan.recent.size} apps used in 24 h", Outcome.OK,
                            "The app list below shows screen time per app.")
                    } else {
                        CheckResult(tweak.title, "Needs usage access", Outcome.RECOMMEND,
                            "Allow usage access to see which apps were active.")
                    }
                }
                20 -> {
                    if (tweak.value == "Recommended now") {
                        CheckResult(tweak.title, tweak.value, Outcome.RECOMMEND, tweak.advice)
                    } else {
                        CheckResult(tweak.title, tweak.value, Outcome.OK, "Not needed at this battery level.")
                    }
                }
                else -> genericCheck(tweak)
            }
        }

        val top = scan.recent.take(3)
        checks += when {
            !scan.usageAccess -> CheckResult(
                "High battery usage apps", "Needs usage access", Outcome.RECOMMEND,
                "Android does not give apps per-app battery numbers. Allow usage access to see screen time per app.",
            )
            top.isEmpty() -> CheckResult("High battery usage apps", "None found", Outcome.OK)
            else -> CheckResult(
                "High battery usage apps", "${top.size} to review", Outcome.RECOMMEND,
                "Android does not give per-app battery numbers. These apps had the most screen time in 24 h.",
            )
        }

        checks += when {
            pm.isPowerSaveMode -> CheckResult("Battery Saver", "On", Outcome.OK)
            else -> CheckResult(
                "Battery Saver", "Off", Outcome.RECOMMEND,
                "Turn on Battery Saver when the battery is low or you are away from a charger.",
            )
        }

        checks += CheckResult(
            "Power-saving settings", "Available", Outcome.OK,
            "Battery Saver and Adaptive Battery are listed above and in Battery Tweaks.",
        )
        checks += CheckResult(
            "Notification activity", NOT_SUPPORTED_TEXT, Outcome.UNSUPPORTED,
            "Android does not let apps read other apps' notifications.",
        )
        checks += CheckResult(
            "Unnecessary wake-up activity", NOT_SUPPORTED_TEXT, Outcome.UNSUPPORTED,
            "Android does not show wake-up counts to apps. Review wake-ups in each app's notification settings.",
        )

        val exempt = pm.isIgnoringBatteryOptimizations(context.packageName)
        checks += CheckResult(
            "Battery optimization permissions",
            if (exempt) "This app is exempt" else "This app is optimized",
            Outcome.OK,
            "Other apps' exceptions can only be reviewed in Android's battery optimization list.",
        )
        checks += CheckResult(
            "Device power-saving", "Available", Outcome.OK,
            "Doze and Battery Saver are part of Android.",
        )

        val changed = checks.count { it.outcome == Outcome.CHANGED }
        val screenNeeded = !screenOk && tweaks.any { (it.number == 1 || it.number == 2) && it.supported }
        val status = when {
            screenNeeded -> "Needs your permission to change screen settings"
            changed > 0 -> "Optimized. $changed change(s) confirmed by Android"
            else -> "Checked. No changes were needed or allowed"
        }

        return OneTapReport(
            generatedAt = System.currentTimeMillis(),
            percent = battery.percent,
            temperatureC = temp,
            optimizationStatus = status,
            checks = checks,
            screenPermissionNeeded = screenNeeded,
            usageAccess = scan.usageAccess,
            attention = top,
        )
    }

    private fun screenCheck(context: Context, tweak: Tweak, permitted: Boolean): CheckResult {
        val change = tweak.change
        if (!tweak.supported) return CheckResult(tweak.title, tweak.value, Outcome.UNSUPPORTED, tweak.advice)
        if (change == null) return CheckResult(tweak.title, tweak.value, Outcome.RECOMMEND, tweak.advice)
        if (alreadySet(context, change)) {
            return CheckResult(tweak.title, tweak.value, Outcome.OK, "Already set.")
        }
        if (!permitted) {
            return CheckResult(tweak.title, tweak.value, Outcome.RECOMMEND,
                "Allow screen changes to apply this automatically.")
        }
        return if (verifiedApply(context, change)) {
            CheckResult(tweak.title, "Changed", Outcome.CHANGED, "Android confirmed the new value.")
        } else {
            CheckResult(tweak.title, tweak.value, Outcome.RECOMMEND, "Android did not confirm the change.")
        }
    }

    // Same targets as the change in Tweaks.kt: 40% brightness (about 102 of 255) and a 30 second timeout.
    private fun alreadySet(context: Context, change: InAppChange): Boolean = when (change) {
        InAppChange.LOWER_BRIGHTNESS ->
            (systemInt(context, Settings.System.SCREEN_BRIGHTNESS) ?: 999) <= 110 &&
                systemInt(context, Settings.System.SCREEN_BRIGHTNESS_MODE) == 0
        InAppChange.SHORTER_TIMEOUT ->
            systemInt(context, Settings.System.SCREEN_OFF_TIMEOUT) == 30_000
        InAppChange.ULTRA_MODE -> false
    }

    private fun genericCheck(t: Tweak): CheckResult {
        if (!t.supported) return CheckResult(t.title, t.value, Outcome.UNSUPPORTED, t.advice)
        // The value that is better for battery. Guidance (value not read) always gets the tip.
        val good = when (t.number) {
            5, 6 -> "On"
            8, 10, 14, 15, 18 -> "Off"
            else -> null
        }
        val needsAction = good == null || t.value != good
        return CheckResult(t.title, t.value, if (needsAction) Outcome.RECOMMEND else Outcome.OK, t.advice)
    }
}

fun OneTapReport.toShareText(): String = buildString {
    appendLine("Battery Optimizer report")
    appendLine("Status: $optimizationStatus")
    appendLine("Battery: ${percent?.let { "$it%" } ?: NOT_SUPPORTED_TEXT}")
    appendLine("Temperature: ${temperatureC?.let { "%.1f °C".format(it) } ?: NOT_SUPPORTED_TEXT}")
    appendSection("Completed optimizations", completed.map { "${it.title}: ${it.value}" },
        "None. Android did not confirm any change.")
    appendSection("Recommendations", recommendations.map { "${it.title}: ${it.detail ?: it.value}" },
        "None.")
    appendSection("Unsupported on this device", unsupported.map { it.title }, "None.")
    appendSection("Apps needing attention",
        attention.map { "${it.label}: ${it.foregroundMinutes} min screen time in 24 h" },
        "None found, or usage access is off.")
}

private fun StringBuilder.appendSection(title: String, items: List<String>, emptyText: String) {
    appendLine()
    appendLine("$title:")
    if (items.isEmpty()) appendLine("- $emptyText") else items.forEach { appendLine("- $it") }
}
