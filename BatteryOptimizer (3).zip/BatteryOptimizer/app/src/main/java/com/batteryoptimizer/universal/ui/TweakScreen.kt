package com.batteryoptimizer.universal.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.batteryoptimizer.universal.data.AppPrefs
import com.batteryoptimizer.universal.data.BatteryHistory
import com.batteryoptimizer.universal.data.BatteryInfo
import com.batteryoptimizer.universal.data.InAppChange
import com.batteryoptimizer.universal.data.OptimizationMode
import com.batteryoptimizer.universal.data.Tweak
import com.batteryoptimizer.universal.data.TweakBackup
import com.batteryoptimizer.universal.data.buildTweaks
import com.batteryoptimizer.universal.work.AlertWorker

@Composable
fun TweaksScreen(battery: BatteryInfo, onSelectMode: (OptimizationMode) -> Unit) {
    val context = LocalContext.current
    var refresh by remember { mutableStateOf(0) }
    var askPermission by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    val tweaks = remember(refresh, battery) { buildTweaks(context, battery) }
    val drain = remember(battery) { BatteryHistory.drainPerHour() }

    fun applyChange(change: InAppChange) {
        if (change == InAppChange.ULTRA_MODE) {
            onSelectMode(OptimizationMode.ULTRA_SAVER)
            return
        }
        if (!TweakBackup.canWrite(context)) {
            askPermission = true
            return
        }
        message = if (TweakBackup.applyChange(context, change)) {
            "Changed. Use Restore Default Settings to undo it."
        } else {
            "This device did not accept the change."
        }
        refresh++
    }

    fun restoreDefaults() {
        val systemOk = TweakBackup.restoreSystemSettings(context)
        val prefs = AppPrefs(context)
        prefs.mode = OptimizationMode.NORMAL
        prefs.saverReminders = false
        AlertWorker.setEnabled(context, false)
        message = if (systemOk) {
            "Restored. Brightness and screen timeout are back to their earlier values. App preferences were reset."
        } else {
            "Brightness and screen timeout need permission to restore. App preferences were reset."
        }
        refresh++
    }

    if (askPermission) {
        AlertDialog(
            onDismissRequest = { askPermission = false },
            title = { Text("Allow screen changes?") },
            text = {
                Text(
                    "Android needs your permission before an app can change brightness or screen timeout. " +
                        "The app changes these only when you tap a button, and it saves the old values so " +
                        "Restore Default Settings can put them back.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    askPermission = false
                    openWriteSettingsPermission(context)
                }) { Text("Open permission screen") }
            },
            dismissButton = {
                TextButton(onClick = { askPermission = false }) { Text("Not now") }
            },
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            "These are the values Android reports on this device. Savings are not shown as percentages.",
            style = MaterialTheme.typography.bodySmall,
        )
        Button(onClick = { refresh++ }, modifier = Modifier.fillMaxWidth()) {
            Text("REFRESH DETECTED SETTINGS")
        }

        tweaks.forEach { tweak ->
            TweakCard(
                tweak = tweak,
                onChange = { change -> applyChange(change) },
                onOpen = { action -> openAction(context, action) },
            )
        }

        SectionCard("Battery consumption") {
            Text(
                drain?.let { "About ${"%.1f".format(it)}% per hour, measured from readings while on battery." }
                    ?: "Not enough data yet. Keep the app open for at least 10 minutes while on battery.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                "Based only on this app's readings. It is not a prediction.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        SectionCard("Battery protection") {
            Text(temperatureStatus(battery.temperatureC), style = MaterialTheme.typography.bodyMedium)
            Text("Safe charging habits", fontWeight = FontWeight.SemiBold)
            listOf(
                "Use the charger and cable that came with the phone, or a certified replacement.",
                "Do not charge under a pillow, in a bag, or in direct sunlight.",
                "Unplug the charger when the phone is hot, and let it cool first.",
                "Keeping charge between about 20% and 80% is gentler on the battery when you can.",
            ).forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
            Text(
                "Temperature and low battery alerts are sent once per event, not repeatedly. " +
                    "Charging alerts are sent only when charging starts or stops.",
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                "This app cannot repair battery health. Battery condition changes with age, heat and charge cycles.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        SectionCard("Restore") {
            Text(
                "Restores only what this app changed: brightness, screen timeout, and app preferences. " +
                    "Android does not let an app reset other system settings.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Button(onClick = { restoreDefaults() }, modifier = Modifier.fillMaxWidth()) {
                Text("RESTORE DEFAULT SETTINGS")
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }

        Text(
            "Works offline. No data is uploaded.",
            style = MaterialTheme.typography.labelSmall,
        )
    }
}

@Composable
private fun TweakCard(tweak: Tweak, onChange: (InAppChange) -> Unit, onOpen: (String) -> Unit) {
    SectionCard("${tweak.number}. ${tweak.title}") {
        InfoRow("Status", tweak.value)
        Text(tweak.advice, style = MaterialTheme.typography.bodyMedium)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val change = tweak.change
            if (change != null && tweak.supported) {
                Button(onClick = { onChange(change) }, modifier = Modifier.weight(1f)) {
                    Text(changeLabel(change))
                }
            }
            val action = tweak.action
            if (action != null) {
                OutlinedButton(onClick = { onOpen(action) }, modifier = Modifier.weight(1f)) {
                    Text("OPEN SETTINGS")
                }
            }
        }
    }
}

private fun changeLabel(change: InAppChange): String = when (change) {
    InAppChange.LOWER_BRIGHTNESS -> "LOWER BRIGHTNESS"
    InAppChange.SHORTER_TIMEOUT -> "SHORTER TIMEOUT"
    InAppChange.ULTRA_MODE -> "SWITCH TO ULTRA"
}

private fun temperatureStatus(t: Double?): String = when {
    t == null -> "Battery temperature: Not Supported on this device."
    t >= 45.0 -> "Battery temperature: ${"%.1f".format(t)} °C. Critical. Stop using the phone, unplug it, and let it cool."
    t >= 40.0 -> "Battery temperature: ${"%.1f".format(t)} °C. Warning. Pause heavy use or charging."
    else -> "Battery temperature: ${"%.1f".format(t)} °C. Normal. Warning starts at 40 °C, critical at 45 °C."
}

private fun openAction(context: Context, action: String) {
    try {
        context.startActivity(Intent(action))
    } catch (e: ActivityNotFoundException) {
        context.startActivity(Intent(Settings.ACTION_SETTINGS))
    }
}

private fun openWriteSettingsPermission(context: Context) {
    val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
    context.startActivity(intent)
}
