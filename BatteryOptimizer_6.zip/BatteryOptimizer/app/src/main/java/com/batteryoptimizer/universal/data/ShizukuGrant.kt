package com.batteryoptimizer.universal.data

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Optional helper. If the Shizuku app is running and the user allowed this app in it, Shizuku can
 * grant "Modify system settings" (WRITE_SETTINGS) through its shell. No root is needed.
 * The app works the same without Shizuku; the Android settings screen is still the fallback.
 */
object ShizukuGrant {
    const val REQUEST_CODE = 4101

    /** True when the Shizuku service is running and reachable. Never throws. */
    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    /** True when Shizuku is running and the user has allowed this app in Shizuku. Never throws. */
    fun hasPermission(): Boolean = try {
        isAvailable() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    /** Asks Shizuku to show its own allow prompt. Does nothing if Shizuku is not running. */
    fun requestPermission() {
        try {
            if (isAvailable()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            // Shizuku went away between the check and the request. The user can try again.
        }
    }

    /**
     * Grants this app WRITE_SETTINGS through Shizuku's shell (`appops set <package> WRITE_SETTINGS allow`).
     * Returns true only when the command exits with code 0 and the app is allowed to write settings now.
     */
    fun grantWriteSettings(context: Context): Boolean {
        if (!hasPermission()) return false
        val exitCode = runShell(arrayOf("appops", "set", context.packageName, "WRITE_SETTINGS", "allow"))
        return exitCode == 0 && android.provider.Settings.System.canWrite(context)
    }

    /**
     * Shizuku's public API does not expose a shell helper in every version, so this calls
     * Shizuku.newProcess by reflection. If that method is missing or changes, this returns null
     * and the app falls back to the normal permission screen.
     */
    private fun runShell(command: Array<String>): Int? = try {
        val method = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
        )
        method.isAccessible = true
        val process = method.invoke(null, command, null, null) as Process
        process.waitFor()
    } catch (e: Throwable) {
        null
    }
}
