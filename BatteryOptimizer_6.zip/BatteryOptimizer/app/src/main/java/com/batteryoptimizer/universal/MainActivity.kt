package com.batteryoptimizer.universal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import com.batteryoptimizer.universal.data.AppPrefs
import com.batteryoptimizer.universal.data.BatteryHistory
import com.batteryoptimizer.universal.data.BatteryInfo
import com.batteryoptimizer.universal.data.BatteryRepository
import com.batteryoptimizer.universal.data.BatterySample
import com.batteryoptimizer.universal.data.DeviceProfile
import com.batteryoptimizer.universal.data.OptimizationMode
import com.batteryoptimizer.universal.data.UiPrefs
import com.batteryoptimizer.universal.ui.AppSettingsScreen
import com.batteryoptimizer.universal.ui.BatteryOptimizerTheme
import com.batteryoptimizer.universal.ui.BatteryScreen
import com.batteryoptimizer.universal.ui.DeviceInfoScreen
import com.batteryoptimizer.universal.ui.HomeScreen
import com.batteryoptimizer.universal.ui.TweaksScreen
import com.batteryoptimizer.universal.work.AlertWorker
import kotlinx.coroutines.flow.distinctUntilChanged

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppRoot()
        }
    }
}

enum class BottomTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    OPTIMIZE("Optimize", Icons.Filled.Tune),
    BATTERY("Battery", Icons.Filled.BatteryFull),
    DEVICE("Device", Icons.Filled.Smartphone),
    SETTINGS("Settings", Icons.Filled.Settings),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val prefs = remember { AppPrefs(context) }
    val uiPrefs = remember { UiPrefs(context) }

    var tab: BottomTab by rememberSaveable { mutableStateOf(BottomTab.HOME) }
    var mode: OptimizationMode by remember { mutableStateOf(prefs.mode) }
    var themeMode: Int by remember { mutableStateOf(uiPrefs.themeMode) }

    val initialBattery = remember { BatteryRepository.read(context) }
    val battery: BatteryInfo by remember { BatteryRepository.observe(context).distinctUntilChanged() }
        .collectAsState(initial = initialBattery)
    val history: List<BatterySample> by BatteryHistory.samples.collectAsState()
    LaunchedEffect(battery) { BatteryHistory.record(battery) }

    val device: DeviceProfile = remember(tab) { DeviceProfile.read(context) }
    val drain: Double? = remember(battery) { BatteryHistory.drainPerHour() }

    BackHandler(enabled = tab != BottomTab.HOME) { tab = BottomTab.HOME }

    val selectMode: (OptimizationMode) -> Unit = { selected ->
        prefs.mode = selected
        mode = selected
        if (selected == OptimizationMode.ULTRA_SAVER) {
            AlertWorker.setEnabled(context, false)
        }
    }
    val onRestored: () -> Unit = {
        mode = OptimizationMode.NORMAL
        themeMode = 0
    }
    val onThemeChange: (Int) -> Unit = { value ->
        uiPrefs.themeMode = value
        themeMode = value
    }

    BatteryOptimizerTheme(themeMode = themeMode) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(if (tab == BottomTab.HOME) "Battery Optimizer" else tab.label)
                    },
                )
            },
            bottomBar = {
                NavigationBar {
                    BottomTab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                        )
                    }
                }
            },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (tab) {
                    BottomTab.HOME -> HomeScreen(
                        battery = battery,
                        device = device,
                        mode = mode,
                        drain = drain,
                        onOptimizeNow = { tab = BottomTab.OPTIMIZE },
                        onOpenTweaks = { tab = BottomTab.OPTIMIZE },
                    )
                    BottomTab.OPTIMIZE -> TweaksScreen(
                        battery = battery,
                        onSelectMode = { selected ->
                            selectMode(selected)
                            tab = BottomTab.BATTERY
                        },
                        onRestored = onRestored,
                    )
                    BottomTab.BATTERY -> BatteryScreen(
                        battery = battery,
                        mode = mode,
                        history = history,
                        onSelectMode = selectMode,
                    )
                    BottomTab.DEVICE -> DeviceInfoScreen(device = device)
                    BottomTab.SETTINGS -> AppSettingsScreen(
                        themeMode = themeMode,
                        onThemeChange = onThemeChange,
                        onRestored = onRestored,
                    )
                }
            }
        }
    }
}
