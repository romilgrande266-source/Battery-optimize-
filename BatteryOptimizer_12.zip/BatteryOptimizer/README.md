# Battery Optimizer – Universal Edition

A free, offline Android app that shows real battery information from Android's system APIs and gives battery-saving recommendations. It works on phones from many brands, from Android 8.0 (API 26) upward, on both ARM 32-bit (`armeabi-v7a`) and ARM 64-bit (`arm64-v8a`) devices.

> **Status:** The source code is complete, but it has not yet been compiled or run on a device. See [docs/TESTING.md](docs/TESTING.md) for what is verified and what is still pending. Build it with the steps below before relying on it.

## What it does

- **Dashboard:** animated battery ring, temperature, voltage, charging status and source, device summary, a battery optimization score, and Battery Saver status.
- **Battery Optimize:** checks the app can measure (battery optimization for this app, Battery Saver, screen brightness, screen timeout), general tips, brand-specific tips, and shortcuts to system settings.
- **Modes:** Normal, Battery Saver, Ultra Battery Saver, and Performance. Each shows recommendations and a shortcut to the relevant system screen.
- **Battery Health:** the health status, technology, charge counter, and time-to-full that Android reports. Unavailable values show *Not Supported*.
- **Battery Monitor:** live readings and an in-memory level chart for the current session.
- **Device Information:** manufacturer, brand, model, Android version and SDK, CPU ABI, RAM, screen, and hardware feature support.
- **One-tap optimize:** the **OPTIMIZE BATTERY NOW** button runs every check. It changes only what Android allows, marks a change as done only after Android confirms it, and gives you a report you can share.
- **Clean Background:** lists the apps that used the most screen time and the apps not opened in 7 days. Each one links to its settings. It never closes or stops an app.
- **Optional alerts:** low battery, temperature warning (40 °C), charging started or stopped, and Battery Saver reminders. Off by default.

## What it deliberately does not do

- It does not force-stop apps, change protected system settings, or root the device. It opens the system settings screens. The only change it makes itself is to brightness and screen timeout, and only after you allow it.
- It does not claim to restore battery capacity or improve battery health. Android does not expose wear level, design capacity, or cycle count to apps, so those fields show *Not Supported* instead of estimates.
- It does not overclock the CPU or bypass thermal protection. Performance Mode only explains and shows usage.
- It has no internet permission, no accounts, no analytics, and no background service. Battery readings never leave the device.

## Permissions

| Permission | Why | When it is requested |
|---|---|---|
| `POST_NOTIFICATIONS` | Show the alerts you turn on | Android 13+, only when you enable alerts. The app explains this first. |
| `PACKAGE_USAGE_STATS` | Show which apps used the most time (Clean Background) | Only when you turn on Usage access in Android's settings. The data stays on the device. |

Everything else is read without permission from Android's public APIs.

**Optional: Shizuku.** If the [Shizuku](https://shizuku.rikka.app/) app is installed and running, and you allow Battery Optimizer in it, the app can grant itself "Modify system settings" for the brightness and timeout buttons. This needs no root. Shizuku is not required. Without it, the app opens Android's permission screen instead. The app does not need Shizuku to open.

## Real Cooling Mode

Tap **REAL COOLING MODE** on the Home screen. It is a monitoring and guidance screen, not a cooler.

- **Live readings:** battery temperature from Android's battery sensor, CPU and GPU temperature from the phone's thermal zones when they are accessible, and Android's thermal status on Android 10 and newer.
- **Sensor access:** the app first tries to read the thermal zones directly. If Android blocks that and Shizuku is connected and allowed, it reads them through Shizuku's shell. If neither works, the screen shows *Not accessible*. Many phones block these sensors for apps, and the app never estimates a value in their place.
- **Steps you choose:** turn on Battery Saver (through Shizuku only), lower screen brightness (with your permission, or through Shizuku), scan background activity, and restrict the apps you pick. Each step runs only when you tap it. Restrictions ask for confirmation, and a step counts as completed only after Android reads back the new state.
- **Results:** starting and current temperature, the difference, thermal status, heat level, completed steps, steps Android did not confirm, and recent readings. The screen says cooling is confirmed only when the last two readings are both at least 0.5 °C below the starting reading.
- **Warnings:** the screen warns at a battery temperature of 40 °C or more (hot) and 45 °C or more (dangerously hot), or when Android's thermal status is Severe or Critical. It recommends pausing demanding use and unplugging the charger when that helps.
- **Monitoring:** readings are recorded only while the screen is open, for up to 10 minutes. No background service runs.
- **Compatibility:** the screen lists what this phone supports and what it does not, and why.

It never changes CPU or GPU speed, never disables or changes thermal protection, and never shows a temperature it did not read.

## Requirements

- Android 8.0 (API 26) or newer
- To build from source: JDK 17, Android SDK (platform 34, build-tools 34.0.0), Gradle 8.7

## Build locally

```bash
# One time: create the Gradle wrapper (the wrapper JAR is not included in this ZIP)
gradle wrapper --gradle-version 8.7

# Build both variants
./gradlew assembleArm32Debug assembleArm64Debug
```

Output files:

- `app/build/outputs/apk/arm32/debug/app-arm32-debug.apk`
- `app/build/outputs/apk/arm64/debug/app-arm64-debug.apk`

Open the project folder in Android Studio to run it on a device or emulator.

## Build on GitHub (automatic)

1. Create a new GitHub repository and push this project to it.
2. The workflow in `.github/workflows/build.yml` runs on every push, on pull requests, and on manual *Run workflow*.
3. Open the **Actions** tab. Each run produces two artifacts, `BatteryOptimizer-arm32.apk` and `BatteryOptimizer-arm64.apk`. Download them from the run's summary page.
4. To publish a release, push a version tag such as `v1.0.0`. The workflow attaches both APKs to a GitHub Release.

If a build fails, open the failed run and read the log for the failing step. On failure the workflow also uploads `build-logs-<abi>` artifacts with the Gradle reports.

## Installing an APK on a phone

1. Copy the APK to the phone, or download it there from the GitHub release.
2. Open it and allow installation from that source when Android asks.
3. Choose **Install**, then open **Battery Optimizer**.

Choose `arm64` for most phones made after about 2019. Use `arm32` only for older or low-end 32-bit-only devices. Use the Device Information screen to see your device's CPU architecture.

## Notes on the APKs

- The APKs are **debug-signed**. They install and run, but they are not suitable for Google Play. A release build needs your own keystore, stored as GitHub secrets. That signing setup is not included.
- The app contains no native code, so the two APKs have identical code. They differ only in their ABI packaging rules, which the workflow checks.

## Project layout

```
app/src/main/java/com/batteryoptimizer/universal/
├── MainActivity.kt          Navigation and app root
├── BatteryOptimizerApp.kt   Application class, creates the notification channel
├── data/                    Battery and device readings, checks, modes, preferences
├── notify/                  Notification helper
├── work/                    Optional background alerts (WorkManager) and power receiver
└── ui/                      Theme, reusable components, screens
```

## Limitations

- Background alert checks run about every 15 minutes. This is the WorkManager minimum, so alerts are not instant.
- Battery history is kept in memory while the app is open and is cleared when the app is closed.
- Brand menu names in the tips are general guidance. They vary by Android version and phone software.
- CPU and GPU temperatures appear only when Android or Shizuku gives access to the thermal zones. Many phones block this.
- Battery Saver through Shizuku depends on how the phone's software handles the setting. The app confirms it by reading Android's real state, and it says so when it cannot.
- Real Cooling Mode monitors only while its screen is open.
- The UI text is in English.

## License

MIT. See [LICENSE](LICENSE).
