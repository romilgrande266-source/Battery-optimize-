package com.batteryoptimizer.universal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import com.batteryoptimizer.universal.data.AppPrefs
import com.batteryoptimizer.universal.data.BatteryHistory
import com.batteryoptimizer.universal.data.BatteryInfo
import com.batteryoptimizer.universal.data.BatteryRepository
import com.batteryoptimizer.universal.data.BatterySample
import com.batteryoptimizer.universal.data.DeviceProfile
import com.batteryoptimizer.universal.data.OneTapOptimizer
import com.batteryoptimizer.universal.data.OneTapReport
import com.batteryoptimizer.universal.data.OptimizationMode
import com.batteryoptimizer.universal.data.ShizukuGrant
import com.batteryoptimizer.universal.data.UiPrefs
import com.batteryoptimizer.universal.ui.AppMonitorScreen
import com.batteryoptimizer.universal.ui.AppSettingsScreen
import com.batteryoptimizer.universal.ui.BatteryOptimizerTheme
import com.batteryoptimizer.universal.ui.BatteryScreen
import com.batteryoptimizer.universal.ui.CleanAllBackgroundScreen
import com.batteryoptimizer.universal.ui.DeviceInfoScreen
import com.batteryoptimizer.universal.ui.HomeScreen
import com.batteryoptimizer.universal.ui.OneTapReportScreen
import com.batteryoptimizer.universal.ui.ShizukuSetupScreen
import com.batteryoptimizer.universal.ui.TweaksScreen
import com.batteryoptimizer.universal.ui.openScreenPermission
import com.batteryoptimizer.universal.work.AlertWorker
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Loads the saved Shizuku on/off choice and listens for Shizuku starting or stopping.
        ShizukuGrant.init(this)
        setContent {
            AppRoot()
        }
    }
}

enum class BottomTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    OPTIMIZE("Optimize", Icons.Filled.Tune),
    BATTERY("Battery", Icons.Filled.BatteryFull),
    DEVICE("Device", Icons.Filled.Smartphone),
    SETTINGS("Settings", Icons.Filled.Settings),
}

/** Full-screen pages shown in place of the current tab. */
enum class Overlay(val title: String) {
    ONE_TAP_REPORT("Optimization report"),
    CLEAN_BACKGROUND("Clean background"),
    APP_MONITOR("App monitor"),
    SHIZUKU_SETUP("Shizuku setup"),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val prefs = remember { AppPrefs(context) }
    val uiPrefs = remember { UiPrefs(context) }

    var tab: BottomTab by rememberSaveable { mutableStateOf(BottomTab.HOME) }
    var mode: OptimizationMode by remember { mutableStateOf(prefs.mode) }
    var themeMode: Int by remember { mutableStateOf(uiPrefs.themeMode) }
    var overlay: Overlay? by remember { mutableStateOf<Overlay?>(null) }
    var running: Boolean by remember { mutableStateOf(false) }
    var report: OneTapReport? by remember { mutableStateOf<OneTapReport?>(null) }

    val initialBattery = remember { BatteryRepository.read(context) }
    val battery: BatteryInfo by remember { BatteryRepository.observe(context).distinctUntilChanged() }
        .collectAsState(initial = initialBattery)
    val history: List<BatterySample> by BatteryHistory.samples.collectAsState()
    LaunchedEffect(battery) { BatteryHistory.record(battery) }

    val device: DeviceProfile = remember(tab) { DeviceProfile.read(context) }
    val drain: Double? = remember(battery) { BatteryHistory.drainPerHour() }

    BackHandler(enabled = tab != BottomTab.HOME) { tab = BottomTab.HOME }
    BackHandler(enabled = overlay != null) { overlay = null }

    // One tap runs every check. The short delay lets the button animation show before the work runs.
    LaunchedEffect(running) {
        if (running) {
            delay(900)
            report = OneTapOptimizer.run(context, battery)
            running = false
            overlay = Overlay.ONE_TAP_REPORT
        }
    }

    val selectMode: (OptimizationMode) -> Unit = { selected ->
        prefs.mode = selected
        mode = selected
        if (selected == OptimizationMode.ULTRA_SAVER) {
            AlertWorker.setEnabled(context, false)
        }
    }
    val onRestored: () -> Unit = {
        mode = OptimizationMode.NORMAL
        themeMode = 0
    }
    val onThemeChange: (Int) -> Unit = { value ->
        uiPrefs.themeMode = value
        themeMode = value
    }

    BatteryOptimizerTheme(themeMode = themeMode) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(overlay?.title ?: if (tab == BottomTab.HOME) "Battery Optimizer" else tab.label)
                    },
                )
            },
            bottomBar = {
                NavigationBar {
                    BottomTab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = {
                                overlay = null
                                tab = item
                            },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                        )
                    }
                }
            },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (overlay) {
                    Overlay.ONE_TAP_REPORT -> report?.let { current ->
                        OneTapReportScreen(
                            report = current,
                            onOpenScreenPermission = { openScreenPermission(context) },
                        )
                    }
                    Overlay.CLEAN_BACKGROUND -> CleanAllBackgroundScreen(
                        onOpenShizukuSetup = { overlay = Overlay.SHIZUKU_SETUP },
                        onOpenAppMonitor = { overlay = Overlay.APP_MONITOR },
                    )
                    Overlay.APP_MONITOR -> AppMonitorScreen(
                        onOpenShizukuSetup = { overlay = Overlay.SHIZUKU_SETUP },
                    )
                    Overlay.SHIZUKU_SETUP -> ShizukuSetupScreen()
                    null -> when (tab) {
                    BottomTab.HOME -> HomeScreen(
                        battery = battery,
                        device = device,
                        mode = mode,
                        drain = drain,
                        running = running,
                        onOptimizeNow = { running = true },
                        onCleanBackground = { overlay = Overlay.CLEAN_BACKGROUND },
                        onOpenTweaks = { tab = BottomTab.OPTIMIZE },
                        onUltraSaver = {
                            selectMode(OptimizationMode.ULTRA_SAVER)
                            tab = BottomTab.BATTERY
                        },
                    )
                    BottomTab.OPTIMIZE -> TweaksScreen(
                        battery = battery,
                        onSelectMode = { selected ->
                            selectMode(selected)
                            tab = BottomTab.BATTERY
                        },
                        onRestored = onRestored,
                    )
                    BottomTab.BATTERY -> BatteryScreen(
                        battery = battery,
                        mode = mode,
                        history = history,
                        onSelectMode = selectMode,
                    )
                    BottomTab.DEVICE -> DeviceInfoScreen(device = device)
                    BottomTab.SETTINGS -> AppSettingsScreen(
                        themeMode = themeMode,
                        onThemeChange = onThemeChange,
                        onRestored = onRestored,
                    )
                }
                }
            }
        }
    }
}
