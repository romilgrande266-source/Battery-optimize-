package com.batteryoptimizer.universal.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.width
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.batteryoptimizer.universal.data.AppPrefs
import com.batteryoptimizer.universal.data.BatteryInfo
import com.batteryoptimizer.universal.data.BatterySample
import com.batteryoptimizer.universal.data.DeviceProfile
import com.batteryoptimizer.universal.data.OptimizationMode
import com.batteryoptimizer.universal.data.UiPrefs
import com.batteryoptimizer.universal.data.modeInfo
import com.batteryoptimizer.universal.work.AlertWorker

/** A rounded card with consistent padding and spacing. */
@Composable
fun PremiumCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content,
        )
    }
}

/** Shows a status value. "Not Supported" is grey; everything else uses the neon accent. */
@Composable
fun StatusPill(text: String) {
    val tint = if (text == NOT_SUPPORTED) MaterialTheme.colorScheme.onSurfaceVariant else BatteryGreen
    Surface(shape = RoundedCornerShape(50), color = tint.copy(alpha = 0.16f)) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            color = tint,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
fun HomeScreen(
    battery: BatteryInfo,
    device: DeviceProfile,
    mode: OptimizationMode,
    drain: Double?,
    running: Boolean,
    onOptimizeNow: () -> Unit,
    onCleanBackground: () -> Unit,
    onOpenTweaks: () -> Unit,
    onUltraSaver: () -> Unit,
) {
    val info = modeInfo(mode)
    val pulse by animateFloatAsState(
        targetValue = if (running) 0.97f else 1f,
        animationSpec = tween(durationMillis = 300),
        label = "optimizePulse",
    )
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        BatteryCircle(percent = battery.percent)
        Text(homeStatus(battery), style = MaterialTheme.typography.titleMedium, color = BatteryGreen)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard(
                label = "Temperature",
                value = battery.temperatureC?.let { "%.1f °C".format(it) } ?: NOT_SUPPORTED,
                icon = Icons.Filled.Thermostat,
                modifier = Modifier.weight(1f),
            )
            MetricCard(
                label = "Voltage",
                value = battery.voltageV?.let { "%.2f V".format(it) } ?: NOT_SUPPORTED,
                icon = Icons.Filled.ElectricBolt,
                modifier = Modifier.weight(1f),
            )
        }

        PremiumCard {
            Text("Estimated remaining time", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(remainingText(battery, drain), style = MaterialTheme.typography.bodyLarge)
        }

        PremiumCard {
            Text("Current battery-saving mode", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(info.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(info.summary, style = MaterialTheme.typography.bodyMedium)
        }

        PremiumCard {
            Text("Device", style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("${device.brand} ${device.model}", style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold)
            Text("Android ${device.androidRelease} · ${archLabel(device)}",
                style = MaterialTheme.typography.bodySmall)
        }

        Button(
            onClick = onOptimizeNow,
            enabled = !running,
            modifier = Modifier.fillMaxWidth().height(84.dp).graphicsLayer {
                scaleX = pulse
                scaleY = pulse
            },
            colors = greenButtonColors(),
        ) {
            Icon(Icons.Filled.BatteryFull, contentDescription = null)
            Spacer(Modifier.width(10.dp))
            Text(if (running) "OPTIMIZING…" else "OPTIMIZE BATTERY NOW", fontWeight = FontWeight.Bold)
        }
        if (running) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = BatteryGreen)
        }
        Button(
            onClick = onCleanBackground,
            modifier = Modifier.fillMaxWidth().height(64.dp),
            colors = greenButtonColors(),
        ) {
            Icon(Icons.Filled.Apps, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("CLEAN BACKGROUND", fontWeight = FontWeight.SemiBold)
        }
        Button(
            onClick = onOpenTweaks,
            modifier = Modifier.fillMaxWidth().height(64.dp),
            colors = greenButtonColors(),
        ) {
            Icon(Icons.Filled.Tune, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("BATTERY TWEAKS", fontWeight = FontWeight.SemiBold)
        }
        Button(
            onClick = onUltraSaver,
            modifier = Modifier.fillMaxWidth().height(64.dp),
            colors = greenButtonColors(),
        ) {
            Icon(Icons.Filled.ElectricBolt, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("ULTRA BATTERY SAVER", fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun BatteryScreen(
    battery: BatteryInfo,
    mode: OptimizationMode,
    history: List<BatterySample>,
    onSelectMode: (OptimizationMode) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Power-saving modes", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        OptimizationMode.entries.forEach { option ->
            val info = modeInfo(option)
            PremiumCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(info.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(info.summary, style = MaterialTheme.typography.bodySmall)
                    }
                    if (option == mode) {
                        StatusPill("Active")
                    } else {
                        OutlinedButton(onClick = { onSelectMode(option) }) { Text("SELECT") }
                    }
                }
            }
        }

        PremiumCard {
            Text("Active recommendations", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            modeInfo(mode).tips.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
        }

        Text("Battery health", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        PremiumCard {
            InfoRow("Health reported by Android", battery.health ?: NOT_SUPPORTED)
            InfoRow("Battery technology", battery.technology ?: NOT_SUPPORTED)
            InfoRow("Temperature", battery.temperatureC?.let { "%.1f °C".format(it) } ?: NOT_SUPPORTED)
            InfoRow("Voltage", battery.voltageV?.let { "%.2f V".format(it) } ?: NOT_SUPPORTED)
            InfoRow("Charging status", homeStatus(battery))
            InfoRow("Current charge", battery.currentChargeMah?.let { "$it mAh" } ?: NOT_SUPPORTED)
            InfoRow("Design capacity", NOT_SUPPORTED)
        }

        PremiumCard {
            Text("Battery protection", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(tempNote(battery.temperatureC), style = MaterialTheme.typography.bodyMedium)
            listOf(
                "Use the charger and cable that came with the phone, or a certified replacement.",
                "Do not charge under a pillow, in a bag, or in direct sunlight.",
                "Unplug the charger when the phone is hot, and let it cool first.",
            ).forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
            Text("This app cannot repair battery health. Battery condition changes with age, heat and charge cycles.",
                style = MaterialTheme.typography.bodySmall)
        }

        PremiumCard {
            Text("Level history (this session)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            LevelChart(history)
        }
    }
}

@Composable
fun DeviceInfoScreen(device: DeviceProfile) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PremiumCard {
            Text("${device.brand} ${device.model}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(device.manufacturer, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        PremiumCard {
            Text("System", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            InfoRow("Android version", device.androidRelease)
            InfoRow("SDK level", device.sdkInt.toString())
        }
        PremiumCard {
            Text("Processor", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            InfoRow("Architecture", archLabel(device))
            InfoRow("Running ABI", abiLabel(device.primaryAbi))
            InfoRow("All supported ABIs", device.supportedAbis.joinToString())
        }
        PremiumCard {
            Text("Memory and screen", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            InfoRow("Total RAM", "${device.totalRamMb} MB")
            InfoRow("Available RAM", "${device.availableRamMb} MB")
            InfoRow("Screen", "${device.screenWidthPx} × ${device.screenHeightPx} px")
            InfoRow("Density", "${device.densityDpi} dpi")
        }
        PremiumCard {
            Text("Supported features", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            device.features.forEach { feature ->
                InfoRow(feature.name, if (feature.supported) "Supported" else NOT_SUPPORTED)
            }
        }
    }
}

@Composable
fun AppSettingsScreen(themeMode: Int, onThemeChange: (Int) -> Unit, onRestored: () -> Unit) {
    val context = LocalContext.current
    val appPrefs = remember { AppPrefs(context) }
    val uiPrefs = remember { UiPrefs(context) }
    var alerts by remember { mutableStateOf(appPrefs.alertsEnabled) }
    var saverReminders by remember { mutableStateOf(appPrefs.saverReminders) }
    var tempAlert by remember { mutableStateOf(uiPrefs.tempAlertEnabled) }
    var batteryAlert by remember { mutableStateOf(uiPrefs.batteryAlertEnabled) }
    var explainPermission by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            alerts = true
            AlertWorker.setEnabled(context, true)
        }
    }

    fun setAlerts(on: Boolean) {
        if (!on) {
            alerts = false
            AlertWorker.setEnabled(context, false)
            return
        }
        val needsPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            explainPermission = true
        } else {
            alerts = true
            AlertWorker.setEnabled(context, true)
        }
    }

    if (explainPermission) {
        AlertDialog(
            onDismissRequest = { explainPermission = false },
            title = { Text("Allow notifications?") },
            text = {
                Text(
                    "Notifications are used only for the alerts you turn on. The app does not need " +
                        "internet, location or storage access.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    explainPermission = false
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }) { Text("Continue") }
            },
            dismissButton = {
                TextButton(onClick = { explainPermission = false }) { Text("Not now") }
            },
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PremiumCard {
            Text("Appearance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            listOf(Pair(0, "Automatic (follow phone)"), Pair(1, "Dark"), Pair(2, "Light")).forEach { option ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = themeMode == option.first, onClick = { onThemeChange(option.first) })
                    Text(option.second, modifier = Modifier.padding(start = 4.dp))
                }
            }
        }

        PremiumCard {
            Text("Notifications", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            SettingSwitch("Background battery alerts", alerts) { setAlerts(it) }
            SettingSwitch("Temperature alert", tempAlert) {
                tempAlert = it
                uiPrefs.tempAlertEnabled = it
            }
            SettingSwitch("Battery alert (low battery)", batteryAlert) {
                batteryAlert = it
                uiPrefs.batteryAlertEnabled = it
            }
            SettingSwitch("Battery Saver reminders", saverReminders) {
                saverReminders = it
                appPrefs.saverReminders = it
            }
            OutlinedButton(onClick = { openNotificationSettings(context) }, modifier = Modifier.fillMaxWidth()) {
                Text("OPEN NOTIFICATION SETTINGS")
            }
        }

        PremiumCard {
            Text("Language", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "The app follows your phone's language. English is the only language included in this build.",
                style = MaterialTheme.typography.bodyMedium,
            )
            OutlinedButton(onClick = { openLocaleSettings(context) }, modifier = Modifier.fillMaxWidth()) {
                Text("LANGUAGE SETTINGS")
            }
        }

        PremiumCard {
            Text("Restore", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Restores brightness, screen timeout, theme, alerts and app preferences that this app changed. " +
                    "Android does not let an app reset other system settings.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Button(
                onClick = {
                    val systemOk = restoreEverything(context)
                    alerts = false
                    saverReminders = false
                    tempAlert = true
                    batteryAlert = true
                    onRestored()
                    message = if (systemOk) {
                        "Restored."
                    } else {
                        "App preferences restored. Brightness and timeout need permission to restore."
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("RESTORE DEFAULT SETTINGS") }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }

        PremiumCard {
            Text("Privacy", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "No internet permission. No accounts. No ads. Battery readings stay on this device.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun LevelChart(history: List<BatterySample>) {
    if (history.size < 2) {
        Text(
            "Collecting samples. One sample is kept per minute while the app is open.",
            style = MaterialTheme.typography.bodySmall,
        )
        return
    }
    Canvas(Modifier.fillMaxWidth().height(120.dp)) {
        val values = history.map { it.percent }
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = size.width * i / (values.size - 1)
            val y = size.height * (1f - v / 100f)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, BatteryGreen, style = Stroke(width = 4.dp.toPx()))
    }
}

private fun homeStatus(b: BatteryInfo): String {
    val parts = mutableListOf(b.status.label)
    b.chargingSource?.let { parts += it }
    return parts.joinToString(" · ")
}

private fun remainingText(battery: BatteryInfo, drain: Double?): String {
    if (battery.isCharging) {
        val toFull = battery.minutesToFull ?: return NOT_SUPPORTED
        return "About ${formatMinutes(toFull)} until full"
    }
    val percent = battery.percent ?: return NOT_SUPPORTED
    if (drain == null || drain <= 0.0) {
        return "Not enough data yet. An estimate needs about 10 minutes on battery."
    }
    val minutesLeft = (percent / drain * 60.0).toLong()
    return "About ${formatMinutes(minutesLeft)} left (estimate from measured drain)"
}

private fun formatMinutes(total: Long): String = "${total / 60} h ${total % 60} min"

private fun archLabel(device: DeviceProfile): String =
    if (device.supportedAbis.any { it.contains("64") }) "64-bit" else "32-bit"

private fun abiLabel(abi: String): String = when (abi) {
    "armeabi-v7a" -> "ARM 32-bit (armeabi-v7a)"
    "arm64-v8a" -> "ARM 64-bit (arm64-v8a)"
    else -> abi
}

private fun tempNote(t: Double?): String = when {
    t == null -> "Battery temperature: Not Supported on this device."
    t >= 45.0 -> "Critical at ${"%.1f".format(t)} °C. Stop using the phone, unplug it, and let it cool."
    t >= 40.0 -> "Warning at ${"%.1f".format(t)} °C. Pause heavy use or charging."
    else -> "Normal at ${"%.1f".format(t)} °C. Warning starts at 40 °C; critical at 45 °C."
}

private fun openNotificationSettings(context: Context) {
    val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
        .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
    context.startActivity(intent)
}

private fun openLocaleSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
    } catch (e: ActivityNotFoundException) {
        context.startActivity(Intent(Settings.ACTION_SETTINGS))
    }
}
