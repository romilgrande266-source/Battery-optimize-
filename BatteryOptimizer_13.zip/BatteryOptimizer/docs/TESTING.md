# Testing report

**Status legend:** `Not run` = not yet executed. Fill in the result and date after testing on real hardware or an emulator.

The project was written in an environment without the Android SDK, Gradle dependency downloads, or devices. Nothing below has been compiled or executed yet. Source files were reviewed by reading them, which caught and fixed a wrong import path and two missing imports.

## Build

| # | Check | Method | Status |
|---|---|---|---|
| B1 | Project compiles with no errors | `./gradlew assembleArm32Debug assembleArm64Debug`, or the GitHub Actions run | Not run |
| B2 | Dependencies resolve | Same build; check that Gradle downloads succeed | Not run |
| B3 | No lint errors that block the build | Run `./gradlew lintArm64Debug` and review | Not run |
| B4 | ARM 32-bit APK produced | Check `BatteryOptimizer-arm32.apk` artifact exists and installs | Not run |
| B5 | ARM 64-bit APK produced | Check `BatteryOptimizer-arm64.apk` artifact exists and installs | Not run |

## Device detection

| # | Check | Method | Status |
|---|---|---|---|
| D1 | Manufacturer, brand, model, Android version, SDK shown correctly | Compare with Settings > About phone | Not run |
| D2 | ARM 32-bit vs 64-bit label correct | Compare with the device's CPU spec | Not run |
| D3 | RAM values plausible | Compare total RAM with the spec sheet | Not run |
| D4 | Feature list matches the device (e.g. NFC absent on a device without NFC) | Compare with the spec sheet | Not run |

## Battery information

| # | Check | Method | Status |
|---|---|---|---|
| I1 | Percentage matches the status bar | Compare on screen | Not run |
| I2 | Temperature in °C is plausible | Compare with a thermometer app or after heavy use | Not run |
| I3 | Voltage in V is plausible (about 3.5 to 4.4 V for a Li-ion cell) | Visual check | Not run |
| I4 | Charging status and source update when plugging and unplugging | Plug and unplug a charger | Not run |
| I5 | Time-to-full appears only while charging on Android 9+ and is hidden when unavailable | Charge and check | Not run |
| I6 | Unsupported values show *Not Supported*, not zero | Test on a device that omits some values, or review code path | Not run |

## Optimization and modes

| # | Check | Method | Status |
|---|---|---|---|
| O1 | Score matches the checks shown | Compare the checks and the score | Not run |
| O2 | Each *Open settings* button opens the right system screen, or the fallback settings screen | Tap each button on at least two brands | Not run |
| O3 | Ultra Battery Saver turns off this app's background alerts | Enable alerts, select Ultra, check Settings | Not run |
| O4 | Performance Mode changes no CPU or thermal settings | Review code and check no system settings change | Not run |
| O5 | Mode chips update the recommendations | Tap each chip | Not run |
| O6 | Opening Optimize / Battery Tweaks does not crash on Android 14 (Infinix X6532); Wi-Fi Scanning and Auto-Sync show a value or Guidance, never close the app | Tap BATTERY TWEAKS and OPTIMIZE tab | Not run |
| O7 | OPTIMIZE BATTERY NOW shows a report; "Completed optimizations" lists only changes Android confirmed | Tap the button with and without screen permission | Not run |
| O8 | CLEAN BACKGROUND never closes an app; it only opens settings screens | Tap OPEN SETTINGS on an app row; check no app is stopped | Not run |
| O9 | Without usage access, Clean Background and the report say "Needs usage access" and show no app list | Turn off Usage access and open both screens | Not run |
| S1 | With Shizuku running and allowed, LOWER BRIGHTNESS works without the Android permission screen | Start Shizuku, allow this app in Shizuku, tap LOWER BRIGHTNESS | Not run |
| S2 | Without Shizuku, LOWER BRIGHTNESS still opens the Android permission screen | Stop Shizuku, tap LOWER BRIGHTNESS | Not run |

## Alerts and notifications

| # | Check | Method | Status |
|---|---|---|---|
| N1 | Notification permission explained before the system prompt (Android 13+) | Enable alerts on a fresh install | Not run |
| N2 | Low battery alert at 15% when not charging | Test with the battery low or a test build with a lower threshold | Not run |
| N3 | Temperature warning at 40 °C | Hard to trigger safely; verify by code review or a test build | Not run |
| N4 | Charging started / stopped notifications | Plug and unplug | Not run |
| N5 | No alerts when alerts are off | Disable alerts and plug and unplug | Not run |

## Offline and privacy

| # | Check | Method | Status |
|---|---|---|---|
| P1 | All core features work with airplane mode on | Enable airplane mode and use every screen | Not run |
| P2 | Merged manifest has only `POST_NOTIFICATIONS` and `PACKAGE_USAGE_STATS` as permissions | Inspect `app/build/intermediates/merged_manifests` | Not run |
| P3 | No network calls are made | Check with a network monitor or review code (no networking libraries used) | Not run |

## Compatibility

| # | Check | Method | Status |
|---|---|---|---|
| C1 | Install and launch on Android 8.0 (API 26) | Emulator or device | Not run |
| C2 | Install and launch on a current Android version | Emulator or device | Not run |
| C3 | Layout works on a small phone and a large phone | Emulator with two screen sizes | Not run |
| C4 | Dark and light themes both readable | Toggle system theme | Not run |
| C5 | Test on a low-end device | Physical device | Not run |

## Real Cooling Mode

| # | Check | Method | Status |
|---|---|---|---|
| R1 | REAL COOLING MODE button opens the screen; Back returns to Home | Tap the button, then Back | Not run |
| R2 | Battery temperature matches a thermometer app | Compare on the same device, after heavy use | Not run |
| R3 | CPU and GPU rows show a value only when a real zone is read; otherwise *Not accessible* | Test with and without Shizuku on several phones | Not run |
| R4 | Thermal status shows a value on Android 10+ and "Not available" on Android 8 and 9 | Test on an Android 8 or 9 device and an Android 10+ device | Not run |
| R5 | Reading source changes from "This app" to "Shizuku" when Android blocks direct access and Shizuku is allowed | Compare with Shizuku on and off | Not run |
| R6 | Heat warnings appear at 40 °C (hot) and 45 °C (dangerously hot), or at Severe/Critical thermal status | Code review; test with a safe build that lowers the thresholds | Not run |
| R7 | "Cooling confirmed" appears only after the last two readings are both at least 0.5 °C below the start | Review code; watch a real cool-down | Not run |
| R8 | Battery Saver through Shizuku is marked completed only after Android reports it on | Connect Shizuku, switch Battery Saver on, check the status bar | Not run |
| R9 | Without Shizuku, the Battery Saver switch is disabled and the screen only opens system settings | Stop Shizuku, look at the switch and the button | Not run |
| R10 | Brightness step is marked completed only after Android reads back the new value | Allow screen changes, tap LOWER SCREEN BRIGHTNESS | Not run |
| R11 | Background restriction asks for confirmation; no app is force-stopped | Pick apps, tap RESTRICT SELECTED, confirm, check the app keeps running | Not run |
| R12 | RESTORE RESTRICTED APPS removes only restrictions this app set | Restrict an app, then restore, then check Android's app settings | Not run |
| R13 | Monitoring stops after 10 minutes and when the screen is left | Start, wait, leave the screen, return | Not run |
| R14 | No new permissions added to the merged manifest | Same check as P2 | Not run |
| R15 | Works in airplane mode | Enable airplane mode and use the screen | Not run |
| R16 | Battery Saver switch starts off on a fresh start and shows Android's real state | Open Real Cooling Mode with Battery Saver off, then on | Not run |
| R17 | Switching Battery Saver off does not count as an optimization | Switch on, then off, and check Completed optimizations | Not run |
| R18 | Always-On Display, Wi-Fi scanning and screen sleep while charging are marked completed only after the setting reads back | Connect Shizuku, tap each button, check the setting in system settings | Not run |
| R19 | RESTORE COOLING CHANGES puts back only the values this app saved, and leaves other settings alone | Change a setting, restore, compare with the value before the change | Not run |
| R20 | The 30-second screen timeout is marked completed only after it reads back | Allow screen changes, tap SET 30-SECOND SCREEN TIMEOUT, check Settings > Display | Not run |
| R21 | On a phone that rejects a setting, the screen says so and changes nothing | Try a setting that the phone does not have | Not run |

## Known gaps

- No automated unit or UI tests are included yet.
- Physical battery health is not available to apps on Android, so it cannot be tested directly.
