# Battery Optimize Plus V2 — Smart Tweaks

## Included
- Long Life Battery: charge-target reminder (80/85/90% only where the phone's own settings support it); no claim of a software-enforced charge cutoff.
- CPU & Thermal Guard: Android thermal status on API 29+ and battery temperature reported by Android. Android does not expose a universal CPU temperature sensor API.
- Smart Battery Saver: opens Android's built-in Battery Saver settings.
- Background Power Control: opens Android battery-usage settings for user review.
- Balanced Gaming Mode: safe recommendations; no overclocking or thermal-limit bypass.

## Scripts
The `app/src/main/assets/tweaks/` directory contains optional shell examples:
- `battery_saver_on.sh`: asks Android's built-in power service to enable Battery Saver.
- `battery_saver_off.sh`: disables Battery Saver.
- `thermal_status.sh`: read-only thermal-service diagnostic.
- `long_life_reminder.sh`: prints charging/heat guidance only.

These scripts are not automatically executed by the app. Review them before running in a Shizuku shell. Command availability and permissions vary by Android version and manufacturer. The app itself does not display the old Modify System Settings permission dialog.
