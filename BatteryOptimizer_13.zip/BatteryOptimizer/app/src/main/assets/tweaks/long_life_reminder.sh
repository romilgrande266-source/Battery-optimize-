#!/system/bin/sh
# Informational reminder only. Android does not expose a universal charge-limit API.
echo "Long-life reminder: avoid prolonged heat and use your phone maker's charge limit (80-90%) if available."
echo "This script does not stop charging or change battery hardware settings."
