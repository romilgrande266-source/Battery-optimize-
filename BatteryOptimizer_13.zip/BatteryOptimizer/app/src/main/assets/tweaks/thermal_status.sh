#!/system/bin/sh
# Read-only diagnostic: show Android thermal service status when available.
dumpsys thermalservice 2>/dev/null
