#!/system/bin/sh
# Optional Shizuku shell script. Disables Android's built-in Battery Saver.
cmd power set-mode 0
