#!/system/bin/sh
# Optional Shizuku shell script. Enables Android's built-in Battery Saver.
# Run only after reviewing it. This does not change CPU clocks or thermal policy.
cmd power set-mode 1
