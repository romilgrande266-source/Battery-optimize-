package com.batteryoptimizer.universal.data

import android.content.Context
import android.os.Build
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Cooling is claimed only when the last two readings are both at least this many °C below the start. */
const val COOL_CONFIRM_C = 0.5

/** Screen timeout used by the cooling step: 30 seconds. */
const val COOL_TIMEOUT_MS = 30_000

/** Monitoring stops by itself after this long, and keeps at most [MONITOR_MAX_SAMPLES] readings. */
const val MONITOR_MAX_MS = 10 * 60_000L
const val MONITOR_MAX_SAMPLES = 200

/** Heat level from the battery temperature and Android's thermal status, whichever is hotter. */
enum class HeatLevel(val label: String) {
    NORMAL("Normal"),
    WARM("Warm"),
    HOT("Hot"),
    DANGER("Dangerously hot"),
}

fun heatLevel(reading: ThermalReading): HeatLevel {
    val battery = reading.batteryC
    val status = reading.thermalStatus
    return when {
        (battery != null && battery >= BATTERY_CRITICAL_C) || (status != null && status >= THERMAL_CRITICAL) ->
            HeatLevel.DANGER
        (battery != null && battery >= BATTERY_WARNING_C) || (status != null && status >= THERMAL_SEVERE) ->
            HeatLevel.HOT
        status != null && status >= THERMAL_MODERATE -> HeatLevel.WARM
        else -> HeatLevel.NORMAL
    }
}

/** One cooling session. Readings are recorded only while [active]. [initial] is the starting reading. */
data class CoolingSession(
    val active: Boolean = false,
    val startedAt: Long = 0L,
    val initial: ThermalReading? = null,
    val samples: List<ThermalReading> = emptyList(),
) {
    /** Adds a reading while monitoring. Stops by itself after [MONITOR_MAX_MS]. */
    fun record(reading: ThermalReading): CoolingSession = when {
        !active -> this
        reading.timeMs - startedAt >= MONITOR_MAX_MS -> copy(active = false)
        else -> copy(samples = (samples + reading).takeLast(MONITOR_MAX_SAMPLES))
    }
}

/**
 * Sensors whose last two readings are both at least [COOL_CONFIRM_C] below the starting reading.
 * An empty list means cooling is not confirmed. It never means the phone is cooler by guesswork.
 */
fun confirmedCooling(session: CoolingSession): List<String> {
    val start = session.initial ?: return emptyList()
    val last = session.samples.takeLast(2)
    if (last.size < 2) return emptyList()
    val confirmed = mutableListOf<String>()

    fun check(label: String, read: (ThermalReading) -> Double?) {
        val begin = read(start) ?: return
        val allLower = last.all { reading ->
            val now = read(reading)
            now != null && begin - now >= COOL_CONFIRM_C
        }
        if (allLower) confirmed += label
    }

    check("battery") { it.batteryC }
    check("CPU") { it.cpuC }
    check("GPU") { it.gpuC }
    return confirmed
}

/** Change from one reading to another, or null if either value is missing. A negative value means cooler. */
fun deltaC(from: Double?, to: Double?): Double? = if (from != null && to != null) to - from else null

/** Suggestions that still apply. The app applies none of them by itself. */
fun remainingRecommendations(
    reading: ThermalReading?,
    shizukuConnected: Boolean,
    pendingApps: Int?,
    pendingEffects: List<String>,
): List<String> {
    if (reading == null) return listOf("Waiting for the first reading.")
    val out = mutableListOf<String>()
    val heat = heatLevel(reading)
    if (heat == HeatLevel.DANGER) {
        out += "Stop using the phone now and let it cool in a shaded place. Do not put it in cold water or a freezer."
    } else if (heat == HeatLevel.HOT) {
        out += "Stop demanding activities such as games, video recording and navigation until it cools."
    }
    val battery = reading.batteryC
    if (reading.charging && battery != null && battery >= BATTERY_WARNING_C) {
        out += "Unplug the charger until the battery cools below ${BATTERY_WARNING_C.toInt()} °C."
    }
    if (!reading.batterySaverOn) out += "Turn on Battery Saver."
    if (!reading.brightnessLow) out += "Lower screen brightness to about 40%, or use adaptive brightness."
    out += pendingEffects
    if (pendingApps == null) {
        out += "Scan background activity to find apps you rarely use."
    } else if (pendingApps > 0) {
        val note = if (shizukuConnected) "" else " Restricting needs Shizuku."
        out += "Review the $pendingApps background app(s) you rarely use and restrict them.$note"
    }
    if (!shizukuConnected) {
        out += "Connect Shizuku (optional) to change system settings and restrict apps from this screen."
    }
    return out.ifEmpty { listOf("No further recommendations right now.") }
}

/** One row of the compatibility list. [detail] says what works and what does not, in plain words. */
data class FeatureSupport(val name: String, val supported: Boolean, val detail: String)

object RealCooling {
    const val TITLE_BRIGHTNESS = "Screen brightness"
    const val TITLE_TIMEOUT = "Screen timeout"
    const val TITLE_RESTRICTION = "Background restriction"
    const val TITLE_RESTRICTION_REMOVED = "Background restriction removed"

    private const val CHECKING = "Checking…"

    /** Lowers brightness to the Battery Tweaks target. Runs only when the user allowed screen changes or Shizuku is connected. */
    suspend fun lowerBrightness(context: Context): CheckResult = withContext(Dispatchers.IO) {
        if (ThermalSensors.brightnessLowered(context)) {
            return@withContext CheckResult(TITLE_BRIGHTNESS, "Already low", Outcome.OK, "Already set.")
        }
        val allowed = TweakBackup.canWrite(context) || ShizukuGrant.grantWriteSettings(context)
        if (!allowed) {
            return@withContext CheckResult(
                TITLE_BRIGHTNESS, "Not changed", Outcome.RECOMMEND,
                "Allow screen changes, or connect Shizuku, to apply this from here.",
            )
        }
        if (verifiedApply(context, InAppChange.LOWER_BRIGHTNESS)) {
            CheckResult(TITLE_BRIGHTNESS, "Lowered", Outcome.CHANGED, "Android confirmed the new brightness.")
        } else {
            CheckResult(TITLE_BRIGHTNESS, "Not changed", Outcome.RECOMMEND, "Android did not confirm the change.")
        }
    }

    /** Sets the screen timeout to 30 seconds, under the same permission rules as brightness. Confirmed by reading it back. */
    suspend fun shorterTimeout(context: Context): CheckResult = withContext(Dispatchers.IO) {
        if (systemInt(context, Settings.System.SCREEN_OFF_TIMEOUT) == COOL_TIMEOUT_MS) {
            return@withContext CheckResult(TITLE_TIMEOUT, "30 seconds", Outcome.OK, "Already set.")
        }
        val allowed = TweakBackup.canWrite(context) || ShizukuGrant.grantWriteSettings(context)
        if (!allowed) {
            return@withContext CheckResult(
                TITLE_TIMEOUT, "Not changed", Outcome.RECOMMEND,
                "Allow screen changes, or connect Shizuku, to apply this from here.",
            )
        }
        if (verifiedApply(context, InAppChange.SHORTER_TIMEOUT)) {
            CheckResult(TITLE_TIMEOUT, "30 seconds", Outcome.CHANGED, "Android confirmed the new timeout.")
        } else {
            CheckResult(TITLE_TIMEOUT, "Not changed", Outcome.RECOMMEND, "Android did not confirm the change.")
        }
    }

    /** Restricts the apps the user picked. Each one is confirmed by Android. System and essential apps are refused. */
    suspend fun restrictApps(context: Context, apps: List<AppEntry>): List<ApplyOutcome> =
        BackgroundCleaner.restrict(context, apps)

    /** Removes the restrictions this app set earlier. Apps stay listed if Shizuku fails. */
    suspend fun restoreApps(context: Context): List<ApplyOutcome> = BackgroundCleaner.restoreAll(context)

    fun restrictionCheck(o: ApplyOutcome): CheckResult = CheckResult(
        TITLE_RESTRICTION,
        o.label,
        if (o.restricted == true) Outcome.CHANGED else Outcome.RECOMMEND,
        o.message,
    )

    fun restoreCheck(o: ApplyOutcome): CheckResult = CheckResult(
        TITLE_RESTRICTION_REMOVED,
        o.label,
        if (o.restricted == false) Outcome.OK else Outcome.RECOMMEND,
        o.message,
    )

    /** What this phone and this session support right now. A null [reading] means the first reading has not arrived. */
    fun compatibility(
        reading: ThermalReading?,
        usageAccess: Boolean,
        shizukuConnected: Boolean,
        brightnessAllowed: Boolean,
    ): List<FeatureSupport> {
        val thermalApi = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val battery = reading?.batteryC
        return listOf(
            FeatureSupport(
                "Battery temperature",
                battery != null,
                when {
                    reading == null -> CHECKING
                    battery == null -> "Android did not report it on this phone."
                    else -> "Read from Android's battery sensor."
                },
            ),
            sensorRow("CPU temperature", reading, reading?.cpuC),
            sensorRow("GPU temperature", reading, reading?.gpuC),
            FeatureSupport(
                "Android thermal status",
                thermalApi && reading?.thermalStatus != null,
                when {
                    !thermalApi -> "Needs Android 10 or newer."
                    reading == null -> CHECKING
                    reading.thermalStatus == null -> "Android did not report it on this phone."
                    else -> "Reported by Android. The levels are set by the phone."
                },
            ),
            FeatureSupport(
                "Battery Saver",
                shizukuConnected,
                if (shizukuConnected) {
                    "Switch on or off from this screen. Confirmed from Android's real state."
                } else {
                    "Without Shizuku, turn it on in Battery Saver settings."
                },
            ),
            FeatureSupport(
                "Screen brightness",
                brightnessAllowed,
                if (brightnessAllowed) "Can be lowered from this screen." else "Allow screen changes, or connect Shizuku.",
            ),
            FeatureSupport(
                "Screen timeout",
                brightnessAllowed,
                if (brightnessAllowed) "Can be set to 30 seconds from this screen." else "Allow screen changes, or connect Shizuku.",
            ),
            FeatureSupport(
                "Always-On Display, Wi-Fi scanning, screen sleep while charging",
                shizukuConnected,
                if (shizukuConnected) {
                    "Changed through Shizuku, confirmed by reading the setting back, and restorable."
                } else {
                    "Needs Shizuku connected."
                },
            ),
            FeatureSupport(
                "Background activity analysis",
                usageAccess,
                if (usageAccess) "Screen time per app is available." else "Turn on usage access to see screen time per app.",
            ),
            FeatureSupport(
                "Background restriction",
                shizukuConnected,
                if (shizukuConnected) "Available. Each app is restricted only after you confirm." else "Needs Shizuku connected.",
            ),
            FeatureSupport("Temperature monitoring", true, "Runs while the screen is open, for up to 10 minutes."),
            FeatureSupport(
                "Shizuku (optional)",
                shizukuConnected,
                if (shizukuConnected) "Connected." else "Not connected. Readings and warnings do not need it.",
            ),
        )
    }

    private fun sensorRow(name: String, reading: ThermalReading?, value: Double?): FeatureSupport = when {
        reading == null -> FeatureSupport(name, false, CHECKING)
        value == null -> FeatureSupport(name, false, "Not accessible. This phone does not let apps read this sensor.")
        else -> FeatureSupport(name, true, "Reading source: ${reading.zoneSource.label}.")
    }
}
