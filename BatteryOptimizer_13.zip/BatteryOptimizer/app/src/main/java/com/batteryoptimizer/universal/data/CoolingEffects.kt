package com.batteryoptimizer.universal.data

import android.content.Context
import android.os.PowerManager
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * System settings that Real Cooling Mode can change through Shizuku's shell. [target] is the value
 * that means cooling. Each change is read back from Android before it is reported as done, and the
 * original value is saved first so Restore can put it back.
 */
enum class ShellSetting(
    val title: String,
    val table: String,
    val key: String,
    val target: Int,
    val buttonLabel: String,
    val advice: String,
) {
    BATTERY_SAVER(
        "Battery Saver", "global", "low_power", 1,
        "TURN ON BATTERY SAVER",
        "Turn on Battery Saver.",
    ),
    ALWAYS_ON_DISPLAY(
        "Always-On Display", "secure", "doze_always_on", 0,
        "TURN OFF ALWAYS-ON DISPLAY",
        "Turn off Always-On Display to reduce constant screen use.",
    ),
    WIFI_SCANNING(
        "Wi-Fi scanning", "global", "wifi_scan_always_enabled", 0,
        "TURN OFF WI-FI SCANNING",
        "Turn off Wi-Fi scanning when you do not need location-based scanning.",
    ),
    SCREEN_SLEEP_WHILE_CHARGING(
        "Screen sleep while charging", "global", "stay_on_while_plugged_in", 0,
        "LET SCREEN SLEEP WHILE CHARGING",
        "Let the screen sleep while charging, so the phone does not stay warm.",
    ),
}

private const val COOL_PREFS = "cooling_effects"
private const val COOL_WAIT_MS = 3_000L
private const val UNSET = -1

object CoolingEffects {

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(COOL_PREFS, Context.MODE_PRIVATE)

    /** The value Android stores for this setting, or [UNSET] when it has never been set. */
    fun value(context: Context, setting: ShellSetting): Int {
        val resolver = context.contentResolver
        return try {
            if (setting.table == "secure") {
                Settings.Secure.getInt(resolver, setting.key, UNSET)
            } else {
                Settings.Global.getInt(resolver, setting.key, UNSET)
            }
        } catch (e: Exception) {
            UNSET
        }
    }

    /** True when the setting holds [expected]. Battery Saver is checked against Android's real state. */
    fun isAt(context: Context, setting: ShellSetting, expected: Int): Boolean =
        if (setting == ShellSetting.BATTERY_SAVER) {
            context.getSystemService(PowerManager::class.java).isPowerSaveMode == (expected == 1)
        } else {
            value(context, setting) == expected
        }

    /** True when the setting is at its cooling value. */
    fun isCooling(context: Context, setting: ShellSetting): Boolean = isAt(context, setting, setting.target)

    /** Switches Battery Saver on or off through Shizuku. It is confirmed only from Android's real state. */
    suspend fun setBatterySaver(context: Context, on: Boolean): CheckResult = withContext(Dispatchers.IO) {
        val setting = ShellSetting.BATTERY_SAVER
        val wanted = if (on) 1 else 0
        val label = if (on) "On" else "Off"
        if (isAt(context, setting, wanted)) {
            return@withContext CheckResult(setting.title, label, Outcome.OK, "Already ${label.lowercase()}.")
        }
        if (!ShizukuGrant.hasPermission()) {
            return@withContext CheckResult(
                setting.title, "Not changed", Outcome.RECOMMEND,
                "Connect Shizuku to switch Battery Saver from here, or use Battery Saver settings.",
            )
        }
        if (on) saveOriginal(context, setting)
        if (!put(setting, wanted)) {
            return@withContext CheckResult(
                setting.title, "Not changed", Outcome.RECOMMEND,
                "Shizuku could not change Battery Saver. Open Battery Saver settings.",
            )
        }
        val confirmed = waitFor { isAt(context, setting, wanted) }
        when {
            !confirmed -> CheckResult(
                setting.title, "Not changed", Outcome.RECOMMEND,
                "Android did not confirm Battery Saver. Open Battery Saver settings.",
            )
            on -> CheckResult(setting.title, "On", Outcome.CHANGED, "Android confirmed Battery Saver is on.")
            else -> {
                // The user switched it off on purpose, so restore should not switch it back on.
                prefs(context).edit().remove(setting.name).apply()
                CheckResult(setting.title, "Off", Outcome.OK, "Battery Saver turned off, as you asked.")
            }
        }
    }

    /** Sets one non-battery setting to its cooling value, then reads Android's value back. */
    suspend fun applySetting(context: Context, setting: ShellSetting): CheckResult = withContext(Dispatchers.IO) {
        if (isCooling(context, setting)) {
            return@withContext CheckResult(setting.title, "Already set", Outcome.OK, "Already at the cooling value.")
        }
        if (!ShizukuGrant.hasPermission()) {
            return@withContext CheckResult(
                setting.title, "Not changed", Outcome.RECOMMEND,
                "Connect Shizuku to change this from here. ${setting.advice}",
            )
        }
        saveOriginal(context, setting)
        if (!put(setting, setting.target)) {
            return@withContext CheckResult(
                setting.title, "Not changed", Outcome.RECOMMEND,
                "Shizuku could not change this setting on this phone.",
            )
        }
        if (waitFor { isCooling(context, setting) }) {
            CheckResult(
                setting.title, "Changed", Outcome.CHANGED,
                "Android confirmed the new value. Restore puts the original back.",
            )
        } else {
            CheckResult(setting.title, "Not changed", Outcome.RECOMMEND, "Android did not confirm the change on this phone.")
        }
    }

    /**
     * Puts back every value this app changed through Shizuku, and the screen brightness and timeout it saved.
     * Settings that were never changed are not touched.
     */
    suspend fun restoreAll(context: Context): List<CheckResult> = withContext(Dispatchers.IO) {
        val out = mutableListOf<CheckResult>()
        val p = prefs(context)
        for (setting in ShellSetting.entries) {
            if (!p.contains(setting.name)) continue
            val original = p.getInt(setting.name, UNSET)
            if (!ShizukuGrant.hasPermission()) {
                out += CheckResult(setting.title, "Not restored", Outcome.RECOMMEND, "Connect Shizuku to restore this setting.")
                continue
            }
            val written = when {
                original == UNSET && setting != ShellSetting.BATTERY_SAVER -> delete(setting)
                original == UNSET -> put(setting, 0)
                else -> put(setting, original)
            }
            val back = written && waitFor { isAt(context, setting, original) }
            if (back) {
                p.edit().remove(setting.name).apply()
                out += CheckResult(setting.title, "Restored", Outcome.OK, "Put back the value Android had before this app changed it.")
            } else {
                out += CheckResult(
                    setting.title, "Not restored", Outcome.RECOMMEND,
                    "Android did not confirm the restore. It stays saved, so you can try again.",
                )
            }
        }
        val screenOk = TweakBackup.restoreSystemSettings(context)
        out += CheckResult(
            "Screen brightness and timeout",
            if (screenOk) "Restored" else "Not restored",
            if (screenOk) Outcome.OK else Outcome.RECOMMEND,
            if (screenOk) {
                "Returned to the values saved before this app changed them, if any."
            } else {
                "Allow screen changes to restore them."
            },
        )
        out
    }

    /** Advice for settings that are not at their cooling value yet. Battery Saver has its own recommendation. */
    fun pendingAdvice(context: Context): List<String> {
        val advice = ShellSetting.entries
            .filter { it != ShellSetting.BATTERY_SAVER && !isCooling(context, it) }
            .map { it.advice }
        val timeout = systemInt(context, Settings.System.SCREEN_OFF_TIMEOUT)
        return if (timeout == COOL_TIMEOUT_MS) {
            advice
        } else {
            advice + "Use a 30-second screen timeout so the screen turns off sooner."
        }
    }

    /** Saves the value from before the first change. Only the first value is kept, so restore goes back to the start. */
    private fun saveOriginal(context: Context, setting: ShellSetting) {
        val p = prefs(context)
        if (!p.contains(setting.name)) {
            p.edit().putInt(setting.name, value(context, setting)).apply()
        }
    }

    /** Runs `settings put` through Shizuku. True only when the command exits with code 0. */
    private fun put(setting: ShellSetting, value: Int): Boolean {
        val result = ShizukuGrant.shell("settings", "put", setting.table, setting.key, value.toString())
        return result != null && result.exitCode == 0
    }

    /** Runs `settings delete` through Shizuku. True only when the command exits with code 0. */
    private fun delete(setting: ShellSetting): Boolean {
        val result = ShizukuGrant.shell("settings", "delete", setting.table, setting.key)
        return result != null && result.exitCode == 0
    }

    /** Polls until [check] is true or the wait runs out. Android applies some settings a moment later. */
    private suspend fun waitFor(check: () -> Boolean): Boolean {
        val deadline = System.currentTimeMillis() + COOL_WAIT_MS
        while (System.currentTimeMillis() < deadline) {
            if (check()) return true
            delay(250)
        }
        return check()
    }
}
