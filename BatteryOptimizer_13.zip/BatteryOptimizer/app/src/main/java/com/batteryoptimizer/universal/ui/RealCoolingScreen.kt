package com.batteryoptimizer.universal.ui

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.batteryoptimizer.universal.data.AppEntry
import com.batteryoptimizer.universal.data.BackgroundCleaner
import com.batteryoptimizer.universal.data.CheckResult
import com.batteryoptimizer.universal.data.COOL_CONFIRM_C
import com.batteryoptimizer.universal.data.CoolingEffects
import com.batteryoptimizer.universal.data.CoolingSession
import com.batteryoptimizer.universal.data.HeatLevel
import com.batteryoptimizer.universal.data.Outcome
import com.batteryoptimizer.universal.data.RealCooling
import com.batteryoptimizer.universal.data.ScanResult
import com.batteryoptimizer.universal.data.SettingsTarget
import com.batteryoptimizer.universal.data.ShellSetting
import com.batteryoptimizer.universal.data.ShizukuGrant
import com.batteryoptimizer.universal.data.ThermalReading
import com.batteryoptimizer.universal.data.ThermalSensors
import com.batteryoptimizer.universal.data.TweakBackup
import com.batteryoptimizer.universal.data.confirmedCooling
import com.batteryoptimizer.universal.data.deltaC
import com.batteryoptimizer.universal.data.hasUsageAccess
import com.batteryoptimizer.universal.data.heatLevel
import com.batteryoptimizer.universal.data.remainingRecommendations
import com.batteryoptimizer.universal.data.thermalStatusLabel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Readings are taken every 5 seconds while idle and every 3 seconds while a session is monitoring. */
private const val POLL_IDLE_MS = 5_000L
private const val POLL_MONITOR_MS = 3_000L

/**
 * REAL COOLING MODE. It shows real sensor readings and warns when the phone is hot. Each step runs only
 * when the user taps it, and a change counts as completed only after Android confirms it. Battery Saver
 * starts off and only changes when the user switches it. Cooling is claimed only when the sensor readings
 * show it. Monitoring runs only while this screen is open.
 */
@Composable
fun RealCoolingScreen(onOpenShizukuSetup: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val shizukuOn by ShizukuGrant.connected.collectAsState()

    var live by remember { mutableStateOf<ThermalReading?>(null) }
    var session by remember { mutableStateOf(CoolingSession()) }
    var actions by remember { mutableStateOf<List<CheckResult>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var scan by remember { mutableStateOf<ScanResult?>(null) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var restrictedPkgs by remember { mutableStateOf<Set<String>>(emptySet()) }
    var confirm by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    // Real readings while this screen is open. A reading is recorded only while a session is monitoring.
    LaunchedEffect(Unit) {
        while (true) {
            readNow(context)?.let { reading ->
                live = reading
                session = session.record(reading)
            }
            delay(if (session.active) POLL_MONITOR_MS else POLL_IDLE_MS)
        }
    }

    fun startCooling() {
        scope.launch {
            busy = true
            val first = readNow(context)
            if (first == null) {
                message = "Could not read the sensors right now. Try again."
            } else {
                live = first
                session = CoolingSession(active = true, startedAt = first.timeMs, initial = first)
                actions = emptyList()
                selected = emptySet()
                message = null
            }
            busy = false
        }
    }

    fun stopCooling() {
        session = session.copy(active = false)
    }

    // Runs one step, adds its result, then reads the device again so the switch and readings are current.
    fun runAction(action: suspend () -> CheckResult) {
        scope.launch {
            busy = true
            val result = action()
            actions = actions + result
            readNow(context)?.let { live = it }
            busy = false
        }
    }

    fun restoreChanges() {
        scope.launch {
            busy = true
            actions = actions + CoolingEffects.restoreAll(context)
            readNow(context)?.let { live = it }
            busy = false
        }
    }

    fun scanBackground() {
        scope.launch {
            busy = true
            message = null
            scan = try {
                BackgroundCleaner.scan(context) { }
            } catch (e: Exception) {
                message = "The background scan stopped early. Nothing was changed."
                null
            }
            selected = emptySet()
            busy = false
        }
    }

    fun restrictChosen(apps: List<AppEntry>) {
        scope.launch {
            busy = true
            val outcomes = RealCooling.restrictApps(context, apps)
            actions = actions + outcomes.map { RealCooling.restrictionCheck(it) }
            restrictedPkgs = restrictedPkgs + outcomes.filter { it.restricted == true }.map { it.packageName }
            selected = emptySet()
            busy = false
        }
    }

    fun restoreRestricted() {
        scope.launch {
            busy = true
            val outcomes = RealCooling.restoreApps(context)
            actions = actions + outcomes.map { RealCooling.restoreCheck(it) }
            val cleared = outcomes.filter { it.restricted == false }.map { it.packageName }.toSet()
            restrictedPkgs = restrictedPkgs - cleared
            busy = false
        }
    }

    val now = live
    val initial = session.initial
    val heat = now?.let { heatLevel(it) } ?: HeatLevel.NORMAL
    val completed = actions.filter { it.outcome == Outcome.CHANGED }
    val notConfirmed = actions.filter { it.outcome != Outcome.CHANGED && it.outcome != Outcome.OK }
    val candidates: List<AppEntry> = scan?.let { s ->
        (s.highActivity + s.recommended)
            .distinctBy { it.packageName }
            .filter { it.packageName !in restrictedPkgs && it.restricted != true }
    } ?: emptyList()
    val chosen = candidates.filter { it.packageName in selected }
    val screenAllowed = TweakBackup.canWrite(context) || shizukuOn
    val usageAccess = hasUsageAccess(context)
    val confirmed = confirmedCooling(session)
    val recommendations = remainingRecommendations(
        reading = now,
        shizukuConnected = shizukuOn,
        pendingApps = scan?.let { candidates.size },
        pendingEffects = CoolingEffects.pendingAdvice(context),
    )
    val features = RealCooling.compatibility(now, usageAccess, shizukuOn, screenAllowed)
    val batterySaverOn = now?.batterySaverOn == true

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PremiumCard {
            Text("Real cooling mode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Reads real temperatures and Android's thermal status, then applies only the changes Android allows. " +
                    "It never fakes a reading, never changes CPU or GPU speed, and never turns off thermal protection.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                "Battery temperature updates on Android's own schedule, so it can stay the same for a short time.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        if (heat == HeatLevel.HOT || heat == HeatLevel.DANGER) {
            PremiumCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Text(
                        heat.label,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                Text(heatMessage(heat), style = MaterialTheme.typography.bodyMedium)
            }
        }

        PremiumCard {
            Text("Live readings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            InfoRow("Battery temperature", sensorText(now, now?.batteryC))
            InfoRow("CPU temperature", sensorText(now, now?.cpuC))
            InfoRow("GPU temperature", sensorText(now, now?.gpuC))
            InfoRow("Android thermal status", thermalStatusLabel(now?.thermalStatus))
            InfoRow("Reading source", now?.zoneSource?.label ?: "Checking…")
        }

        PremiumCard {
            Text("Cooling session", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (session.active) {
                Text(
                    "Monitoring. Readings are recorded while this screen is open, for up to 10 minutes.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                OutlinedButton(onClick = { stopCooling() }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("STOP MONITORING")
                }
            } else {
                Text(
                    "Start to record the starting temperature. Then run the steps below and watch the readings.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Button(
                    onClick = { startCooling() },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(72.dp),
                    colors = greenButtonColors(),
                ) {
                    Icon(Icons.Filled.Thermostat, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("START REAL COOLING", fontWeight = FontWeight.Bold)
                }
            }
            if (busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = BatteryGreen)
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
        }

        PremiumCard {
            Text("Cooling steps", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Each step runs only when you tap it. Android confirms every change before it counts as completed.",
                style = MaterialTheme.typography.bodySmall,
            )

            Text("1. Battery Saver", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (batterySaverOn) "On" else "Off",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        "Starts off. It changes only when you switch it.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Switch(
                    checked = batterySaverOn,
                    onCheckedChange = { on -> runAction { CoolingEffects.setBatterySaver(context, on) } },
                    enabled = shizukuOn && !busy,
                )
            }
            if (!shizukuOn) {
                OutlinedButton(
                    onClick = { openSystemSettings(context, SettingsTarget.BATTERY_SAVER) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text("OPEN BATTERY SAVER SETTINGS") }
                Text("Connect Shizuku to switch it here.", style = MaterialTheme.typography.bodySmall)
            }

            Text("2. Screen brightness and timeout", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            if (screenAllowed) {
                Button(
                    onClick = { runAction { RealCooling.lowerBrightness(context) } },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = greenButtonColors(),
                ) { Text("LOWER SCREEN BRIGHTNESS", fontWeight = FontWeight.Bold) }
                Button(
                    onClick = { runAction { RealCooling.shorterTimeout(context) } },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = greenButtonColors(),
                ) { Text("SET 30-SECOND SCREEN TIMEOUT", fontWeight = FontWeight.Bold) }
            } else {
                OutlinedButton(
                    onClick = { openScreenPermission(context) },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text("ALLOW SCREEN CHANGES") }
            }

            Text("3. Heat sources (through Shizuku)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            if (shizukuOn) {
                ShellSetting.entries
                    .filter { it != ShellSetting.BATTERY_SAVER }
                    .forEach { setting ->
                        Button(
                            onClick = { runAction { CoolingEffects.applySetting(context, setting) } },
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            colors = greenButtonColors(),
                        ) { Text(setting.buttonLabel, fontWeight = FontWeight.Bold) }
                    }
            } else {
                Text(
                    "Connect Shizuku to change Always-On Display, Wi-Fi scanning and screen sleep while charging from here.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            Text("4. Background activity", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            OutlinedButton(
                onClick = { scanBackground() },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("SCAN BACKGROUND ACTIVITY") }
            scan?.let { s ->
                Text(
                    if (s.usageAccess) {
                        "Found ${candidates.size} app(s) you may restrict. Nothing changes until you confirm."
                    } else {
                        "Turn on usage access to see which apps were active."
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            candidates.forEach { app ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = app.packageName in selected,
                        onCheckedChange = { on ->
                            selected = if (on) selected + app.packageName else selected - app.packageName
                        },
                        enabled = shizukuOn && !busy,
                    )
                    Column(Modifier.weight(1f)) {
                        Text(app.label, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        Text(appDetail(app), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (candidates.isNotEmpty() && shizukuOn) {
                Button(
                    onClick = { confirm = true },
                    enabled = chosen.isNotEmpty() && !busy,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = greenButtonColors(),
                ) { Text("RESTRICT SELECTED (${chosen.size})", fontWeight = FontWeight.Bold) }
            }
            if (shizukuOn) {
                OutlinedButton(
                    onClick = { restoreRestricted() },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text("RESTORE RESTRICTED APPS") }
            }

            Text("5. Undo", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            OutlinedButton(
                onClick = { restoreChanges() },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("RESTORE COOLING CHANGES") }
            Text(
                "Puts back the values this app saved before it changed them: Battery Saver, the heat-source settings, " +
                    "and screen brightness and timeout.",
                style = MaterialTheme.typography.bodySmall,
            )

            OutlinedButton(onClick = onOpenShizukuSetup, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Text("SHIZUKU SETUP (OPTIONAL)")
            }
        }

        PremiumCard {
            Text("Cooling results", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (initial == null) {
                Text(
                    "No session yet. Start real cooling to record the starting temperature.",
                    style = MaterialTheme.typography.bodyMedium,
                )
            } else {
                InfoRow("Initial temperature", sensorText(initial, initial.batteryC))
                InfoRow("Current temperature", sensorText(now, now?.batteryC))
                InfoRow("Temperature difference", deltaText(deltaC(initial.batteryC, now?.batteryC)))
                InfoRow("CPU, start to now", pairText(initial.cpuC, now?.cpuC))
                InfoRow("GPU, start to now", pairText(initial.gpuC, now?.gpuC))
                InfoRow("Thermal status", thermalStatusLabel(now?.thermalStatus))
                InfoRow("Heat level", heat.label)
                Text(
                    when {
                        confirmed.isNotEmpty() ->
                            "Cooling confirmed by sensor readings (${confirmed.joinToString()}). " +
                                "The last two readings are both at least $COOL_CONFIRM_C °C below the start."
                        session.samples.size < 2 -> "Not enough readings yet to judge cooling."
                        else -> "No cooling confirmed by sensor readings yet."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        PremiumCard {
            Text("Completed optimizations", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            if (completed.isEmpty()) {
                Text("None yet. Android has not confirmed any change.", style = MaterialTheme.typography.bodyMedium)
            }
            completed.forEach { Text("• ${it.title}: ${it.value}", style = MaterialTheme.typography.bodyMedium) }
            if (notConfirmed.isNotEmpty()) {
                Text("Not confirmed by Android", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                notConfirmed.forEach {
                    Text("• ${it.title}: ${it.detail ?: it.value}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        if (session.samples.isNotEmpty()) {
            PremiumCard {
                Text("Recent readings", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                session.samples.takeLast(6).reversed().forEach { r ->
                    Text(
                        "${clock(r.timeMs)}   battery ${tempOrNa(r.batteryC)}   CPU ${tempOrNa(r.cpuC)}   GPU ${tempOrNa(r.gpuC)}",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }

        PremiumCard {
            Text("Remaining recommendations", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            recommendations.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
        }

        PremiumCard {
            Text("Device compatibility", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            features.forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.weight(1f)) {
                        Text(f.name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        Text(f.detail, style = MaterialTheme.typography.bodySmall)
                    }
                    StatusPill(if (f.supported) "Supported" else NOT_SUPPORTED)
                }
            }
        }

        PremiumCard {
            Text("Not supported by design", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            listOf(
                "Changing CPU or GPU speed. It needs root or system access, and this app never does it.",
                "Turning off or changing thermal protection. This app never does it.",
                "Battery use per app. Android does not report it to apps.",
                "Force-stopping apps. This app only restricts background activity, after you confirm.",
                "Refresh rate, hotspot and mobile data changes. No setting works reliably across phones, so this screen does not change them.",
            ).forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Restrict ${chosen.size} app(s)?") },
            text = {
                Text(
                    "Android will stop these apps from running in the background. " +
                        "No app is force-stopped. Use RESTORE RESTRICTED APPS to undo it.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    restrictChosen(chosen)
                }) { Text("RESTRICT") }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text("CANCEL") }
            },
        )
    }
}

/** One reading on a background thread. Returns null instead of throwing, so a sensor problem never closes the screen. */
private suspend fun readNow(context: Context): ThermalReading? =
    withContext(Dispatchers.IO) { runCatching { ThermalSensors.read(context) }.getOrNull() }

private fun heatMessage(heat: HeatLevel): String = when (heat) {
    HeatLevel.DANGER ->
        "Dangerously hot. Stop demanding activities, unplug the charger, and let the phone cool. " +
            "Do not put it in cold water or a freezer."
    HeatLevel.HOT -> "The phone is hot. Pause games, video recording, navigation and charging until it cools."
    HeatLevel.WARM -> "The phone is getting warm."
    HeatLevel.NORMAL -> ""
}

/** A real value, or "Checking…" before the first reading, or "Not accessible" when the sensor is unavailable. */
private fun sensorText(reading: ThermalReading?, value: Double?): String = when {
    reading == null -> "Checking…"
    value == null -> "Not accessible"
    else -> "%.1f °C".format(value)
}

private fun tempOrNa(value: Double?): String = value?.let { "%.1f °C".format(it) } ?: "n/a"

private fun deltaText(delta: Double?): String = when {
    delta == null -> NOT_SUPPORTED
    abs(delta) < 0.05 -> "0.0 °C"
    delta > 0 -> "+%.1f °C".format(delta)
    else -> "%.1f °C".format(delta)
}

private fun pairText(start: Double?, now: Double?): String {
    if (start == null && now == null) return "Not accessible"
    return "${tempOrNa(start)} → ${tempOrNa(now)}"
}

private fun appDetail(app: AppEntry): String {
    val screen = app.foregroundMinutes?.let { "$it min screen time in 24 h" } ?: "Screen time not available"
    val last = app.daysSinceUsed?.let { "last used $it day(s) ago" } ?: "no recent use recorded"
    return "$screen · $last"
}

private fun clock(ms: Long): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(ms))
