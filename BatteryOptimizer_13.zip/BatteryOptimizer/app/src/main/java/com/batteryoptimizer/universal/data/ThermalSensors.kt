package com.batteryoptimizer.universal.data

import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import java.io.File
import kotlin.math.abs

// Android's thermal status levels (PowerManager.THERMAL_STATUS_*, Android 10 and newer).
const val THERMAL_NONE = 0
const val THERMAL_LIGHT = 1
const val THERMAL_MODERATE = 2
const val THERMAL_SEVERE = 3
const val THERMAL_CRITICAL = 4
const val THERMAL_EMERGENCY = 5
const val THERMAL_SHUTDOWN = 6

/** Battery temperature warning and critical levels. They match the battery alerts and the One-tap report. */
const val BATTERY_WARNING_C = 40.0
const val BATTERY_CRITICAL_C = 45.0

/** A brightness at or below this value (0 to 255) counts as lowered. Same target as Battery Tweaks, about 43%. */
const val LOWERED_BRIGHTNESS_MAX = 110

/** Where the CPU and GPU readings came from. */
enum class ZoneSource(val label: String) {
    APP("This app"),
    SHIZUKU("Shizuku"),
    NONE("No access"),
}

/**
 * One set of real readings taken at [timeMs]. A null value means the value was not available.
 * Nothing is estimated, filled in, or copied from an earlier reading.
 */
data class ThermalReading(
    val timeMs: Long,
    val batteryC: Double?,
    val cpuC: Double?,
    val gpuC: Double?,
    val thermalStatus: Int?,
    val zoneSource: ZoneSource,
    val charging: Boolean,
    val batterySaverOn: Boolean,
    val brightnessLow: Boolean,
)

private data class ZoneReading(val type: String, val tempC: Double)

private data class ZoneScan(val readings: List<ZoneReading>, val source: ZoneSource)

/** Hottest zone whose type name contains [keyword], or null when no such zone reports a value. */
private fun List<ZoneReading>.hottest(keyword: String): Double? =
    filter { it.type.contains(keyword, ignoreCase = true) }.maxOfOrNull { it.tempC }

/** Human-readable thermal status. Null means Android did not report it (Android 8 and 9, or no value). */
fun thermalStatusLabel(status: Int?): String = when (status) {
    null -> "Not available"
    THERMAL_NONE -> "None"
    THERMAL_LIGHT -> "Light"
    THERMAL_MODERATE -> "Moderate"
    THERMAL_SEVERE -> "Severe"
    THERMAL_CRITICAL -> "Critical"
    THERMAL_EMERGENCY -> "Emergency"
    THERMAL_SHUTDOWN -> "Shutdown"
    else -> "Unknown"
}

/**
 * Reads real sensors only. Order: Android's battery sensor, the thermal zones through normal app access,
 * then the thermal zones through Shizuku's shell if Shizuku is allowed. This can block when Shizuku is
 * used, so call it from a background thread.
 */
object ThermalSensors {
    private const val ZONE_DIR = "/sys/class/thermal"
    private const val PLAUSIBLE_MIN_C = -20.0
    private const val PLAUSIBLE_MAX_C = 125.0

    // One shell process reads every zone with shell builtins, so each poll starts only one process.
    private const val ZONE_SCRIPT =
        "for z in /sys/class/thermal/thermal_zone*; do " +
            "read t < \$z/type 2>/dev/null; read v < \$z/temp 2>/dev/null; " +
            "echo \"\$t|\$v\"; done"

    fun read(context: Context): ThermalReading {
        val battery = BatteryRepository.read(context)
        val zones = readZones()
        val power = context.getSystemService(PowerManager::class.java)
        return ThermalReading(
            timeMs = System.currentTimeMillis(),
            batteryC = battery.temperatureC,
            cpuC = zones.readings.hottest("cpu"),
            gpuC = zones.readings.hottest("gpu"),
            thermalStatus = thermalStatus(context),
            zoneSource = zones.source,
            charging = battery.isCharging,
            batterySaverOn = power.isPowerSaveMode,
            brightnessLow = brightnessLowered(context),
        )
    }

    /** True when the screen brightness is set manually and is at or below the Battery Tweaks target. */
    fun brightnessLowered(context: Context): Boolean {
        val level = systemInt(context, Settings.System.SCREEN_BRIGHTNESS) ?: return false
        val manual = systemInt(context, Settings.System.SCREEN_BRIGHTNESS_MODE) == 0
        return manual && level <= LOWERED_BRIGHTNESS_MAX
    }

    /** Android 10 (API 29) and newer report thermal status. Older versions return null. */
    private fun thermalStatus(context: Context): Int? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return try {
            context.getSystemService(PowerManager::class.java).currentThermalStatus
        } catch (e: Exception) {
            null
        }
    }

    /** Tries normal app access first. If Android blocks it, tries Shizuku's shell. Never invents a value. */
    private fun readZones(): ZoneScan {
        val direct = readZonesDirect()
        if (direct.isNotEmpty()) return ZoneScan(direct, ZoneSource.APP)
        val viaShizuku = readZonesShizuku()
        if (viaShizuku.isNotEmpty()) return ZoneScan(viaShizuku, ZoneSource.SHIZUKU)
        return ZoneScan(emptyList(), ZoneSource.NONE)
    }

    private fun readZonesDirect(): List<ZoneReading> {
        val dirs: Array<File>? = try {
            File(ZONE_DIR).listFiles()
        } catch (e: SecurityException) {
            null
        }
        val list: List<File> = dirs?.toList() ?: emptyList()
        return list
            .filter { it.name.startsWith("thermal_zone") }
            .mapNotNull { dir ->
                val type = readFirstLine(File(dir, "type")) ?: return@mapNotNull null
                val temp = parseTemp(readFirstLine(File(dir, "temp")).orEmpty()) ?: return@mapNotNull null
                ZoneReading(type, temp)
            }
    }

    private fun readZonesShizuku(): List<ZoneReading> {
        val result = ShizukuGrant.shell("sh", "-c", ZONE_SCRIPT) ?: return emptyList()
        if (result.exitCode != 0) return emptyList()
        return result.output.lineSequence().mapNotNull { line ->
            val type = line.substringBefore('|').trim()
            val temp = parseTemp(line.substringAfter('|', "")) ?: return@mapNotNull null
            if (type.isEmpty()) null else ZoneReading(type, temp)
        }.toList()
    }

    /** Sysfs usually reports millidegrees Celsius (45000 = 45.0 °C). Values outside a plausible range are dropped. */
    private fun parseTemp(raw: String): Double? {
        val value = raw.trim().toDoubleOrNull() ?: return null
        val celsius = if (abs(value) > 1000.0) value / 1000.0 else value
        return celsius.takeIf { it >= PLAUSIBLE_MIN_C && it <= PLAUSIBLE_MAX_C }
    }

    private fun readFirstLine(file: File): String? = try {
        file.bufferedReader().use { it.readLine()?.trim() }
    } catch (e: Exception) {
        null
    }
}
