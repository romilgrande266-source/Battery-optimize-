package com.batteryoptimizer.universal.data

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

/**
 * Optional Shizuku integration. Shizuku runs a privileged shell that this app can ask to run a few
 * fixed commands for background restrictions on apps the user explicitly selects.
 * No root is needed, and the app works the same without Shizuku.
 *
 * Every failure is logged under the tag "BatteryOptimizerShizuku" and kept in [lastError].
 */
object ShizukuGrant {
    const val REQUEST_CODE = 4101
    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    const val DOWNLOAD_URL = "https://shizuku.rikka.app/download/"
    const val RESTRICT_OP = "RUN_ANY_IN_BACKGROUND"
    private const val TAG = "BatteryOptimizerShizuku"

    class ShellResult(val exitCode: Int, val output: String)

    /** Why the last Shizuku action failed. Null when it worked or has not run. */
    @Volatile
    var lastError: String? = null
        private set

    private val _connected = MutableStateFlow(false)

    /** True when Shizuku is running and allowed for this app. Updates when Shizuku starts or stops. */
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    private const val PREFS = "shizuku_prefs"
    private const val KEY_ENABLED = "access_enabled"

    private val _enabled = MutableStateFlow(true)

    /** True when Shizuku access is turned on inside this app. When off, the app never calls Shizuku. */
    val enabled: StateFlow<Boolean> = _enabled.asStateFlow()

    @Volatile
    private var prefs: SharedPreferences? = null

    /** Loads the saved on/off choice and starts listening. Call once from MainActivity. */
    fun init(context: Context) {
        val store = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = store
        _enabled.value = store.getBoolean(KEY_ENABLED, true)
        startListeners()
    }

    /**
     * Turns Shizuku access on or off inside this app. Off means the app never calls Shizuku.
     * It does not remove the permission in the Shizuku app; remove this app there to revoke it.
     */
    fun setEnabled(value: Boolean) {
        prefs?.edit()?.putBoolean(KEY_ENABLED, value)?.apply()
        _enabled.value = value
        refresh()
    }

    @Volatile
    private var listening = false

    /** Listens for Shizuku starting and stopping. Safe to call more than once. */
    fun startListeners() {
        if (listening) return
        listening = true
        try {
            Shizuku.addBinderReceivedListener { refresh() }
            Shizuku.addBinderDeadListener { _connected.value = false }
        } catch (e: Throwable) {
            listening = false
            Log.w(TAG, "Could not register Shizuku listeners", e)
        }
        refresh()
    }

    /** Re-checks the connection and updates [connected]. Never throws. */
    fun refresh() {
        _connected.value = hasPermission()
    }

    /** True when the Shizuku manager app is installed. */
    fun isInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** True when the Shizuku service is running and reachable. Never throws. */
    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        Log.w(TAG, "pingBinder failed", e)
        false
    }

    /** True when Shizuku is running and this app is allowed in it. Never throws. */
    fun hasPermission(): Boolean = try {
        _enabled.value && isAvailable() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        Log.w(TAG, "checkSelfPermission failed", e)
        false
    }

    /**
     * Asks Shizuku to show its allow prompt. If the user denied this app before, Shizuku may show
     * no prompt at all. The answer arrives in the listener on the Tweaks screen.
     */
    fun requestPermission() {
        try {
            if (_enabled.value && isAvailable()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            Log.w(TAG, "requestPermission failed", e)
        }
    }

    /** A plain-language reason for the user, based on the current state. */
    fun explain(): String = when {
        !_enabled.value -> "Shizuku access is off in this app. Turn it on in Shizuku setup."
        !isAvailable() -> "Shizuku is not running. Open Shizuku, start it, then try again."
        !hasPermission() -> "Shizuku is running but has not allowed Battery Optimizer. Allow it in Shizuku, then try again."
        else -> lastError ?: "Shizuku is connected and ready for supported background-app actions."
    }

    /**
     * Sets background restriction (RUN_ANY_IN_BACKGROUND) for one app, then reads it back.
     * Returns true only when Android reports the requested state. Never force-stops anything.
     */
    fun setBackgroundRestricted(pkg: String, restricted: Boolean): Boolean {
        lastError = null
        if (!hasPermission()) {
            lastError = "Shizuku is not connected."
            return false
        }
        val mode = if (restricted) "ignore" else "allow"
        val result = exec(arrayOf("cmd", "appops", "set", pkg, RESTRICT_OP, mode))
        if (result == null) {
            lastError = "Shizuku did not run the command for this app."
            return false
        }
        if (result.exitCode != 0) {
            lastError = "The command failed with code ${result.exitCode}: ${result.output}"
            Log.w(TAG, "set $pkg restricted=$restricted: $lastError")
            return false
        }
        val now = readBackgroundRestricted(pkg)
        if (now != restricted) {
            lastError = "Android reports the restriction as ${now ?: "unknown"}."
            Log.w(TAG, "readback for $pkg did not match: $lastError")
            return false
        }
        return true
    }

    /** Reads the background restriction for one app. Null when it cannot be read. */
    fun readBackgroundRestricted(pkg: String): Boolean? {
        val result = exec(arrayOf("cmd", "appops", "get", pkg, RESTRICT_OP)) ?: return null
        if (result.exitCode != 0) return null
        return when {
            result.output.contains("ignore") -> true
            // "default" means no override is set, so the app runs in the background normally.
            result.output.contains("allow") || result.output.contains("default") -> false
            else -> null
        }
    }

    /**
     * Runs one command in Shizuku's shell and returns its exit code and output. Null if Shizuku
     * cannot run it. Shizuku.newProcess is not public in every version, so it is called by reflection.
     */
    private fun exec(command: Array<String>): ShellResult? = if (!_enabled.value) null else try {
        val method = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java,
        )
        method.isAccessible = true
        val process = method.invoke(null, command, null, null) as Process
        val output = process.inputStream.bufferedReader().use { it.readText() }.trim()
        ShellResult(process.waitFor(), output)
    } catch (e: Throwable) {
        Log.w(TAG, "Shizuku shell failed: ${command.joinToString(" ")}", e)
        null
    }
}
