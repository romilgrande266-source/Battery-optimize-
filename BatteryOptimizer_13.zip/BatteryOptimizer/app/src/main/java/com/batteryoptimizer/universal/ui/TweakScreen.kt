package com.batteryoptimizer.universal.ui

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Timelapse
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.batteryoptimizer.universal.data.AppPrefs
import com.batteryoptimizer.universal.data.BatteryInfo
import com.batteryoptimizer.universal.data.OptimizationMode
import com.batteryoptimizer.universal.data.UiPrefs
import com.batteryoptimizer.universal.work.AlertWorker

@Composable
fun TweaksScreen(
    battery: BatteryInfo,
    onRestored: () -> Unit,
) {
    val context = LocalContext.current
    val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    val saverOn = powerManager.isPowerSaveMode
    val thermal = if (Build.VERSION.SDK_INT >= 29) {
        when (powerManager.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown threshold"
            else -> "Unknown"
        }
    } else "Not available on this Android version"

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        PremiumCard {
            Text("NEW SMART TWEAKS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Safe Android controls and monitoring. No hidden changes and no special permission screen.", style = MaterialTheme.typography.bodyMedium)
        }

        PremiumCard {
            Row { androidx.compose.material3.Icon(Icons.Filled.BatteryChargingFull, contentDescription = null); Text("  Long Life Battery", fontWeight = FontWeight.Bold) }
            Text("Battery: ${battery.percent?.let { "$it%" } ?: "Not supported"} · ${if (battery.isCharging) "Charging" else "Not charging"}")
            Text("Use an 80–90% charging target when your phone supports a built-in charge limit. This app provides a reminder only; it cannot control the charger.", style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onClick = { openSystemSettings(context, Settings.ACTION_BATTERY_SAVER_SETTINGS) }, modifier = Modifier.fillMaxWidth()) { Text("OPEN BATTERY SETTINGS") }
        }

        PremiumCard {
            Row { androidx.compose.material3.Icon(Icons.Filled.Thermostat, contentDescription = null); Text("  CPU & Thermal Guard", fontWeight = FontWeight.Bold) }
            Text("Android thermal status: $thermal", fontWeight = FontWeight.SemiBold)
            Text("Battery temperature: ${battery.temperatureC?.let { "%.1f °C".format(it) } ?: "Not reported"}")
            Text("Android exposes thermal status, not a universal CPU temperature reading. The app never disables thermal protection or forces CPU clocks.", style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onClick = { openSystemSettings(context, Settings.ACTION_BATTERY_SAVER_SETTINGS) }, modifier = Modifier.fillMaxWidth()) { Text("OPEN POWER SETTINGS") }
        }

        PremiumCard {
            Row { androidx.compose.material3.Icon(Icons.Filled.ElectricBolt, contentDescription = null); Text("  Smart Battery Saver", fontWeight = FontWeight.Bold) }
            Text(if (saverOn) "Battery Saver is ON" else "Battery Saver is OFF")
            Text("Android controls the actual Battery Saver state. Open system settings to switch it on or configure automatic activation.", style = MaterialTheme.typography.bodyMedium)
            Button(onClick = { openSystemSettings(context, Settings.ACTION_BATTERY_SAVER_SETTINGS) }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("CONFIGURE BATTERY SAVER") }
        }

        PremiumCard {
            Row { androidx.compose.material3.Icon(Icons.Filled.Memory, contentDescription = null); Text("  Background Power Control", fontWeight = FontWeight.Bold) }
            Text("Review apps that consume power in the background. Restrict only apps you recognize and do not need running all the time.", style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onClick = { openSystemSettings(context, "android.intent.action.POWER_USAGE_SUMMARY") }, modifier = Modifier.fillMaxWidth()) { Text("VIEW APP BATTERY USAGE") }
        }

        PremiumCard {
            Row { androidx.compose.material3.Icon(Icons.Filled.Speed, contentDescription = null); Text("  Balanced Gaming Mode", fontWeight = FontWeight.Bold) }
            Text("For lower heat, use the phone's built-in balanced or battery mode, reduce graphics settings in games, and take breaks if the device becomes hot. No CPU overclock or thermal bypass.", style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onClick = { openSystemSettings(context, Settings.ACTION_DISPLAY_SETTINGS) }, modifier = Modifier.fillMaxWidth()) { Text("OPEN DISPLAY SETTINGS") }
        }

        PremiumCard {
            Row { androidx.compose.material3.Icon(Icons.Filled.Timelapse, contentDescription = null); Text("  Charging & Heat Reminder", fontWeight = FontWeight.Bold) }
            Text("Avoid prolonged heat, use a suitable charger, and follow your phone maker's charging guidance. The 80/85/90% values are reminders, not an enforced charge cutoff.", style = MaterialTheme.typography.bodyMedium)
        }

        PremiumCard {
            Text("Bundled Script Modules", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("battery_saver_on.sh — enables Android Battery Saver when run in a supported Shizuku shell.", style = MaterialTheme.typography.bodySmall)
            Text("battery_saver_off.sh — disables Android Battery Saver when run in a supported Shizuku shell.", style = MaterialTheme.typography.bodySmall)
            Text("thermal_status.sh — read-only Android thermal-service report.", style = MaterialTheme.typography.bodySmall)
            Text("long_life_reminder.sh — prints battery-care reminders; it does not limit charging.", style = MaterialTheme.typography.bodySmall)
            Text("Scripts are included as source files and are not auto-executed by the app. Review them before use; command support varies by device.", style = MaterialTheme.typography.bodySmall)
        }

        PremiumCard {
            Text("Restore app preferences", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Reset this app's modes, alerts and theme. This does not modify protected Android settings.", style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onClick = {
                val prefs = AppPrefs(context)
                prefs.mode = OptimizationMode.NORMAL
                prefs.saverReminders = false
                AlertWorker.setEnabled(context, false)
                val ui = UiPrefs(context)
                ui.themeMode = 0
                ui.tempAlertEnabled = true
                ui.batteryAlertEnabled = true
                onRestored()
            }, modifier = Modifier.fillMaxWidth()) { Text("RESET APP PREFERENCES") }
        }
    }
}

private fun openSystemSettings(context: Context, action: String) {
    try { context.startActivity(Intent(action)) }
    catch (_: Exception) { context.startActivity(Intent(Settings.ACTION_SETTINGS)) }
}

/** Restores system values this app changed, and resets this app's own preferences. */
fun restoreEverything(context: Context): Boolean {
    val app = AppPrefs(context)
    app.mode = OptimizationMode.NORMAL
    app.saverReminders = false
    AlertWorker.setEnabled(context, false)
    val ui = UiPrefs(context)
    ui.themeMode = 0
    ui.tempAlertEnabled = true
    ui.batteryAlertEnabled = true
    return true
}

