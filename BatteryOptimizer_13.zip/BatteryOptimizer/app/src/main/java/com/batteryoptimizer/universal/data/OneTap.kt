package com.batteryoptimizer.universal.data

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.os.Build
import android.os.Process
import android.view.inputmethod.InputMethodManager

private const val DAY_MS = 86_400_000L
private const val NOT_SUPPORTED_TEXT = "Not Supported"

/**
 * What happened to one check.
 * CHANGED only when Android confirmed the new value. Everything else is information or a recommendation.
 */
enum class Outcome { CHANGED, OK, RECOMMEND, UNSUPPORTED }

data class CheckResult(
    val title: String,
    val value: String,
    val outcome: Outcome,
    val detail: String? = null,
)

/** An app Android lets us see. Minutes are screen time, not battery use. */
data class AppUsage(
    val label: String,
    val packageName: String,
    val foregroundMinutes: Long,
    val daysSinceUsed: Long?,
)

class BackgroundScan(
    val usageAccess: Boolean,
    val recent: List<AppUsage>,   // screen time in the last 24 hours, most first
    val unused: List<AppUsage>,   // installed apps with no use in the last 7 days
)

data class OneTapReport(
    val generatedAt: Long,
    val percent: Int?,
    val temperatureC: Double?,
    val optimizationStatus: String,
    val checks: List<CheckResult>,
    val screenPermissionNeeded: Boolean,
    val usageAccess: Boolean,
    val attention: List<AppUsage>,
) {
    val completed: List<CheckResult> get() = checks.filter { it.outcome == Outcome.CHANGED }
    val recommendations: List<CheckResult> get() = checks.filter { it.outcome == Outcome.RECOMMEND }
    val unsupported: List<CheckResult> get() = checks.filter { it.outcome == Outcome.UNSUPPORTED }
    val goodChecks: List<CheckResult> get() = checks.filter { it.outcome == Outcome.OK }
}

fun hasUsageAccess(context: Context): Boolean {
    val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
    @Suppress("DEPRECATION")
    val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

/**
 * Lists apps from Android's usage data. Android does not give apps per-app battery numbers,
 * so this uses screen time. It never stops, kills or restricts any app.
 */
object BackgroundCleanup {
    fun scan(context: Context): BackgroundScan {
        if (!hasUsageAccess(context)) return BackgroundScan(false, emptyList(), emptyList())
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return BackgroundScan(true, emptyList(), emptyList())

        val pm = context.packageManager
        val self = context.packageName
        val essential = essentialPackages(context)
        val now = System.currentTimeMillis()
        val day = usm.queryAndAggregateUsageStats(now - DAY_MS, now)
        val week = usm.queryAndAggregateUsageStats(now - 7 * DAY_MS, now)

        val recent = day.mapNotNull { (pkg, stats) ->
            if (stats.totalTimeInForeground <= 0L) return@mapNotNull null
            val info = eligible(pm, pkg, self, essential) ?: return@mapNotNull null
            AppUsage(
                label = pm.getApplicationLabel(info).toString(),
                packageName = pkg,
                foregroundMinutes = stats.totalTimeInForeground / 60_000L,
                daysSinceUsed = daysSince(now, week[pkg]?.lastTimeUsed ?: stats.lastTimeUsed),
            )
        }.sortedByDescending { it.foregroundMinutes }

        val unused = pm.getInstalledApplications(0).mapNotNull { info ->
            val pkg = info.packageName
            if (week.containsKey(pkg)) return@mapNotNull null
            eligible(pm, pkg, self, essential) ?: return@mapNotNull null
            AppUsage(pm.getApplicationLabel(info).toString(), pkg, 0L, null)
        }.sortedBy { it.label.lowercase() }

        return BackgroundScan(true, recent, unused)
    }

    private fun daysSince(now: Long, last: Long): Long? =
        if (last <= 0L) null else (now - last) / DAY_MS

    /** Third-party apps only. Phone, messages, home screen and keyboard apps are never listed. */
    private fun eligible(pm: PackageManager, pkg: String, self: String, essential: Set<String>): ApplicationInfo? {
        if (pkg == self || pkg in essential) return null
        return try {
            val info = pm.getApplicationInfo(pkg, 0)
            if ((info.flags and ApplicationInfo.FLAG_SYSTEM) != 0) null else info
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }

    internal fun essentialPackages(context: Context): Set<String> {
        val pm = context.packageManager
        val found = mutableSetOf<String>()
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_VIEW, Uri.parse("sms:")),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
        )
        for (intent in intents) {
            val pkg = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            if (pkg != null) found.add(pkg)
        }
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.enabledInputMethodList?.forEach { found.add(it.packageName) }
        return found
    }
}

object OneTapOptimizer {
    /**
     * Runs every check. A setting is changed only when Android allows it, and it is marked CHANGED
     * only after Android reads the new value back.
     */
    fun run(context: Context, battery: BatteryInfo): OneTapReport {
        val scan = BackgroundCleanup.scan(context)
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val checks = mutableListOf<CheckResult>()

        checks += CheckResult(
            "Battery status",
            "${battery.percent?.let { "$it%" } ?: NOT_SUPPORTED_TEXT} · ${battery.status.label}",
            Outcome.OK,
        )

        val temp = battery.temperatureC
        checks += when {
            temp == null -> CheckResult("Battery temperature", NOT_SUPPORTED_TEXT, Outcome.UNSUPPORTED)
            temp >= 45.0 -> CheckResult(
                "Battery temperature", "%.1f °C".format(temp), Outcome.RECOMMEND,
                "Stop heavy use, unplug the charger, and let the phone cool.",
            )
            temp >= 40.0 -> CheckResult(
                "Battery temperature", "%.1f °C".format(temp), Outcome.RECOMMEND,
                "Pause heavy use or charging.",
            )
            else -> CheckResult("Battery temperature", "%.1f °C".format(temp), Outcome.OK)
        }

        if (battery.isCharging) {
            checks += CheckResult(
                "Long Life Battery",
                "Charging",
                Outcome.RECOMMEND,
                "Use your phone's built-in 80–90% charge limit if available, and avoid heat. This app cannot stop charging at a target percentage.",
            )
        } else {
            checks += CheckResult(
                "Long Life Battery",
                "Reminder available",
                Outcome.OK,
                "Avoid prolonged heat and use the manufacturer's charging guidance.",
            )
        }

        if (Build.VERSION.SDK_INT >= 29) {
            val thermalStatus = pm.currentThermalStatus
            val thermalLabel = when (thermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Light"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown threshold"
                else -> "Unknown"
            }
            checks += CheckResult(
                "Android thermal status",
                thermalLabel,
                if (thermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) Outcome.RECOMMEND else Outcome.OK,
                "This is Android's thermal status, not a direct CPU temperature reading. System thermal protection remains enabled.",
            )
        } else {
            checks += CheckResult("Android thermal status", NOT_SUPPORTED_TEXT, Outcome.UNSUPPORTED,
                "Thermal status API requires Android 10 or newer.")
        }

        val top = scan.recent.take(3)
        checks += when {
            !scan.usageAccess -> CheckResult(
                "High battery usage apps", "Needs usage access", Outcome.RECOMMEND,
                "Android does not give apps per-app battery numbers. Allow usage access to see screen time per app.",
            )
            top.isEmpty() -> CheckResult("High battery usage apps", "None found", Outcome.OK)
            else -> CheckResult(
                "High battery usage apps", "${top.size} to review", Outcome.RECOMMEND,
                "Android does not give per-app battery numbers. These apps had the most screen time in 24 h.",
            )
        }

        checks += when {
            pm.isPowerSaveMode -> CheckResult("Battery Saver", "On", Outcome.OK)
            else -> CheckResult(
                "Battery Saver", "Off", Outcome.RECOMMEND,
                "Turn on Battery Saver when the battery is low or you are away from a charger.",
            )
        }

        checks += CheckResult(
            "Power-saving settings", "Available", Outcome.OK,
            "Battery Saver and Adaptive Battery are listed above and in Battery Tweaks.",
        )
        checks += CheckResult(
            "Notification activity", NOT_SUPPORTED_TEXT, Outcome.UNSUPPORTED,
            "Android does not let apps read other apps' notifications.",
        )
        checks += CheckResult(
            "Unnecessary wake-up activity", NOT_SUPPORTED_TEXT, Outcome.UNSUPPORTED,
            "Android does not show wake-up counts to apps. Review wake-ups in each app's notification settings.",
        )

        val exempt = pm.isIgnoringBatteryOptimizations(context.packageName)
        checks += CheckResult(
            "Battery optimization permissions",
            if (exempt) "This app is exempt" else "This app is optimized",
            Outcome.OK,
            "Other apps' exceptions can only be reviewed in Android's battery optimization list.",
        )
        checks += CheckResult(
            "Device power-saving", "Available", Outcome.OK,
            "Doze and Battery Saver are part of Android.",
        )

        val changed = checks.count { it.outcome == Outcome.CHANGED }
        val status = if (changed > 0) "Checked. $changed change(s) confirmed by Android" else "Checked. Battery and thermal status reviewed"

        return OneTapReport(
            generatedAt = System.currentTimeMillis(),
            percent = battery.percent,
            temperatureC = temp,
            optimizationStatus = status,
            checks = checks,
            screenPermissionNeeded = false,
            usageAccess = scan.usageAccess,
            attention = top,
        )
    }


}

fun OneTapReport.toShareText(): String = buildString {
    appendLine("Battery Optimizer report")
    appendLine("Status: $optimizationStatus")
    appendLine("Battery: ${percent?.let { "$it%" } ?: NOT_SUPPORTED_TEXT}")
    appendLine("Temperature: ${temperatureC?.let { "%.1f °C".format(it) } ?: NOT_SUPPORTED_TEXT}")
    appendSection("Completed optimizations", completed.map { "${it.title}: ${it.value}" },
        "None. Android did not confirm any change.")
    appendSection("Recommendations", recommendations.map { "${it.title}: ${it.detail ?: it.value}" },
        "None.")
    appendSection("Unsupported on this device", unsupported.map { it.title }, "None.")
    appendSection("Apps needing attention",
        attention.map { "${it.label}: ${it.foregroundMinutes} min screen time in 24 h" },
        "None found, or usage access is off.")
}

private fun StringBuilder.appendSection(title: String, items: List<String>, emptyText: String) {
    appendLine()
    appendLine("$title:")
    if (items.isEmpty()) appendLine("- $emptyText") else items.forEach { appendLine("- $it") }
}
